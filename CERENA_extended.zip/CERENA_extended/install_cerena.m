cerena_path = fileparts(which('install_cerena.m'));
addpath(genpath(cerena_path));

% General properties
TextSizes.DefaultAxesFontSize = 16;
TextSizes.DefaultTextFontSize = 16;
set(0,TextSizes);


