
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int JvB_linearChain_MM2_g_a(N_Vector vB, N_Vector JvB, realtype t, N_Vector x, N_Vector xB, N_Vector xBdot, void *user_data, N_Vector tmpB) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *xB_tmp = N_VGetArrayPointer(xB);
realtype *xBdot_tmp = N_VGetArrayPointer(xBdot);
realtype *vB_tmp = N_VGetArrayPointer(vB);
realtype *JvB_tmp = N_VGetArrayPointer(JvB);
memset(JvB_tmp,0,sizeof(realtype)*29);
  JvB_tmp[0] = p[1]*vB_tmp[0]-p[1]*vB_tmp[1]-p[1]*vB_tmp[10]+p[1]*vB_tmp[11]-p[1]*vB_tmp[12];
  JvB_tmp[1] = vB_tmp[1]*(p[2]+p[3])-vB_tmp[12]*(p[2]+p[3])-p[2]*vB_tmp[0]-p[3]*vB_tmp[2]-p[2]*vB_tmp[10]+p[2]*vB_tmp[11]+p[3]*vB_tmp[13]-p[3]*vB_tmp[14];
  JvB_tmp[2] = vB_tmp[2]*(p[4]+p[5])-vB_tmp[14]*(p[4]+p[5])-p[4]*vB_tmp[1]-p[5]*vB_tmp[3]-p[4]*vB_tmp[12]+p[4]*vB_tmp[13]+p[5]*vB_tmp[15]-p[5]*vB_tmp[16];
  JvB_tmp[3] = vB_tmp[3]*(p[6]+p[7])-vB_tmp[16]*(p[6]+p[7])-p[6]*vB_tmp[2]-p[7]*vB_tmp[4]-p[6]*vB_tmp[14]+p[6]*vB_tmp[15]+p[7]*vB_tmp[17]-p[7]*vB_tmp[18];
  JvB_tmp[4] = vB_tmp[4]*(p[8]+p[9])-vB_tmp[18]*(p[8]+p[9])-p[8]*vB_tmp[3]-p[9]*vB_tmp[5]-p[8]*vB_tmp[16]+p[8]*vB_tmp[17]+p[9]*vB_tmp[19]-p[9]*vB_tmp[20];
  JvB_tmp[5] = vB_tmp[5]*(p[10]+p[11])-vB_tmp[20]*(p[10]+p[11])-p[10]*vB_tmp[4]-p[11]*vB_tmp[6]-p[10]*vB_tmp[18]+p[10]*vB_tmp[19]+p[11]*vB_tmp[21]-p[11]*vB_tmp[22];
  JvB_tmp[6] = vB_tmp[6]*(p[12]+p[13])-vB_tmp[22]*(p[12]+p[13])-p[12]*vB_tmp[5]-p[13]*vB_tmp[7]-p[12]*vB_tmp[20]+p[12]*vB_tmp[21]+p[13]*vB_tmp[23]-p[13]*vB_tmp[24];
  JvB_tmp[7] = vB_tmp[7]*(p[14]+p[15])-vB_tmp[24]*(p[14]+p[15])-p[14]*vB_tmp[6]-p[15]*vB_tmp[8]-p[14]*vB_tmp[22]+p[14]*vB_tmp[23]+p[15]*vB_tmp[25]-p[15]*vB_tmp[26];
  JvB_tmp[8] = vB_tmp[8]*(p[16]+p[17])-vB_tmp[26]*(p[16]+p[17])-p[16]*vB_tmp[7]-p[17]*vB_tmp[9]-p[16]*vB_tmp[24]+p[16]*vB_tmp[25]+p[17]*vB_tmp[27]-p[17]*vB_tmp[28];
  JvB_tmp[9] = vB_tmp[9]*(p[18]+p[19])-vB_tmp[28]*(p[18]+p[19])-p[18]*vB_tmp[8]-p[18]*vB_tmp[26]+p[18]*vB_tmp[27];
  JvB_tmp[10] = p[1]*vB_tmp[10]*2.0-p[1]*vB_tmp[11];
  JvB_tmp[11] = p[2]*vB_tmp[10]*-2.0-p[1]*vB_tmp[12]*2.0+vB_tmp[11]*(p[1]+p[2]+p[3]);
  JvB_tmp[12] = -p[2]*vB_tmp[11]-p[3]*vB_tmp[13]+vB_tmp[12]*(p[2]*2.0+p[3]*2.0);
  JvB_tmp[13] = p[4]*vB_tmp[12]*-2.0-p[3]*vB_tmp[14]*2.0+vB_tmp[13]*(p[2]+p[3]+p[4]+p[5]);
  JvB_tmp[14] = -p[4]*vB_tmp[13]-p[5]*vB_tmp[15]+vB_tmp[14]*(p[4]*2.0+p[5]*2.0);
  JvB_tmp[15] = p[6]*vB_tmp[14]*-2.0-p[5]*vB_tmp[16]*2.0+vB_tmp[15]*(p[4]+p[5]+p[6]+p[7]);
  JvB_tmp[16] = -p[6]*vB_tmp[15]-p[7]*vB_tmp[17]+vB_tmp[16]*(p[6]*2.0+p[7]*2.0);
  JvB_tmp[17] = p[8]*vB_tmp[16]*-2.0-p[7]*vB_tmp[18]*2.0+vB_tmp[17]*(p[6]+p[7]+p[8]+p[9]);
  JvB_tmp[18] = -p[8]*vB_tmp[17]-p[9]*vB_tmp[19]+vB_tmp[18]*(p[8]*2.0+p[9]*2.0);
  JvB_tmp[19] = p[10]*vB_tmp[18]*-2.0-p[9]*vB_tmp[20]*2.0+vB_tmp[19]*(p[8]+p[9]+p[10]+p[11]);
  JvB_tmp[20] = -p[10]*vB_tmp[19]-p[11]*vB_tmp[21]+vB_tmp[20]*(p[10]*2.0+p[11]*2.0);
  JvB_tmp[21] = p[12]*vB_tmp[20]*-2.0-p[11]*vB_tmp[22]*2.0+vB_tmp[21]*(p[10]+p[11]+p[12]+p[13]);
  JvB_tmp[22] = -p[12]*vB_tmp[21]-p[13]*vB_tmp[23]+vB_tmp[22]*(p[12]*2.0+p[13]*2.0);
  JvB_tmp[23] = p[14]*vB_tmp[22]*-2.0-p[13]*vB_tmp[24]*2.0+vB_tmp[23]*(p[12]+p[13]+p[14]+p[15]);
  JvB_tmp[24] = -p[14]*vB_tmp[23]-p[15]*vB_tmp[25]+vB_tmp[24]*(p[14]*2.0+p[15]*2.0);
  JvB_tmp[25] = p[16]*vB_tmp[24]*-2.0-p[15]*vB_tmp[26]*2.0+vB_tmp[25]*(p[14]+p[15]+p[16]+p[17]);
  JvB_tmp[26] = -p[16]*vB_tmp[25]-p[17]*vB_tmp[27]+vB_tmp[26]*(p[16]*2.0+p[17]*2.0);
  JvB_tmp[27] = p[18]*vB_tmp[26]*-2.0-p[17]*vB_tmp[28]*2.0+vB_tmp[27]*(p[16]+p[17]+p[18]+p[19]);
  JvB_tmp[28] = -p[18]*vB_tmp[27]+vB_tmp[28]*(p[18]*2.0+p[19]*2.0);
return(0);

}


