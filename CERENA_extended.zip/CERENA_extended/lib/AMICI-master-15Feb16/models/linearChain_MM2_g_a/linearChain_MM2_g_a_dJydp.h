#ifndef _am_linearChain_MM2_g_a_dJydp_h
#define _am_linearChain_MM2_g_a_dJydp_h

int dJydp_linearChain_MM2_g_a(realtype t, int it, realtype *dJydp, realtype *y, N_Vector x, realtype *dydp, realtype *my, realtype *sd_y, realtype *dsigma_ydp, void *user_data);


#endif /* _am_linearChain_MM2_g_a_dJydp_h */
