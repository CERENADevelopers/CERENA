
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int sz_tf_linearChain_MM2_g_a(realtype t, int ie, int *nroots, realtype *sz, N_Vector x, N_Vector *sx, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *sx_tmp;
return(0);

}


