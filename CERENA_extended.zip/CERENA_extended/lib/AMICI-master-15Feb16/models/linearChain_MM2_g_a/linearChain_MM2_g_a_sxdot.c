
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>
#include "linearChain_MM2_g_a_JSparse.h"
#include "linearChain_MM2_g_a_dxdotdp.h"

int sxdot_linearChain_MM2_g_a(int Ns, realtype t, N_Vector x, N_Vector xdot,int ip,  N_Vector sx, N_Vector sxdot, void *user_data, N_Vector tmp1, N_Vector tmp2) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *sx_tmp = N_VGetArrayPointer(sx);
realtype *sxdot_tmp = N_VGetArrayPointer(sxdot);
realtype *xdot_tmp = N_VGetArrayPointer(xdot);
memset(sxdot_tmp,0,sizeof(realtype)*29);
int status = 0;
if(ip == 0) {
    status = JSparse_linearChain_MM2_g_a(t,x,xdot,tmp_J,user_data,NULL,NULL,NULL);
    status = dxdotdp_linearChain_MM2_g_a(t,tmp_dxdotdp,x,user_data);
}
  sxdot_tmp[0] = tmp_dxdotdp[0 + ip*29]+sx_tmp[0]*tmp_J->data[0]+sx_tmp[1]*tmp_J->data[5];
  sxdot_tmp[1] = tmp_dxdotdp[1 + ip*29]+sx_tmp[0]*tmp_J->data[1]+sx_tmp[1]*tmp_J->data[6]+sx_tmp[2]*tmp_J->data[13];
  sxdot_tmp[2] = tmp_dxdotdp[2 + ip*29]+sx_tmp[1]*tmp_J->data[7]+sx_tmp[2]*tmp_J->data[14]+sx_tmp[3]*tmp_J->data[21];
  sxdot_tmp[3] = tmp_dxdotdp[3 + ip*29]+sx_tmp[2]*tmp_J->data[15]+sx_tmp[3]*tmp_J->data[22]+sx_tmp[4]*tmp_J->data[29];
  sxdot_tmp[4] = tmp_dxdotdp[4 + ip*29]+sx_tmp[3]*tmp_J->data[23]+sx_tmp[4]*tmp_J->data[30]+sx_tmp[5]*tmp_J->data[37];
  sxdot_tmp[5] = tmp_dxdotdp[5 + ip*29]+sx_tmp[4]*tmp_J->data[31]+sx_tmp[5]*tmp_J->data[38]+sx_tmp[6]*tmp_J->data[45];
  sxdot_tmp[6] = tmp_dxdotdp[6 + ip*29]+sx_tmp[5]*tmp_J->data[39]+sx_tmp[6]*tmp_J->data[46]+sx_tmp[7]*tmp_J->data[53];
  sxdot_tmp[7] = tmp_dxdotdp[7 + ip*29]+sx_tmp[6]*tmp_J->data[47]+sx_tmp[7]*tmp_J->data[54]+sx_tmp[8]*tmp_J->data[61];
  sxdot_tmp[8] = tmp_dxdotdp[8 + ip*29]+sx_tmp[7]*tmp_J->data[55]+sx_tmp[8]*tmp_J->data[62]+sx_tmp[9]*tmp_J->data[69];
  sxdot_tmp[9] = tmp_dxdotdp[9 + ip*29]+sx_tmp[8]*tmp_J->data[63]+sx_tmp[9]*tmp_J->data[70];
  sxdot_tmp[10] = tmp_dxdotdp[10 + ip*29]+sx_tmp[0]*tmp_J->data[2]+sx_tmp[1]*tmp_J->data[8]+sx_tmp[10]*tmp_J->data[74]+sx_tmp[11]*tmp_J->data[76];
  sxdot_tmp[11] = tmp_dxdotdp[11 + ip*29]+sx_tmp[0]*tmp_J->data[3]+sx_tmp[1]*tmp_J->data[9]+sx_tmp[10]*tmp_J->data[75]+sx_tmp[11]*tmp_J->data[77]+sx_tmp[12]*tmp_J->data[79];
  sxdot_tmp[12] = tmp_dxdotdp[12 + ip*29]+sx_tmp[0]*tmp_J->data[4]+sx_tmp[1]*tmp_J->data[10]+sx_tmp[2]*tmp_J->data[16]+sx_tmp[11]*tmp_J->data[78]+sx_tmp[12]*tmp_J->data[80]+sx_tmp[13]*tmp_J->data[82];
  sxdot_tmp[13] = tmp_dxdotdp[13 + ip*29]+sx_tmp[1]*tmp_J->data[11]+sx_tmp[2]*tmp_J->data[17]+sx_tmp[12]*tmp_J->data[81]+sx_tmp[13]*tmp_J->data[83]+sx_tmp[14]*tmp_J->data[85];
  sxdot_tmp[14] = tmp_dxdotdp[14 + ip*29]+sx_tmp[1]*tmp_J->data[12]+sx_tmp[2]*tmp_J->data[18]+sx_tmp[3]*tmp_J->data[24]+sx_tmp[13]*tmp_J->data[84]+sx_tmp[14]*tmp_J->data[86]+sx_tmp[15]*tmp_J->data[88];
  sxdot_tmp[15] = tmp_dxdotdp[15 + ip*29]+sx_tmp[2]*tmp_J->data[19]+sx_tmp[3]*tmp_J->data[25]+sx_tmp[14]*tmp_J->data[87]+sx_tmp[15]*tmp_J->data[89]+sx_tmp[16]*tmp_J->data[91];
  sxdot_tmp[16] = tmp_dxdotdp[16 + ip*29]+sx_tmp[2]*tmp_J->data[20]+sx_tmp[3]*tmp_J->data[26]+sx_tmp[4]*tmp_J->data[32]+sx_tmp[15]*tmp_J->data[90]+sx_tmp[16]*tmp_J->data[92]+sx_tmp[17]*tmp_J->data[94];
  sxdot_tmp[17] = tmp_dxdotdp[17 + ip*29]+sx_tmp[3]*tmp_J->data[27]+sx_tmp[4]*tmp_J->data[33]+sx_tmp[16]*tmp_J->data[93]+sx_tmp[17]*tmp_J->data[95]+sx_tmp[18]*tmp_J->data[97];
  sxdot_tmp[18] = tmp_dxdotdp[18 + ip*29]+sx_tmp[3]*tmp_J->data[28]+sx_tmp[4]*tmp_J->data[34]+sx_tmp[5]*tmp_J->data[40]+sx_tmp[17]*tmp_J->data[96]+sx_tmp[18]*tmp_J->data[98]+sx_tmp[19]*tmp_J->data[100];
  sxdot_tmp[19] = tmp_dxdotdp[19 + ip*29]+sx_tmp[4]*tmp_J->data[35]+sx_tmp[5]*tmp_J->data[41]+sx_tmp[18]*tmp_J->data[99]+sx_tmp[19]*tmp_J->data[101]+sx_tmp[20]*tmp_J->data[103];
  sxdot_tmp[20] = tmp_dxdotdp[20 + ip*29]+sx_tmp[4]*tmp_J->data[36]+sx_tmp[5]*tmp_J->data[42]+sx_tmp[6]*tmp_J->data[48]+sx_tmp[19]*tmp_J->data[102]+sx_tmp[20]*tmp_J->data[104]+sx_tmp[21]*tmp_J->data[106];
  sxdot_tmp[21] = tmp_dxdotdp[21 + ip*29]+sx_tmp[5]*tmp_J->data[43]+sx_tmp[6]*tmp_J->data[49]+sx_tmp[20]*tmp_J->data[105]+sx_tmp[21]*tmp_J->data[107]+sx_tmp[22]*tmp_J->data[109];
  sxdot_tmp[22] = tmp_dxdotdp[22 + ip*29]+sx_tmp[5]*tmp_J->data[44]+sx_tmp[6]*tmp_J->data[50]+sx_tmp[7]*tmp_J->data[56]+sx_tmp[21]*tmp_J->data[108]+sx_tmp[22]*tmp_J->data[110]+sx_tmp[23]*tmp_J->data[112];
  sxdot_tmp[23] = tmp_dxdotdp[23 + ip*29]+sx_tmp[6]*tmp_J->data[51]+sx_tmp[7]*tmp_J->data[57]+sx_tmp[22]*tmp_J->data[111]+sx_tmp[23]*tmp_J->data[113]+sx_tmp[24]*tmp_J->data[115];
  sxdot_tmp[24] = tmp_dxdotdp[24 + ip*29]+sx_tmp[6]*tmp_J->data[52]+sx_tmp[7]*tmp_J->data[58]+sx_tmp[8]*tmp_J->data[64]+sx_tmp[23]*tmp_J->data[114]+sx_tmp[24]*tmp_J->data[116]+sx_tmp[25]*tmp_J->data[118];
  sxdot_tmp[25] = tmp_dxdotdp[25 + ip*29]+sx_tmp[7]*tmp_J->data[59]+sx_tmp[8]*tmp_J->data[65]+sx_tmp[24]*tmp_J->data[117]+sx_tmp[25]*tmp_J->data[119]+sx_tmp[26]*tmp_J->data[121];
  sxdot_tmp[26] = tmp_dxdotdp[26 + ip*29]+sx_tmp[7]*tmp_J->data[60]+sx_tmp[8]*tmp_J->data[66]+sx_tmp[9]*tmp_J->data[71]+sx_tmp[25]*tmp_J->data[120]+sx_tmp[26]*tmp_J->data[122]+sx_tmp[27]*tmp_J->data[124];
  sxdot_tmp[27] = tmp_dxdotdp[27 + ip*29]+sx_tmp[8]*tmp_J->data[67]+sx_tmp[9]*tmp_J->data[72]+sx_tmp[26]*tmp_J->data[123]+sx_tmp[27]*tmp_J->data[125]+sx_tmp[28]*tmp_J->data[127];
  sxdot_tmp[28] = tmp_dxdotdp[28 + ip*29]+sx_tmp[8]*tmp_J->data[68]+sx_tmp[9]*tmp_J->data[73]+sx_tmp[27]*tmp_J->data[126]+sx_tmp[28]*tmp_J->data[128];
return(status);

}


