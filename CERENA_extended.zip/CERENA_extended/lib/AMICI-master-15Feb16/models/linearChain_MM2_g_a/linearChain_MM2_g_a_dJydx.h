#ifndef _am_linearChain_MM2_g_a_dJydx_h
#define _am_linearChain_MM2_g_a_dJydx_h

int dJydx_linearChain_MM2_g_a(realtype t, int it, realtype *dJydx, realtype *y, N_Vector x, realtype *dydx, realtype *my, realtype *sd_y, void *user_data);


#endif /* _am_linearChain_MM2_g_a_dJydx_h */
