
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int sy_linearChain_MM2_g_a(realtype t, int it, realtype *sy, N_Vector x, N_Vector *sx, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *sx_tmp;
int ip;
for(ip = 0; ip<np; ip++) {
sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
switch (plist[ip]) {
  case 0: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*1)] = sx_tmp[9];

  } break;

  case 1: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*1)] = sx_tmp[9];

  } break;

  case 2: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*1)] = sx_tmp[9];

  } break;

  case 3: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*1)] = sx_tmp[9];

  } break;

  case 4: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*1)] = sx_tmp[9];

  } break;

  case 5: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*1)] = sx_tmp[9];

  } break;

  case 6: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*1)] = sx_tmp[9];

  } break;

  case 7: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*1)] = sx_tmp[9];

  } break;

  case 8: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*1)] = sx_tmp[9];

  } break;

  case 9: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*1)] = sx_tmp[9];

  } break;

  case 10: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*1)] = sx_tmp[9];

  } break;

  case 11: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*1)] = sx_tmp[9];

  } break;

  case 12: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*1)] = sx_tmp[9];

  } break;

  case 13: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*1)] = sx_tmp[9];

  } break;

  case 14: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*1)] = sx_tmp[9];

  } break;

  case 15: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*1)] = sx_tmp[9];

  } break;

  case 16: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*1)] = sx_tmp[9];

  } break;

  case 17: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*1)] = sx_tmp[9];

  } break;

  case 18: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*1)] = sx_tmp[9];

  } break;

  case 19: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*1)] = sx_tmp[9];

  } break;

}
}
return(0);

}


