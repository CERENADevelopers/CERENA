#ifndef _am_linearChain_MM2_g_a_qBdot_h
#define _am_linearChain_MM2_g_a_qBdot_h

int qBdot_linearChain_MM2_g_a(realtype t, N_Vector x, N_Vector xB, N_Vector qBdot, void *user_data);


#endif /* _am_linearChain_MM2_g_a_qBdot_h */
