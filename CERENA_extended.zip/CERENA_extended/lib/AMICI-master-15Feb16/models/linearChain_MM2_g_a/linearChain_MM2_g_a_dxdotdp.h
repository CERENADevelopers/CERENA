#ifndef _am_linearChain_MM2_g_a_dxdotdp_h
#define _am_linearChain_MM2_g_a_dxdotdp_h

int dxdotdp_linearChain_MM2_g_a(realtype t, realtype *dxdotdp, N_Vector x, void *user_data);


#endif /* _am_linearChain_MM2_g_a_dxdotdp_h */
