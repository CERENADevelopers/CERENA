
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int sigma_z_linearChain_MM2_g_a(realtype t, int ie, realtype *sigma_z, void *user_data) {
UserData udata = (UserData) user_data;
memset(sigma_z,0,sizeof(realtype)*0);
return(0);

}


