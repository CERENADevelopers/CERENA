#ifndef _am_linearChain_MM2_g_a_stau_h
#define _am_linearChain_MM2_g_a_stau_h

int stau_linearChain_MM2_g_a(realtype t, int ie, realtype *stau, N_Vector x, N_Vector *sx, void *user_data);


#endif /* _am_linearChain_MM2_g_a_stau_h */
