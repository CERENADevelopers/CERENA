
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int dsigma_ydp_linearChain_MM2_g_a(realtype t, realtype *dsigma_ydp, void *user_data) {
UserData udata = (UserData) user_data;
memset(dsigma_ydp,0,sizeof(realtype)*1*np);
int ip;
for(ip = 0; ip<np; ip++) {
switch (plist[ip]) {
}
}
return(0);

}


