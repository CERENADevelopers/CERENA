#ifndef _am_linearChain_MM2_g_a_sz_tf_h
#define _am_linearChain_MM2_g_a_sz_tf_h

int sz_tf_linearChain_MM2_g_a(realtype t, int ie, int *nroots, realtype *sz, N_Vector x, N_Vector *sx, void *user_data);


#endif /* _am_linearChain_MM2_g_a_sz_tf_h */
