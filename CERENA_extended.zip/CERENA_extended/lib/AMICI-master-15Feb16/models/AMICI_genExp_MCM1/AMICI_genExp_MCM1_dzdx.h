#ifndef _am_AMICI_genExp_MCM1_dzdx_h
#define _am_AMICI_genExp_MCM1_dzdx_h

int dzdx_AMICI_genExp_MCM1(realtype t, int ie, realtype *dzdx, N_Vector x, void *user_data);


#endif /* _am_AMICI_genExp_MCM1_dzdx_h */
