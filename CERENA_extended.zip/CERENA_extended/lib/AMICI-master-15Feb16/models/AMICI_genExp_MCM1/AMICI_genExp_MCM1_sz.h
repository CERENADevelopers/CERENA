#ifndef _am_AMICI_genExp_MCM1_sz_h
#define _am_AMICI_genExp_MCM1_sz_h

int sz_AMICI_genExp_MCM1(realtype t, int ie, int *nroots, realtype *sz, N_Vector x, N_Vector *sx, void *user_data);


#endif /* _am_AMICI_genExp_MCM1_sz_h */
