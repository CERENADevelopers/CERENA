#ifndef _am_AMICI_genExp_MCM1_z_h
#define _am_AMICI_genExp_MCM1_z_h

int z_AMICI_genExp_MCM1(realtype t, int ie, int *nroots, realtype *z, N_Vector x, void *user_data);


#endif /* _am_AMICI_genExp_MCM1_z_h */
