#ifndef _am_AMICI_genExp_MCM1_xdot_h
#define _am_AMICI_genExp_MCM1_xdot_h

int xdot_AMICI_genExp_MCM1(realtype t, N_Vector x, N_Vector dx, N_Vector xdot, void *user_data);


#endif /* _am_AMICI_genExp_MCM1_xdot_h */
