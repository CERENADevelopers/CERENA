#ifndef _am_AMICI_genExp_MCM1_root_h
#define _am_AMICI_genExp_MCM1_root_h

int root_AMICI_genExp_MCM1(realtype t, N_Vector x, N_Vector dx, realtype *root, void *user_data);


#endif /* _am_AMICI_genExp_MCM1_root_h */
