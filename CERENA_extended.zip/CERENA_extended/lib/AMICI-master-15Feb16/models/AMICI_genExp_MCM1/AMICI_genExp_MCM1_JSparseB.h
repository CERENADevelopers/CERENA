#ifndef _am_AMICI_genExp_MCM1_JSparseB_h
#define _am_AMICI_genExp_MCM1_JSparseB_h

int JSparseB_AMICI_genExp_MCM1(realtype t, realtype cj, N_Vector x, N_Vector dx, N_Vector xB, N_Vector dxB, N_Vector xBdot, SlsMat JB, void *user_data, N_Vector tmp1B, N_Vector tmp2B, N_Vector tmp3B);


#endif /* _am_AMICI_genExp_MCM1_JSparseB_h */
