#ifndef _am_AMICI_genExp_MCM1_h
#define _am_AMICI_genExp_MCM1_h

#include "AMICI_genExp_MCM1_J.h"
#include "AMICI_genExp_MCM1_JB.h"
#include "AMICI_genExp_MCM1_JBand.h"
#include "AMICI_genExp_MCM1_JBandB.h"
#include "AMICI_genExp_MCM1_JSparse.h"
#include "AMICI_genExp_MCM1_JSparseB.h"
#include "AMICI_genExp_MCM1_Jv.h"
#include "AMICI_genExp_MCM1_JvB.h"
#include "AMICI_genExp_MCM1_Jy.h"
#include "AMICI_genExp_MCM1_Jz.h"
#include "AMICI_genExp_MCM1_dJydp.h"
#include "AMICI_genExp_MCM1_dJydx.h"
#include "AMICI_genExp_MCM1_dJzdp.h"
#include "AMICI_genExp_MCM1_dJzdx.h"
#include "AMICI_genExp_MCM1_deltaqB.h"
#include "AMICI_genExp_MCM1_deltasx.h"
#include "AMICI_genExp_MCM1_deltax.h"
#include "AMICI_genExp_MCM1_deltaxB.h"
#include "AMICI_genExp_MCM1_dsigma_ydp.h"
#include "AMICI_genExp_MCM1_dsigma_zdp.h"
#include "AMICI_genExp_MCM1_dx0.h"
#include "AMICI_genExp_MCM1_dxdotdp.h"
#include "AMICI_genExp_MCM1_dydp.h"
#include "AMICI_genExp_MCM1_dydx.h"
#include "AMICI_genExp_MCM1_dzdp.h"
#include "AMICI_genExp_MCM1_dzdx.h"
#include "AMICI_genExp_MCM1_qBdot.h"
#include "AMICI_genExp_MCM1_root.h"
#include "AMICI_genExp_MCM1_sJy.h"
#include "AMICI_genExp_MCM1_sJz.h"
#include "AMICI_genExp_MCM1_sdx0.h"
#include "AMICI_genExp_MCM1_sigma_y.h"
#include "AMICI_genExp_MCM1_sigma_z.h"
#include "AMICI_genExp_MCM1_stau.h"
#include "AMICI_genExp_MCM1_sx0.h"
#include "AMICI_genExp_MCM1_sxdot.h"
#include "AMICI_genExp_MCM1_sy.h"
#include "AMICI_genExp_MCM1_sz.h"
#include "AMICI_genExp_MCM1_sz_tf.h"
#include "AMICI_genExp_MCM1_x0.h"
#include "AMICI_genExp_MCM1_xBdot.h"
#include "AMICI_genExp_MCM1_xdot.h"
#include "AMICI_genExp_MCM1_y.h"
#include "AMICI_genExp_MCM1_z.h"

int J_AMICI_genExp_MCM1(long int N, realtype t, realtype cj, N_Vector x, N_Vector dx, N_Vector xdot, DlsMat J, void *user_data, N_Vector tmp1, N_Vector tmp2, N_Vector tmp3);
int JB_AMICI_genExp_MCM1(long int NeqBdot, realtype t, realtype cj, N_Vector x, N_Vector dx, N_Vector xB, N_Vector dxB, N_Vector xBdot, DlsMat JB, void *user_data, N_Vector tmp1B, N_Vector tmp2B, N_Vector tmp3B);
int JBand_AMICI_genExp_MCM1(long int N, long int mupper, long int mlower, realtype t, realtype cj, N_Vector x, N_Vector dx, N_Vector xdot, DlsMat J, void *user_data, N_Vector tmp1, N_Vector tmp2, N_Vector tmp3);
int JBandB_AMICI_genExp_MCM1(long int NeqBdot, long int mupper, long int mlower, realtype t, realtype cj, N_Vector x, N_Vector dx, N_Vector xB, N_Vector dxB, N_Vector xBdot, DlsMat JB, void *user_data, N_Vector tmp1B, N_Vector tmp2B, N_Vector tmp3B);
int JSparse_AMICI_genExp_MCM1(realtype t, realtype cj, N_Vector x, N_Vector dx, N_Vector xdot, SlsMat J, void *user_data, N_Vector tmp1, N_Vector tmp2, N_Vector tmp3);
int JSparseB_AMICI_genExp_MCM1(realtype t, realtype cj, N_Vector x, N_Vector dx, N_Vector xB, N_Vector dxB, N_Vector xBdot, SlsMat JB, void *user_data, N_Vector tmp1B, N_Vector tmp2B, N_Vector tmp3B);
int Jv_AMICI_genExp_MCM1(realtype t, N_Vector x, N_Vector dx, N_Vector xdot, N_Vector v, N_Vector Jv, realtype cj, void *user_data, N_Vector tmp1, N_Vector tmp2);
int JvB_AMICI_genExp_MCM1(realtype t, N_Vector x, N_Vector dx, N_Vector xB, N_Vector dxB, N_Vector xBdot, N_Vector vB, N_Vector JvB, realtype cj, void *user_data, N_Vector tmpB1, N_Vector tmpB2);
int Jy_AMICI_genExp_MCM1(realtype t, int it, realtype *Jy, realtype *y, N_Vector x, realtype *my, realtype *sd_y, void *user_data);
int Jz_AMICI_genExp_MCM1(realtype t, int ie, realtype *Jz, realtype *z, N_Vector x, realtype *mz, realtype *sd_z, void *user_data, void *temp_data);
int dJydp_AMICI_genExp_MCM1(realtype t, int it, realtype *dJydp, realtype *y, N_Vector x, realtype *dydp, realtype *my, realtype *sd_y, realtype *dsigma_ydp, void *user_data);
int dJydx_AMICI_genExp_MCM1(realtype t, int it, realtype *dJydx, realtype *y, N_Vector x, realtype *dydx, realtype *my, realtype *sd_y, void *user_data);
int dJzdp_AMICI_genExp_MCM1(realtype t, int ie, realtype *dJzdp, realtype *z, N_Vector x, realtype *dzdp, realtype *mz, realtype *sd_z, realtype *dsigma_zdp, void *user_data, void *temp_data);
int dJzdx_AMICI_genExp_MCM1(realtype t, int ie, realtype *dJzdx, realtype *z, N_Vector x, realtype *dzdx, realtype *mz, realtype *sd_z, void *user_data, void *temp_data);
int deltaqB_AMICI_genExp_MCM1(realtype t, int ie, realtype *deltaqB, N_Vector x, N_Vector xB, N_Vector qBdot, N_Vector xdot, N_Vector xdot_old, void *user_data);
int deltasx_AMICI_genExp_MCM1(realtype t, int ie, realtype *deltasx, N_Vector x, N_Vector xdot, N_Vector xdot_old, N_Vector *sx, void *user_data);
int deltax_AMICI_genExp_MCM1(realtype t, int ie, realtype *deltax, N_Vector x, N_Vector xdot, N_Vector xdot_old, void *user_data);
int deltaxB_AMICI_genExp_MCM1(realtype t, int ie, realtype *deltaxB, N_Vector x, N_Vector xB, N_Vector xdot, N_Vector xdot_old, void *user_data);
int dsigma_ydp_AMICI_genExp_MCM1(realtype t, realtype *dsigma_ydp, void *user_data);
int dsigma_zdp_AMICI_genExp_MCM1(realtype t, int ie, realtype *dsigma_zdp, void *user_data);
int dx0_AMICI_genExp_MCM1(N_Vector x0, N_Vector dx0, void *user_data);
int dxdotdp_AMICI_genExp_MCM1(realtype t, realtype *dxdotdp, N_Vector x, void *user_data);
int dydp_AMICI_genExp_MCM1(realtype t, int it, realtype *dydp, N_Vector x, void *user_data);
int dydx_AMICI_genExp_MCM1(realtype t, int it, realtype *dydx, N_Vector x, void *user_data);
int dzdp_AMICI_genExp_MCM1(realtype t, int ie, realtype *dzdp, N_Vector x, void *user_data);
int dzdx_AMICI_genExp_MCM1(realtype t, int ie, realtype *dzdx, N_Vector x, void *user_data);
int qBdot_AMICI_genExp_MCM1(realtype t, N_Vector x, N_Vector dx, N_Vector xB, N_Vector dxB, N_Vector qBdot, void *user_data);
int root_AMICI_genExp_MCM1(realtype t, N_Vector x, N_Vector dx, realtype *root, void *user_data);
int sJy_AMICI_genExp_MCM1(realtype t, int it, realtype *sJy, realtype *y, N_Vector x, realtype *dydp, realtype *sy, realtype *my, realtype *sd_y, realtype *dsigma_ydp, void *user_data);
int sJz_AMICI_genExp_MCM1(realtype t, int ie, realtype *sJz, realtype *z, N_Vector x, realtype *dzdp, realtype *sz, realtype *mz, realtype *sd_z, realtype *dsigma_zdp, void *user_data, void *temp_data);
int sdx0_AMICI_genExp_MCM1(N_Vector *sdx0, N_Vector x, N_Vector dx, void *user_data);
int sigma_y_AMICI_genExp_MCM1(realtype t, realtype *sigma_y, void *user_data);
int sigma_z_AMICI_genExp_MCM1(realtype t, int ie, realtype *sigma_z, void *user_data);
int stau_AMICI_genExp_MCM1(realtype t, int ie, realtype *stau, N_Vector x, N_Vector *sx, void *user_data);
int sx0_AMICI_genExp_MCM1(N_Vector *sx0, N_Vector x, N_Vector dx, void *user_data);
int sxdot_AMICI_genExp_MCM1(int Ns, realtype t, N_Vector x, N_Vector dx, N_Vector xdot, N_Vector *sx, N_Vector *sdx, N_Vector *sxdot, void *user_data, N_Vector tmp1, N_Vector tmp2, N_Vector tmp3);
int sy_AMICI_genExp_MCM1(realtype t, int it, realtype *sy, N_Vector x, N_Vector *sx, void *user_data);
int sz_AMICI_genExp_MCM1(realtype t, int ie, int *nroots, realtype *sz, N_Vector x, N_Vector *sx, void *user_data);
int sz_tf_AMICI_genExp_MCM1(realtype t, int ie, int *nroots, realtype *sz, N_Vector x, N_Vector *sx, void *user_data);
int x0_AMICI_genExp_MCM1(N_Vector x0, void *user_data);
int xBdot_AMICI_genExp_MCM1(realtype t, N_Vector x, N_Vector dx, N_Vector xB, N_Vector dxB, N_Vector xBdot, void *user_data);
int xdot_AMICI_genExp_MCM1(realtype t, N_Vector x, N_Vector dx, N_Vector xdot, void *user_data);
int y_AMICI_genExp_MCM1(realtype t, int it, realtype *y, N_Vector x, void *user_data);
int z_AMICI_genExp_MCM1(realtype t, int ie, int *nroots, realtype *z, N_Vector x, void *user_data);


#endif /* _am_AMICI_genExp_MCM1_h */
