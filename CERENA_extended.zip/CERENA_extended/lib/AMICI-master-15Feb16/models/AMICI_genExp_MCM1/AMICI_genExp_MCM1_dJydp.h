#ifndef _am_AMICI_genExp_MCM1_dJydp_h
#define _am_AMICI_genExp_MCM1_dJydp_h

int dJydp_AMICI_genExp_MCM1(realtype t, int it, realtype *dJydp, realtype *y, N_Vector x, realtype *dydp, realtype *my, realtype *sd_y, realtype *dsigma_ydp, void *user_data);


#endif /* _am_AMICI_genExp_MCM1_dJydp_h */
