
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>
#include <include/tdata.h>
#undef t
#undef x
#undef x_tmp
#undef dzdp
#undef dzdx
#undef dsigma_zdp

int dJzdx_AMICI_genExp_MCM1(realtype t, int ie, realtype *dJzdx, realtype *z, N_Vector x, realtype *dzdx, realtype *mz, realtype *sd_z, void *user_data, void *temp_data) {
UserData udata = (UserData) user_data;
TempData tdata = (TempData) temp_data;
realtype *x_tmp = N_VGetArrayPointer(x);
return(0);

}


