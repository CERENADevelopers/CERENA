#ifndef _am_AMICI_genExp_MCM1_dxdotdp_h
#define _am_AMICI_genExp_MCM1_dxdotdp_h

int dxdotdp_AMICI_genExp_MCM1(realtype t, realtype *dxdotdp, N_Vector x, void *user_data);


#endif /* _am_AMICI_genExp_MCM1_dxdotdp_h */
