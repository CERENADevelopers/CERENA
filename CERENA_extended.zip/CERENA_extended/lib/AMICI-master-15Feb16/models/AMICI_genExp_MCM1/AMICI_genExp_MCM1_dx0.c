
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int dx0_AMICI_genExp_MCM1(N_Vector x0, N_Vector dx0, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x0_tmp = N_VGetArrayPointer(x0);
realtype *dx0_tmp = N_VGetArrayPointer(dx0);
memset(dx0_tmp,0,sizeof(realtype)*6);
  dx0_tmp[0] = p[0]*(-9.999999999E-1)+p[1]*1.0E-10-k[4]*k[18]*p[6]*9.999999999E-1;
  dx0_tmp[1] = p[0]*9.999999999E-1-p[1]*1.0E-10+k[4]*k[18]*p[6]*9.999999999E-1;
  dx0_tmp[2] = -(p[3]*(k[3]*k[17]-p[9]*(k[3]-1.0)))/k[0];
  dx0_tmp[3] = (p[4]*t*(k[3]*k[17]-p[9]*(k[3]-1.0)))/k[0]-(k[4]*k[18]*p[5])/k[0];
  dx0_tmp[4] = (p[2]-p[3]*(k[3]*k[17]-p[9]*(k[3]-1.0)))/k[0];
  dx0_tmp[5] = (p[4]*t*(k[3]*k[17]-p[9]*(k[3]-1.0)))/k[0]-(k[4]*k[18]*p[5])/k[0];
return(0);

}


