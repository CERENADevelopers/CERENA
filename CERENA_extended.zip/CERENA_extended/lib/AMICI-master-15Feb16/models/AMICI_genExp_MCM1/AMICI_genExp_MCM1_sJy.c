
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int sJy_AMICI_genExp_MCM1(realtype t, int it, realtype *sJy, realtype *y, N_Vector x, realtype *dydp, realtype *sy, realtype *my, realtype *sd_y, realtype *dsigma_ydp, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
int ip;
for(ip = 0; ip<np; ip++) {
switch (plist[ip]) {
  case 0: {
int iy;
for(iy=0;iy<5;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*5)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1-1.0/(sd_y[1]*sd_y[1])*sy[it+nt*(1+ip*5)]*(my[it+nt*1]*2.0-y[it+nt*1]*2.0)*5.0E-1-1.0/(sd_y[2]*sd_y[2])*sy[it+nt*(2+ip*5)]*(my[it+nt*2]*2.0-y[it+nt*2]*2.0)*5.0E-1-1.0/(sd_y[3]*sd_y[3])*sy[it+nt*(3+ip*5)]*(my[it+nt*3]*2.0-y[it+nt*3]*2.0)*5.0E-1-1.0/(sd_y[4]*sd_y[4])*sy[it+nt*(4+ip*5)]*(my[it+nt*4]*2.0-y[it+nt*4]*2.0)*5.0E-1;

  } break;

  case 1: {
int iy;
for(iy=0;iy<5;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*5)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1-1.0/(sd_y[1]*sd_y[1])*sy[it+nt*(1+ip*5)]*(my[it+nt*1]*2.0-y[it+nt*1]*2.0)*5.0E-1-1.0/(sd_y[2]*sd_y[2])*sy[it+nt*(2+ip*5)]*(my[it+nt*2]*2.0-y[it+nt*2]*2.0)*5.0E-1-1.0/(sd_y[3]*sd_y[3])*sy[it+nt*(3+ip*5)]*(my[it+nt*3]*2.0-y[it+nt*3]*2.0)*5.0E-1-1.0/(sd_y[4]*sd_y[4])*sy[it+nt*(4+ip*5)]*(my[it+nt*4]*2.0-y[it+nt*4]*2.0)*5.0E-1;

  } break;

  case 2: {
int iy;
for(iy=0;iy<5;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*5)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1-1.0/(sd_y[1]*sd_y[1])*sy[it+nt*(1+ip*5)]*(my[it+nt*1]*2.0-y[it+nt*1]*2.0)*5.0E-1-1.0/(sd_y[2]*sd_y[2])*sy[it+nt*(2+ip*5)]*(my[it+nt*2]*2.0-y[it+nt*2]*2.0)*5.0E-1-1.0/(sd_y[3]*sd_y[3])*sy[it+nt*(3+ip*5)]*(my[it+nt*3]*2.0-y[it+nt*3]*2.0)*5.0E-1-1.0/(sd_y[4]*sd_y[4])*sy[it+nt*(4+ip*5)]*(my[it+nt*4]*2.0-y[it+nt*4]*2.0)*5.0E-1;

  } break;

  case 3: {
int iy;
for(iy=0;iy<5;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*5)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1-1.0/(sd_y[1]*sd_y[1])*sy[it+nt*(1+ip*5)]*(my[it+nt*1]*2.0-y[it+nt*1]*2.0)*5.0E-1-1.0/(sd_y[2]*sd_y[2])*sy[it+nt*(2+ip*5)]*(my[it+nt*2]*2.0-y[it+nt*2]*2.0)*5.0E-1-1.0/(sd_y[3]*sd_y[3])*sy[it+nt*(3+ip*5)]*(my[it+nt*3]*2.0-y[it+nt*3]*2.0)*5.0E-1-1.0/(sd_y[4]*sd_y[4])*sy[it+nt*(4+ip*5)]*(my[it+nt*4]*2.0-y[it+nt*4]*2.0)*5.0E-1;

  } break;

  case 4: {
int iy;
for(iy=0;iy<5;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*5)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1-1.0/(sd_y[1]*sd_y[1])*sy[it+nt*(1+ip*5)]*(my[it+nt*1]*2.0-y[it+nt*1]*2.0)*5.0E-1-1.0/(sd_y[2]*sd_y[2])*sy[it+nt*(2+ip*5)]*(my[it+nt*2]*2.0-y[it+nt*2]*2.0)*5.0E-1-1.0/(sd_y[3]*sd_y[3])*sy[it+nt*(3+ip*5)]*(my[it+nt*3]*2.0-y[it+nt*3]*2.0)*5.0E-1-1.0/(sd_y[4]*sd_y[4])*sy[it+nt*(4+ip*5)]*(my[it+nt*4]*2.0-y[it+nt*4]*2.0)*5.0E-1;

  } break;

  case 5: {
int iy;
for(iy=0;iy<5;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*5)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1-1.0/(sd_y[1]*sd_y[1])*sy[it+nt*(1+ip*5)]*(my[it+nt*1]*2.0-y[it+nt*1]*2.0)*5.0E-1-1.0/(sd_y[2]*sd_y[2])*sy[it+nt*(2+ip*5)]*(my[it+nt*2]*2.0-y[it+nt*2]*2.0)*5.0E-1-1.0/(sd_y[3]*sd_y[3])*sy[it+nt*(3+ip*5)]*(my[it+nt*3]*2.0-y[it+nt*3]*2.0)*5.0E-1-1.0/(sd_y[4]*sd_y[4])*sy[it+nt*(4+ip*5)]*(my[it+nt*4]*2.0-y[it+nt*4]*2.0)*5.0E-1;

  } break;

  case 6: {
int iy;
for(iy=0;iy<5;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*5)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1-1.0/(sd_y[1]*sd_y[1])*sy[it+nt*(1+ip*5)]*(my[it+nt*1]*2.0-y[it+nt*1]*2.0)*5.0E-1-1.0/(sd_y[2]*sd_y[2])*sy[it+nt*(2+ip*5)]*(my[it+nt*2]*2.0-y[it+nt*2]*2.0)*5.0E-1-1.0/(sd_y[3]*sd_y[3])*sy[it+nt*(3+ip*5)]*(my[it+nt*3]*2.0-y[it+nt*3]*2.0)*5.0E-1-1.0/(sd_y[4]*sd_y[4])*sy[it+nt*(4+ip*5)]*(my[it+nt*4]*2.0-y[it+nt*4]*2.0)*5.0E-1;

  } break;

  case 7: {
int iy;
for(iy=0;iy<5;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += dydp[39]*1.0/(sd_y[4]*sd_y[4])*(my[it+nt*4]*2.0-y[it+nt*4]*2.0)*-5.0E-1-1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*5)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*5.0E-1-1.0/(sd_y[1]*sd_y[1])*sy[it+nt*(1+ip*5)]*(my[it+nt*1]*2.0-y[it+nt*1]*2.0)*5.0E-1-1.0/(sd_y[2]*sd_y[2])*sy[it+nt*(2+ip*5)]*(my[it+nt*2]*2.0-y[it+nt*2]*2.0)*5.0E-1-1.0/(sd_y[3]*sd_y[3])*sy[it+nt*(3+ip*5)]*(my[it+nt*3]*2.0-y[it+nt*3]*2.0)*5.0E-1-1.0/(sd_y[4]*sd_y[4])*sy[it+nt*(4+ip*5)]*(my[it+nt*4]*2.0-y[it+nt*4]*2.0)*5.0E-1;

  } break;

  case 8: {
int iy;
for(iy=0;iy<5;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += dydp[44]*1.0/(sd_y[4]*sd_y[4])*(my[it+nt*4]*2.0-y[it+nt*4]*2.0)*-5.0E-1-1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*5)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*5.0E-1-1.0/(sd_y[1]*sd_y[1])*sy[it+nt*(1+ip*5)]*(my[it+nt*1]*2.0-y[it+nt*1]*2.0)*5.0E-1-1.0/(sd_y[2]*sd_y[2])*sy[it+nt*(2+ip*5)]*(my[it+nt*2]*2.0-y[it+nt*2]*2.0)*5.0E-1-1.0/(sd_y[3]*sd_y[3])*sy[it+nt*(3+ip*5)]*(my[it+nt*3]*2.0-y[it+nt*3]*2.0)*5.0E-1-1.0/(sd_y[4]*sd_y[4])*sy[it+nt*(4+ip*5)]*(my[it+nt*4]*2.0-y[it+nt*4]*2.0)*5.0E-1;

  } break;

  case 9: {
int iy;
for(iy=0;iy<5;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*5)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1-1.0/(sd_y[1]*sd_y[1])*sy[it+nt*(1+ip*5)]*(my[it+nt*1]*2.0-y[it+nt*1]*2.0)*5.0E-1-1.0/(sd_y[2]*sd_y[2])*sy[it+nt*(2+ip*5)]*(my[it+nt*2]*2.0-y[it+nt*2]*2.0)*5.0E-1-1.0/(sd_y[3]*sd_y[3])*sy[it+nt*(3+ip*5)]*(my[it+nt*3]*2.0-y[it+nt*3]*2.0)*5.0E-1-1.0/(sd_y[4]*sd_y[4])*sy[it+nt*(4+ip*5)]*(my[it+nt*4]*2.0-y[it+nt*4]*2.0)*5.0E-1;

  } break;

}
}
return(0);

}


