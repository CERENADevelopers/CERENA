#ifndef _am_AMICI_genExp_MCM1_sigma_y_h
#define _am_AMICI_genExp_MCM1_sigma_y_h

int sigma_y_AMICI_genExp_MCM1(realtype t, realtype *sigma_y, void *user_data);


#endif /* _am_AMICI_genExp_MCM1_sigma_y_h */
