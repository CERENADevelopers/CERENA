
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int dzdp_AMICI_genExp_MCM1(realtype t, int ie, realtype *dzdp, N_Vector x, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
int ip;
for(ip = 0; ip<np; ip++) {
switch (plist[ip]) {
}
}
return(0);

}


