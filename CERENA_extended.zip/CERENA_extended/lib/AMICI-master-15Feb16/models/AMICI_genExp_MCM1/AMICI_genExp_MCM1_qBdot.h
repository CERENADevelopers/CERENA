#ifndef _am_AMICI_genExp_MCM1_qBdot_h
#define _am_AMICI_genExp_MCM1_qBdot_h

int qBdot_AMICI_genExp_MCM1(realtype t, N_Vector x, N_Vector dx, N_Vector xB, N_Vector dxB, N_Vector qBdot, void *user_data);


#endif /* _am_AMICI_genExp_MCM1_qBdot_h */
