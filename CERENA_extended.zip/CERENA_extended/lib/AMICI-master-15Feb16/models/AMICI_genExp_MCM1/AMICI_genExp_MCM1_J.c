
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int J_AMICI_genExp_MCM1(long int N, realtype t, realtype cj, N_Vector x, N_Vector dx, N_Vector xdot, DlsMat J, void *user_data, N_Vector tmp1, N_Vector tmp2, N_Vector tmp3) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *dx_tmp = N_VGetArrayPointer(dx);
realtype *xdot_tmp = N_VGetArrayPointer(xdot);
memset(J->data,0,sizeof(realtype)*36);
  J->data[0] = -cj-p[0]-k[0]*p[6]*x_tmp[3];
  J->data[1] = p[0]+k[0]*p[6]*x_tmp[3];
  J->data[2] = -dx_tmp[2]-p[3]*x_tmp[2];
  J->data[3] = -dx_tmp[3]-p[5]*x_tmp[3]+p[4]*t*x_tmp[2];
  J->data[4] = (k[0]*p[0]*x_tmp[2]-k[0]*p[0]*x_tmp[4]+(k[0]*k[0])*p[6]*x_tmp[2]*x_tmp[3]-(k[0]*k[0])*p[6]*x_tmp[3]*x_tmp[4])/k[0];
  J->data[5] = p[0]*x_tmp[3]-p[0]*x_tmp[5]+k[0]*p[6]*(x_tmp[3]*x_tmp[3])-k[0]*p[6]*x_tmp[3]*x_tmp[5];
  J->data[6] = p[1];
  J->data[7] = -cj-p[1];
  J->data[8] = -p[1]*x_tmp[2]+p[1]*x_tmp[4];
  J->data[9] = -p[1]*x_tmp[3]+p[1]*x_tmp[5];
  J->data[10] = -dx_tmp[4]+(p[2]-k[0]*p[3]*x_tmp[4])/k[0];
  J->data[11] = -dx_tmp[5]-p[5]*x_tmp[5]+p[4]*t*x_tmp[4];
  J->data[14] = -cj*x_tmp[0]-p[1]*x_tmp[1]-p[3]*x_tmp[0];
  J->data[15] = p[4]*t*x_tmp[0];
  J->data[16] = (k[0]*p[0]*x_tmp[0]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3])/k[0];
  J->data[18] = -k[0]*p[6]*x_tmp[0];
  J->data[19] = k[0]*p[6]*x_tmp[0];
  J->data[21] = -cj*x_tmp[0]-p[1]*x_tmp[1]-p[5]*x_tmp[0];
  J->data[22] = ((k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[2]-(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[4])/k[0];
  J->data[23] = p[0]*x_tmp[0]+k[0]*p[6]*x_tmp[0]*x_tmp[3]*2.0-k[0]*p[6]*x_tmp[0]*x_tmp[5];
  J->data[26] = p[1]*x_tmp[1];
  J->data[28] = -cj*x_tmp[1]-(k[0]*p[0]*x_tmp[0]+k[0]*p[3]*x_tmp[1]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3])/k[0];
  J->data[29] = p[4]*t*x_tmp[1];
  J->data[33] = p[1]*x_tmp[1];
  J->data[35] = -cj*x_tmp[1]-p[0]*x_tmp[0]-p[5]*x_tmp[1]-k[0]*p[6]*x_tmp[0]*x_tmp[3];
int ix;
for(ix = 0; ix<36; ix++) {
   if(mxIsNaN(J->data[ix])) {
       J->data[ix] = 0;       if(!udata->am_nan_J) {
           mexWarnMsgIdAndTxt("AMICI:mex:fJ:NaN","AMICI replaced a NaN value in Jacobian and replaced it by 0.0. This will not be reported again for this simulation run.");           udata->am_nan_J = TRUE;
       }
   }   if(mxIsInf(J->data[ix])) {
       mexWarnMsgIdAndTxt("AMICI:mex:fJ:Inf","AMICI encountered an Inf value in Jacobian! Aborting simulation ... ");       return(-1);   }}
return(0);

}


