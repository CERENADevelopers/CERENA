
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int dJydp_AMICI_genExp_MCM1(realtype t, int it, realtype *dJydp, realtype *y, N_Vector x, realtype *dydp, realtype *my, realtype *sd_y, realtype *dsigma_ydp, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
int iy;
for(iy=0;iy<5;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  dJydp[7] += dydp[39]*1.0/(sd_y[4]*sd_y[4])*(my[it+nt*4]*2.0-y[it+nt*4]*2.0)*-5.0E-1;
  dJydp[8] += dydp[44]*1.0/(sd_y[4]*sd_y[4])*(my[it+nt*4]*2.0-y[it+nt*4]*2.0)*-5.0E-1;
return(0);

}


