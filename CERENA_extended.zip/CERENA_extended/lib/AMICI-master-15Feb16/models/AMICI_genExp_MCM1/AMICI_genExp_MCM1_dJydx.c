
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int dJydx_AMICI_genExp_MCM1(realtype t, int it, realtype *dJydx, realtype *y, N_Vector x, realtype *dydx, realtype *my, realtype *sd_y, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
int iy;
for(iy=0;iy<5;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  dJydx[it+0*nt] += dydx[0]*1.0/(sd_y[0]*sd_y[0])*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1-dydx[2]*1.0/(sd_y[2]*sd_y[2])*(my[it+nt*2]*2.0-y[it+nt*2]*2.0)*5.0E-1-dydx[3]*1.0/(sd_y[3]*sd_y[3])*(my[it+nt*3]*2.0-y[it+nt*3]*2.0)*5.0E-1-dydx[4]*1.0/(sd_y[4]*sd_y[4])*(my[it+nt*4]*2.0-y[it+nt*4]*2.0)*5.0E-1;
  dJydx[it+1*nt] += dydx[6]*1.0/(sd_y[1]*sd_y[1])*(my[it+nt*1]*2.0-y[it+nt*1]*2.0)*-5.0E-1-dydx[7]*1.0/(sd_y[2]*sd_y[2])*(my[it+nt*2]*2.0-y[it+nt*2]*2.0)*5.0E-1-dydx[8]*1.0/(sd_y[3]*sd_y[3])*(my[it+nt*3]*2.0-y[it+nt*3]*2.0)*5.0E-1-dydx[9]*1.0/(sd_y[4]*sd_y[4])*(my[it+nt*4]*2.0-y[it+nt*4]*2.0)*5.0E-1;
  dJydx[it+2*nt] += dydx[12]*1.0/(sd_y[2]*sd_y[2])*(my[it+nt*2]*2.0-y[it+nt*2]*2.0)*-5.0E-1;
  dJydx[it+3*nt] += dydx[18]*1.0/(sd_y[3]*sd_y[3])*(my[it+nt*3]*2.0-y[it+nt*3]*2.0)*-5.0E-1-dydx[19]*1.0/(sd_y[4]*sd_y[4])*(my[it+nt*4]*2.0-y[it+nt*4]*2.0)*5.0E-1;
  dJydx[it+4*nt] += dydx[22]*1.0/(sd_y[2]*sd_y[2])*(my[it+nt*2]*2.0-y[it+nt*2]*2.0)*-5.0E-1;
  dJydx[it+5*nt] += dydx[28]*1.0/(sd_y[3]*sd_y[3])*(my[it+nt*3]*2.0-y[it+nt*3]*2.0)*-5.0E-1-dydx[29]*1.0/(sd_y[4]*sd_y[4])*(my[it+nt*4]*2.0-y[it+nt*4]*2.0)*5.0E-1;
return(0);

}


