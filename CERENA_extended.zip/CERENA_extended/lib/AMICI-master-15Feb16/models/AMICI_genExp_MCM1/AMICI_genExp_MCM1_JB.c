
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int JB_AMICI_genExp_MCM1(long int NeqBdot, realtype t, realtype cj, N_Vector x, N_Vector dx, N_Vector xB, N_Vector dxB, N_Vector xBdot, DlsMat JB, void *user_data, N_Vector tmp1B, N_Vector tmp2B, N_Vector tmp3B) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *dx_tmp = N_VGetArrayPointer(dx);
realtype *xB_tmp = N_VGetArrayPointer(xB);
realtype *dxB_tmp = N_VGetArrayPointer(dxB);
realtype *xBdot_tmp = N_VGetArrayPointer(xBdot);
  memset(JB->data,0,sizeof(realtype)*36);
  JB->data[0] = cj+p[0]+k[0]*p[6]*x_tmp[3];
  JB->data[1] = -p[1];
  JB->data[3] = k[0]*p[6]*x_tmp[0];
  JB->data[6] = -p[0]-k[0]*p[6]*x_tmp[3];
  JB->data[7] = cj+p[1];
  JB->data[9] = -k[0]*p[6]*x_tmp[0];
  JB->data[12] = dx_tmp[2]+p[3]*x_tmp[2];
  JB->data[13] = p[1]*x_tmp[2]-p[1]*x_tmp[4];
  JB->data[14] = cj*x_tmp[0]+p[1]*x_tmp[1]+p[3]*x_tmp[0];
  JB->data[16] = -p[1]*x_tmp[1];
  JB->data[18] = dx_tmp[3]+p[5]*x_tmp[3]-p[4]*t*x_tmp[2];
  JB->data[19] = p[1]*x_tmp[3]-p[1]*x_tmp[5];
  JB->data[20] = -p[4]*t*x_tmp[0];
  JB->data[21] = cj*x_tmp[0]+p[1]*x_tmp[1]+p[5]*x_tmp[0];
  JB->data[23] = -p[1]*x_tmp[1];
  JB->data[24] = -(k[0]*p[0]*x_tmp[2]-k[0]*p[0]*x_tmp[4]+(k[0]*k[0])*p[6]*x_tmp[2]*x_tmp[3]-(k[0]*k[0])*p[6]*x_tmp[3]*x_tmp[4])/k[0];
  JB->data[25] = dx_tmp[4]-(p[2]-k[0]*p[3]*x_tmp[4])/k[0];
  JB->data[26] = -(k[0]*p[0]*x_tmp[0]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3])/k[0];
  JB->data[27] = -((k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[2]-(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[4])/k[0];
  JB->data[28] = cj*x_tmp[1]+(k[0]*p[0]*x_tmp[0]+k[0]*p[3]*x_tmp[1]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3])/k[0];
  JB->data[30] = -p[0]*x_tmp[3]+p[0]*x_tmp[5]-k[0]*p[6]*(x_tmp[3]*x_tmp[3])+k[0]*p[6]*x_tmp[3]*x_tmp[5];
  JB->data[31] = dx_tmp[5]+p[5]*x_tmp[5]-p[4]*t*x_tmp[4];
  JB->data[33] = -p[0]*x_tmp[0]-k[0]*p[6]*x_tmp[0]*x_tmp[3]*2.0+k[0]*p[6]*x_tmp[0]*x_tmp[5];
  JB->data[34] = -p[4]*t*x_tmp[1];
  JB->data[35] = cj*x_tmp[1]+p[0]*x_tmp[0]+p[5]*x_tmp[1]+k[0]*p[6]*x_tmp[0]*x_tmp[3];
return(0);

}


