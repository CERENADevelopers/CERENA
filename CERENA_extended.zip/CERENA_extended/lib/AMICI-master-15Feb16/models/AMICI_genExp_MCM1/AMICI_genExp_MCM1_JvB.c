
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int JvB_AMICI_genExp_MCM1(realtype t, N_Vector x, N_Vector dx, N_Vector xB, N_Vector dxB, N_Vector xBdot, N_Vector vB, N_Vector JvB, realtype cj, void *user_data, N_Vector tmpB1, N_Vector tmpB2) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *dx_tmp = N_VGetArrayPointer(dx);
realtype *xB_tmp = N_VGetArrayPointer(xB);
realtype *dxB_tmp = N_VGetArrayPointer(dxB);
realtype *xBdot_tmp = N_VGetArrayPointer(xBdot);
realtype *vB_tmp = N_VGetArrayPointer(vB);
realtype *JvB_tmp = N_VGetArrayPointer(JvB);
memset(JvB_tmp,0,sizeof(realtype)*6);
  JvB_tmp[0] = -vB_tmp[5]*(p[0]*x_tmp[3]-p[0]*x_tmp[5]+k[0]*p[6]*(x_tmp[3]*x_tmp[3])-k[0]*p[6]*x_tmp[3]*x_tmp[5])-vB_tmp[1]*(p[0]+k[0]*p[6]*x_tmp[3])+vB_tmp[3]*(dx_tmp[3]+p[5]*x_tmp[3]-p[4]*t*x_tmp[2])+vB_tmp[0]*(cj+p[0]+k[0]*p[6]*x_tmp[3])+vB_tmp[2]*(dx_tmp[2]+p[3]*x_tmp[2])-(vB_tmp[4]*(k[0]*p[0]*x_tmp[2]-k[0]*p[0]*x_tmp[4]+(k[0]*k[0])*p[6]*x_tmp[2]*x_tmp[3]-(k[0]*k[0])*p[6]*x_tmp[3]*x_tmp[4]))/k[0];
  JvB_tmp[1] = vB_tmp[1]*(cj+p[1])-p[1]*vB_tmp[0]+vB_tmp[4]*(dx_tmp[4]-(p[2]-k[0]*p[3]*x_tmp[4])/k[0])+vB_tmp[5]*(dx_tmp[5]+p[5]*x_tmp[5]-p[4]*t*x_tmp[4])+vB_tmp[2]*(p[1]*x_tmp[2]-p[1]*x_tmp[4])+vB_tmp[3]*(p[1]*x_tmp[3]-p[1]*x_tmp[5]);
  JvB_tmp[2] = vB_tmp[2]*(cj*x_tmp[0]+p[1]*x_tmp[1]+p[3]*x_tmp[0])-(vB_tmp[4]*(k[0]*p[0]*x_tmp[0]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]))/k[0]-p[4]*t*vB_tmp[3]*x_tmp[0];
  JvB_tmp[3] = vB_tmp[3]*(cj*x_tmp[0]+p[1]*x_tmp[1]+p[5]*x_tmp[0])-vB_tmp[5]*(p[0]*x_tmp[0]+k[0]*p[6]*x_tmp[0]*x_tmp[3]*2.0-k[0]*p[6]*x_tmp[0]*x_tmp[5])-(vB_tmp[4]*((k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[2]-(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[4]))/k[0]+k[0]*p[6]*vB_tmp[0]*x_tmp[0]-k[0]*p[6]*vB_tmp[1]*x_tmp[0];
  JvB_tmp[4] = vB_tmp[4]*(cj*x_tmp[1]+(k[0]*p[0]*x_tmp[0]+k[0]*p[3]*x_tmp[1]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3])/k[0])-p[1]*vB_tmp[2]*x_tmp[1]-p[4]*t*vB_tmp[5]*x_tmp[1];
  JvB_tmp[5] = vB_tmp[5]*(cj*x_tmp[1]+p[0]*x_tmp[0]+p[5]*x_tmp[1]+k[0]*p[6]*x_tmp[0]*x_tmp[3])-p[1]*vB_tmp[3]*x_tmp[1];
return(0);

}


