
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int JSparse_AMICI_genExp_MCM1(realtype t, realtype cj, N_Vector x, N_Vector dx, N_Vector xdot, SlsMat J, void *user_data, N_Vector tmp1, N_Vector tmp2, N_Vector tmp3) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *dx_tmp = N_VGetArrayPointer(dx);
realtype *xdot_tmp = N_VGetArrayPointer(xdot);
SlsSetToZero(J);
J->rowvals[0] = 0;
J->rowvals[1] = 1;
J->rowvals[2] = 2;
J->rowvals[3] = 3;
J->rowvals[4] = 4;
J->rowvals[5] = 5;
J->rowvals[6] = 0;
J->rowvals[7] = 1;
J->rowvals[8] = 2;
J->rowvals[9] = 3;
J->rowvals[10] = 4;
J->rowvals[11] = 5;
J->rowvals[12] = 2;
J->rowvals[13] = 3;
J->rowvals[14] = 4;
J->rowvals[15] = 0;
J->rowvals[16] = 1;
J->rowvals[17] = 3;
J->rowvals[18] = 4;
J->rowvals[19] = 5;
J->rowvals[20] = 2;
J->rowvals[21] = 4;
J->rowvals[22] = 5;
J->rowvals[23] = 3;
J->rowvals[24] = 5;
J->colptrs[0] = 0;
J->colptrs[1] = 6;
J->colptrs[2] = 12;
J->colptrs[3] = 15;
J->colptrs[4] = 20;
J->colptrs[5] = 23;
J->colptrs[6] = 25;
  J->data[0] = -cj-p[0]-k[0]*p[6]*x_tmp[3];
  J->data[1] = p[0]+k[0]*p[6]*x_tmp[3];
  J->data[2] = -dx_tmp[2]-p[3]*x_tmp[2];
  J->data[3] = -dx_tmp[3]-p[5]*x_tmp[3]+p[4]*t*x_tmp[2];
  J->data[4] = (k[0]*p[0]*x_tmp[2]-k[0]*p[0]*x_tmp[4]+(k[0]*k[0])*p[6]*x_tmp[2]*x_tmp[3]-(k[0]*k[0])*p[6]*x_tmp[3]*x_tmp[4])/k[0];
  J->data[5] = p[0]*x_tmp[3]-p[0]*x_tmp[5]+k[0]*p[6]*(x_tmp[3]*x_tmp[3])-k[0]*p[6]*x_tmp[3]*x_tmp[5];
  J->data[6] = p[1];
  J->data[7] = -cj-p[1];
  J->data[8] = -p[1]*x_tmp[2]+p[1]*x_tmp[4];
  J->data[9] = -p[1]*x_tmp[3]+p[1]*x_tmp[5];
  J->data[10] = -dx_tmp[4]+(p[2]-k[0]*p[3]*x_tmp[4])/k[0];
  J->data[11] = -dx_tmp[5]-p[5]*x_tmp[5]+p[4]*t*x_tmp[4];
  J->data[12] = -cj*x_tmp[0]-p[1]*x_tmp[1]-p[3]*x_tmp[0];
  J->data[13] = p[4]*t*x_tmp[0];
  J->data[14] = (k[0]*p[0]*x_tmp[0]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3])/k[0];
  J->data[15] = -k[0]*p[6]*x_tmp[0];
  J->data[16] = k[0]*p[6]*x_tmp[0];
  J->data[17] = -cj*x_tmp[0]-p[1]*x_tmp[1]-p[5]*x_tmp[0];
  J->data[18] = ((k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[2]-(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[4])/k[0];
  J->data[19] = p[0]*x_tmp[0]+k[0]*p[6]*x_tmp[0]*x_tmp[3]*2.0-k[0]*p[6]*x_tmp[0]*x_tmp[5];
  J->data[20] = p[1]*x_tmp[1];
  J->data[21] = -cj*x_tmp[1]-(k[0]*p[0]*x_tmp[0]+k[0]*p[3]*x_tmp[1]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3])/k[0];
  J->data[22] = p[4]*t*x_tmp[1];
  J->data[23] = p[1]*x_tmp[1];
  J->data[24] = -cj*x_tmp[1]-p[0]*x_tmp[0]-p[5]*x_tmp[1]-k[0]*p[6]*x_tmp[0]*x_tmp[3];
int inz;
for(inz = 0; inz<25; inz++) {
   if(mxIsNaN(J->data[inz])) {
       J->data[inz] = 0;       if(!udata->am_nan_JSparse) {
           mexWarnMsgIdAndTxt("AMICI:mex:fJ:NaN","AMICI replaced a NaN value in Jacobian and replaced it by 0.0. This will not be reported again for this simulation run.");           udata->am_nan_JSparse = TRUE;
       }
   }   if(mxIsInf(J->data[inz])) {
       mexWarnMsgIdAndTxt("AMICI:mex:fJ:Inf","AMICI encountered an Inf value in Jacobian! Aborting simulation ... ");       return(-1);   }}
return(0);

}


