#ifndef _am_AMICI_genExp_MCM1_dsigma_ydp_h
#define _am_AMICI_genExp_MCM1_dsigma_ydp_h

int dsigma_ydp_AMICI_genExp_MCM1(realtype t, realtype *dsigma_ydp, void *user_data);


#endif /* _am_AMICI_genExp_MCM1_dsigma_ydp_h */
