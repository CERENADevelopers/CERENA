
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>
#include "AMICI_genExp_MCM1_JSparse.h"
#include "AMICI_genExp_MCM1_dxdotdp.h"

int sxdot_AMICI_genExp_MCM1(int Ns, realtype t, N_Vector x, N_Vector dx, N_Vector xdot, N_Vector *sx, N_Vector *sdx, N_Vector *sxdot, void *user_data, N_Vector tmp1, N_Vector tmp2, N_Vector tmp3) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *dx_tmp = N_VGetArrayPointer(dx);
realtype *sx_tmp;
realtype *sdx_tmp;
realtype *sxdot_tmp;
realtype *xdot_tmp = N_VGetArrayPointer(xdot);
int status = 0;
int ip;
for(ip = 0; ip<np; ip++) {
realtype *sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
realtype *sdx_tmp = N_VGetArrayPointer(sdx[plist[ip]]);
realtype *sxdot_tmp = N_VGetArrayPointer(sxdot[plist[ip]]);
memset(sxdot_tmp,0,sizeof(realtype)*6);
switch (plist[ip]) {
  case 0: {
  sxdot_tmp[0] = -sdx_tmp[0]-x_tmp[0]+p[1]*sx_tmp[1]-sx_tmp[0]*(p[0]+k[0]*p[6]*x_tmp[3])-k[0]*p[6]*sx_tmp[3]*x_tmp[0];
  sxdot_tmp[1] = -sdx_tmp[1]+x_tmp[0]-p[1]*sx_tmp[1]+sx_tmp[0]*(p[0]+k[0]*p[6]*x_tmp[3])+k[0]*p[6]*sx_tmp[3]*x_tmp[0];
  sxdot_tmp[2] = -sdx_tmp[2]*x_tmp[0]-sx_tmp[2]*(p[1]*x_tmp[1]+p[3]*x_tmp[0])-sx_tmp[1]*(p[1]*x_tmp[2]-p[1]*x_tmp[4])-sx_tmp[0]*(dx_tmp[2]+p[3]*x_tmp[2])+p[1]*sx_tmp[4]*x_tmp[1];
  sxdot_tmp[3] = -sdx_tmp[3]*x_tmp[0]-sx_tmp[0]*(dx_tmp[3]+p[5]*x_tmp[3]-p[4]*t*x_tmp[2])-sx_tmp[3]*(p[1]*x_tmp[1]+p[5]*x_tmp[0])-sx_tmp[1]*(p[1]*x_tmp[3]-p[1]*x_tmp[5])+p[1]*sx_tmp[5]*x_tmp[1]+p[4]*sx_tmp[2]*t*x_tmp[0];
  sxdot_tmp[4] = (k[0]*x_tmp[0]*x_tmp[2]-k[0]*x_tmp[0]*x_tmp[4])/k[0]-sx_tmp[1]*(dx_tmp[4]-(p[2]-k[0]*p[3]*x_tmp[4])/k[0])-sdx_tmp[4]*x_tmp[1]+(sx_tmp[3]*((k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[2]-(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[4]))/k[0]+(sx_tmp[2]*(k[0]*p[0]*x_tmp[0]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]))/k[0]+(sx_tmp[0]*(k[0]*p[0]*x_tmp[2]-k[0]*p[0]*x_tmp[4]+(k[0]*k[0])*p[6]*x_tmp[2]*x_tmp[3]-(k[0]*k[0])*p[6]*x_tmp[3]*x_tmp[4]))/k[0]-(sx_tmp[4]*(k[0]*p[0]*x_tmp[0]+k[0]*p[3]*x_tmp[1]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]))/k[0];
  sxdot_tmp[5] = sx_tmp[0]*(p[0]*x_tmp[3]-p[0]*x_tmp[5]+k[0]*p[6]*(x_tmp[3]*x_tmp[3])-k[0]*p[6]*x_tmp[3]*x_tmp[5])-sdx_tmp[5]*x_tmp[1]+x_tmp[0]*x_tmp[3]-x_tmp[0]*x_tmp[5]-sx_tmp[1]*(dx_tmp[5]+p[5]*x_tmp[5]-p[4]*t*x_tmp[4])+sx_tmp[3]*(p[0]*x_tmp[0]+k[0]*p[6]*x_tmp[0]*x_tmp[3]*2.0-k[0]*p[6]*x_tmp[0]*x_tmp[5])-sx_tmp[5]*(p[0]*x_tmp[0]+p[5]*x_tmp[1]+k[0]*p[6]*x_tmp[0]*x_tmp[3])+p[4]*sx_tmp[4]*t*x_tmp[1];

  } break;

  case 1: {
  sxdot_tmp[0] = -sdx_tmp[0]+x_tmp[1]+p[1]*sx_tmp[1]-sx_tmp[0]*(p[0]+k[0]*p[6]*x_tmp[3])-k[0]*p[6]*sx_tmp[3]*x_tmp[0];
  sxdot_tmp[1] = -sdx_tmp[1]-x_tmp[1]-p[1]*sx_tmp[1]+sx_tmp[0]*(p[0]+k[0]*p[6]*x_tmp[3])+k[0]*p[6]*sx_tmp[3]*x_tmp[0];
  sxdot_tmp[2] = -sdx_tmp[2]*x_tmp[0]-x_tmp[1]*x_tmp[2]+x_tmp[1]*x_tmp[4]-sx_tmp[2]*(p[1]*x_tmp[1]+p[3]*x_tmp[0])-sx_tmp[1]*(p[1]*x_tmp[2]-p[1]*x_tmp[4])-sx_tmp[0]*(dx_tmp[2]+p[3]*x_tmp[2])+p[1]*sx_tmp[4]*x_tmp[1];
  sxdot_tmp[3] = -sdx_tmp[3]*x_tmp[0]-x_tmp[1]*x_tmp[3]+x_tmp[1]*x_tmp[5]-sx_tmp[0]*(dx_tmp[3]+p[5]*x_tmp[3]-p[4]*t*x_tmp[2])-sx_tmp[3]*(p[1]*x_tmp[1]+p[5]*x_tmp[0])-sx_tmp[1]*(p[1]*x_tmp[3]-p[1]*x_tmp[5])+p[1]*sx_tmp[5]*x_tmp[1]+p[4]*sx_tmp[2]*t*x_tmp[0];
  sxdot_tmp[4] = -sx_tmp[1]*(dx_tmp[4]-(p[2]-k[0]*p[3]*x_tmp[4])/k[0])-sdx_tmp[4]*x_tmp[1]+(sx_tmp[3]*((k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[2]-(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[4]))/k[0]+(sx_tmp[2]*(k[0]*p[0]*x_tmp[0]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]))/k[0]+(sx_tmp[0]*(k[0]*p[0]*x_tmp[2]-k[0]*p[0]*x_tmp[4]+(k[0]*k[0])*p[6]*x_tmp[2]*x_tmp[3]-(k[0]*k[0])*p[6]*x_tmp[3]*x_tmp[4]))/k[0]-(sx_tmp[4]*(k[0]*p[0]*x_tmp[0]+k[0]*p[3]*x_tmp[1]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]))/k[0];
  sxdot_tmp[5] = sx_tmp[0]*(p[0]*x_tmp[3]-p[0]*x_tmp[5]+k[0]*p[6]*(x_tmp[3]*x_tmp[3])-k[0]*p[6]*x_tmp[3]*x_tmp[5])-sdx_tmp[5]*x_tmp[1]-sx_tmp[1]*(dx_tmp[5]+p[5]*x_tmp[5]-p[4]*t*x_tmp[4])+sx_tmp[3]*(p[0]*x_tmp[0]+k[0]*p[6]*x_tmp[0]*x_tmp[3]*2.0-k[0]*p[6]*x_tmp[0]*x_tmp[5])-sx_tmp[5]*(p[0]*x_tmp[0]+p[5]*x_tmp[1]+k[0]*p[6]*x_tmp[0]*x_tmp[3])+p[4]*sx_tmp[4]*t*x_tmp[1];

  } break;

  case 2: {
  sxdot_tmp[0] = -sdx_tmp[0]+p[1]*sx_tmp[1]-sx_tmp[0]*(p[0]+k[0]*p[6]*x_tmp[3])-k[0]*p[6]*sx_tmp[3]*x_tmp[0];
  sxdot_tmp[1] = -sdx_tmp[1]-p[1]*sx_tmp[1]+sx_tmp[0]*(p[0]+k[0]*p[6]*x_tmp[3])+k[0]*p[6]*sx_tmp[3]*x_tmp[0];
  sxdot_tmp[2] = -sdx_tmp[2]*x_tmp[0]-sx_tmp[2]*(p[1]*x_tmp[1]+p[3]*x_tmp[0])-sx_tmp[1]*(p[1]*x_tmp[2]-p[1]*x_tmp[4])-sx_tmp[0]*(dx_tmp[2]+p[3]*x_tmp[2])+p[1]*sx_tmp[4]*x_tmp[1];
  sxdot_tmp[3] = -sdx_tmp[3]*x_tmp[0]-sx_tmp[0]*(dx_tmp[3]+p[5]*x_tmp[3]-p[4]*t*x_tmp[2])-sx_tmp[3]*(p[1]*x_tmp[1]+p[5]*x_tmp[0])-sx_tmp[1]*(p[1]*x_tmp[3]-p[1]*x_tmp[5])+p[1]*sx_tmp[5]*x_tmp[1]+p[4]*sx_tmp[2]*t*x_tmp[0];
  sxdot_tmp[4] = -sx_tmp[1]*(dx_tmp[4]-(p[2]-k[0]*p[3]*x_tmp[4])/k[0])-sdx_tmp[4]*x_tmp[1]+x_tmp[1]/k[0]+(sx_tmp[3]*((k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[2]-(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[4]))/k[0]+(sx_tmp[2]*(k[0]*p[0]*x_tmp[0]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]))/k[0]+(sx_tmp[0]*(k[0]*p[0]*x_tmp[2]-k[0]*p[0]*x_tmp[4]+(k[0]*k[0])*p[6]*x_tmp[2]*x_tmp[3]-(k[0]*k[0])*p[6]*x_tmp[3]*x_tmp[4]))/k[0]-(sx_tmp[4]*(k[0]*p[0]*x_tmp[0]+k[0]*p[3]*x_tmp[1]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]))/k[0];
  sxdot_tmp[5] = sx_tmp[0]*(p[0]*x_tmp[3]-p[0]*x_tmp[5]+k[0]*p[6]*(x_tmp[3]*x_tmp[3])-k[0]*p[6]*x_tmp[3]*x_tmp[5])-sdx_tmp[5]*x_tmp[1]-sx_tmp[1]*(dx_tmp[5]+p[5]*x_tmp[5]-p[4]*t*x_tmp[4])+sx_tmp[3]*(p[0]*x_tmp[0]+k[0]*p[6]*x_tmp[0]*x_tmp[3]*2.0-k[0]*p[6]*x_tmp[0]*x_tmp[5])-sx_tmp[5]*(p[0]*x_tmp[0]+p[5]*x_tmp[1]+k[0]*p[6]*x_tmp[0]*x_tmp[3])+p[4]*sx_tmp[4]*t*x_tmp[1];

  } break;

  case 3: {
  sxdot_tmp[0] = -sdx_tmp[0]+p[1]*sx_tmp[1]-sx_tmp[0]*(p[0]+k[0]*p[6]*x_tmp[3])-k[0]*p[6]*sx_tmp[3]*x_tmp[0];
  sxdot_tmp[1] = -sdx_tmp[1]-p[1]*sx_tmp[1]+sx_tmp[0]*(p[0]+k[0]*p[6]*x_tmp[3])+k[0]*p[6]*sx_tmp[3]*x_tmp[0];
  sxdot_tmp[2] = -sdx_tmp[2]*x_tmp[0]-x_tmp[0]*x_tmp[2]-sx_tmp[2]*(p[1]*x_tmp[1]+p[3]*x_tmp[0])-sx_tmp[1]*(p[1]*x_tmp[2]-p[1]*x_tmp[4])-sx_tmp[0]*(dx_tmp[2]+p[3]*x_tmp[2])+p[1]*sx_tmp[4]*x_tmp[1];
  sxdot_tmp[3] = -sdx_tmp[3]*x_tmp[0]-sx_tmp[0]*(dx_tmp[3]+p[5]*x_tmp[3]-p[4]*t*x_tmp[2])-sx_tmp[3]*(p[1]*x_tmp[1]+p[5]*x_tmp[0])-sx_tmp[1]*(p[1]*x_tmp[3]-p[1]*x_tmp[5])+p[1]*sx_tmp[5]*x_tmp[1]+p[4]*sx_tmp[2]*t*x_tmp[0];
  sxdot_tmp[4] = -sx_tmp[1]*(dx_tmp[4]-(p[2]-k[0]*p[3]*x_tmp[4])/k[0])-sdx_tmp[4]*x_tmp[1]-x_tmp[1]*x_tmp[4]+(sx_tmp[3]*((k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[2]-(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[4]))/k[0]+(sx_tmp[2]*(k[0]*p[0]*x_tmp[0]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]))/k[0]+(sx_tmp[0]*(k[0]*p[0]*x_tmp[2]-k[0]*p[0]*x_tmp[4]+(k[0]*k[0])*p[6]*x_tmp[2]*x_tmp[3]-(k[0]*k[0])*p[6]*x_tmp[3]*x_tmp[4]))/k[0]-(sx_tmp[4]*(k[0]*p[0]*x_tmp[0]+k[0]*p[3]*x_tmp[1]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]))/k[0];
  sxdot_tmp[5] = sx_tmp[0]*(p[0]*x_tmp[3]-p[0]*x_tmp[5]+k[0]*p[6]*(x_tmp[3]*x_tmp[3])-k[0]*p[6]*x_tmp[3]*x_tmp[5])-sdx_tmp[5]*x_tmp[1]-sx_tmp[1]*(dx_tmp[5]+p[5]*x_tmp[5]-p[4]*t*x_tmp[4])+sx_tmp[3]*(p[0]*x_tmp[0]+k[0]*p[6]*x_tmp[0]*x_tmp[3]*2.0-k[0]*p[6]*x_tmp[0]*x_tmp[5])-sx_tmp[5]*(p[0]*x_tmp[0]+p[5]*x_tmp[1]+k[0]*p[6]*x_tmp[0]*x_tmp[3])+p[4]*sx_tmp[4]*t*x_tmp[1];

  } break;

  case 4: {
  sxdot_tmp[0] = -sdx_tmp[0]+p[1]*sx_tmp[1]-sx_tmp[0]*(p[0]+k[0]*p[6]*x_tmp[3])-k[0]*p[6]*sx_tmp[3]*x_tmp[0];
  sxdot_tmp[1] = -sdx_tmp[1]-p[1]*sx_tmp[1]+sx_tmp[0]*(p[0]+k[0]*p[6]*x_tmp[3])+k[0]*p[6]*sx_tmp[3]*x_tmp[0];
  sxdot_tmp[2] = -sdx_tmp[2]*x_tmp[0]-sx_tmp[2]*(p[1]*x_tmp[1]+p[3]*x_tmp[0])-sx_tmp[1]*(p[1]*x_tmp[2]-p[1]*x_tmp[4])-sx_tmp[0]*(dx_tmp[2]+p[3]*x_tmp[2])+p[1]*sx_tmp[4]*x_tmp[1];
  sxdot_tmp[3] = -sdx_tmp[3]*x_tmp[0]-sx_tmp[0]*(dx_tmp[3]+p[5]*x_tmp[3]-p[4]*t*x_tmp[2])-sx_tmp[3]*(p[1]*x_tmp[1]+p[5]*x_tmp[0])-sx_tmp[1]*(p[1]*x_tmp[3]-p[1]*x_tmp[5])+p[1]*sx_tmp[5]*x_tmp[1]+t*x_tmp[0]*x_tmp[2]+p[4]*sx_tmp[2]*t*x_tmp[0];
  sxdot_tmp[4] = -sx_tmp[1]*(dx_tmp[4]-(p[2]-k[0]*p[3]*x_tmp[4])/k[0])-sdx_tmp[4]*x_tmp[1]+(sx_tmp[3]*((k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[2]-(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[4]))/k[0]+(sx_tmp[2]*(k[0]*p[0]*x_tmp[0]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]))/k[0]+(sx_tmp[0]*(k[0]*p[0]*x_tmp[2]-k[0]*p[0]*x_tmp[4]+(k[0]*k[0])*p[6]*x_tmp[2]*x_tmp[3]-(k[0]*k[0])*p[6]*x_tmp[3]*x_tmp[4]))/k[0]-(sx_tmp[4]*(k[0]*p[0]*x_tmp[0]+k[0]*p[3]*x_tmp[1]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]))/k[0];
  sxdot_tmp[5] = sx_tmp[0]*(p[0]*x_tmp[3]-p[0]*x_tmp[5]+k[0]*p[6]*(x_tmp[3]*x_tmp[3])-k[0]*p[6]*x_tmp[3]*x_tmp[5])-sdx_tmp[5]*x_tmp[1]-sx_tmp[1]*(dx_tmp[5]+p[5]*x_tmp[5]-p[4]*t*x_tmp[4])+sx_tmp[3]*(p[0]*x_tmp[0]+k[0]*p[6]*x_tmp[0]*x_tmp[3]*2.0-k[0]*p[6]*x_tmp[0]*x_tmp[5])-sx_tmp[5]*(p[0]*x_tmp[0]+p[5]*x_tmp[1]+k[0]*p[6]*x_tmp[0]*x_tmp[3])+t*x_tmp[1]*x_tmp[4]+p[4]*sx_tmp[4]*t*x_tmp[1];

  } break;

  case 5: {
  sxdot_tmp[0] = -sdx_tmp[0]+p[1]*sx_tmp[1]-sx_tmp[0]*(p[0]+k[0]*p[6]*x_tmp[3])-k[0]*p[6]*sx_tmp[3]*x_tmp[0];
  sxdot_tmp[1] = -sdx_tmp[1]-p[1]*sx_tmp[1]+sx_tmp[0]*(p[0]+k[0]*p[6]*x_tmp[3])+k[0]*p[6]*sx_tmp[3]*x_tmp[0];
  sxdot_tmp[2] = -sdx_tmp[2]*x_tmp[0]-sx_tmp[2]*(p[1]*x_tmp[1]+p[3]*x_tmp[0])-sx_tmp[1]*(p[1]*x_tmp[2]-p[1]*x_tmp[4])-sx_tmp[0]*(dx_tmp[2]+p[3]*x_tmp[2])+p[1]*sx_tmp[4]*x_tmp[1];
  sxdot_tmp[3] = -sdx_tmp[3]*x_tmp[0]-x_tmp[0]*x_tmp[3]-sx_tmp[0]*(dx_tmp[3]+p[5]*x_tmp[3]-p[4]*t*x_tmp[2])-sx_tmp[3]*(p[1]*x_tmp[1]+p[5]*x_tmp[0])-sx_tmp[1]*(p[1]*x_tmp[3]-p[1]*x_tmp[5])+p[1]*sx_tmp[5]*x_tmp[1]+p[4]*sx_tmp[2]*t*x_tmp[0];
  sxdot_tmp[4] = -sx_tmp[1]*(dx_tmp[4]-(p[2]-k[0]*p[3]*x_tmp[4])/k[0])-sdx_tmp[4]*x_tmp[1]+(sx_tmp[3]*((k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[2]-(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[4]))/k[0]+(sx_tmp[2]*(k[0]*p[0]*x_tmp[0]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]))/k[0]+(sx_tmp[0]*(k[0]*p[0]*x_tmp[2]-k[0]*p[0]*x_tmp[4]+(k[0]*k[0])*p[6]*x_tmp[2]*x_tmp[3]-(k[0]*k[0])*p[6]*x_tmp[3]*x_tmp[4]))/k[0]-(sx_tmp[4]*(k[0]*p[0]*x_tmp[0]+k[0]*p[3]*x_tmp[1]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]))/k[0];
  sxdot_tmp[5] = sx_tmp[0]*(p[0]*x_tmp[3]-p[0]*x_tmp[5]+k[0]*p[6]*(x_tmp[3]*x_tmp[3])-k[0]*p[6]*x_tmp[3]*x_tmp[5])-sdx_tmp[5]*x_tmp[1]-x_tmp[1]*x_tmp[5]-sx_tmp[1]*(dx_tmp[5]+p[5]*x_tmp[5]-p[4]*t*x_tmp[4])+sx_tmp[3]*(p[0]*x_tmp[0]+k[0]*p[6]*x_tmp[0]*x_tmp[3]*2.0-k[0]*p[6]*x_tmp[0]*x_tmp[5])-sx_tmp[5]*(p[0]*x_tmp[0]+p[5]*x_tmp[1]+k[0]*p[6]*x_tmp[0]*x_tmp[3])+p[4]*sx_tmp[4]*t*x_tmp[1];

  } break;

  case 6: {
  sxdot_tmp[0] = -sdx_tmp[0]+p[1]*sx_tmp[1]-sx_tmp[0]*(p[0]+k[0]*p[6]*x_tmp[3])-k[0]*x_tmp[0]*x_tmp[3]-k[0]*p[6]*sx_tmp[3]*x_tmp[0];
  sxdot_tmp[1] = -sdx_tmp[1]-p[1]*sx_tmp[1]+sx_tmp[0]*(p[0]+k[0]*p[6]*x_tmp[3])+k[0]*x_tmp[0]*x_tmp[3]+k[0]*p[6]*sx_tmp[3]*x_tmp[0];
  sxdot_tmp[2] = -sdx_tmp[2]*x_tmp[0]-sx_tmp[2]*(p[1]*x_tmp[1]+p[3]*x_tmp[0])-sx_tmp[1]*(p[1]*x_tmp[2]-p[1]*x_tmp[4])-sx_tmp[0]*(dx_tmp[2]+p[3]*x_tmp[2])+p[1]*sx_tmp[4]*x_tmp[1];
  sxdot_tmp[3] = -sdx_tmp[3]*x_tmp[0]-sx_tmp[0]*(dx_tmp[3]+p[5]*x_tmp[3]-p[4]*t*x_tmp[2])-sx_tmp[3]*(p[1]*x_tmp[1]+p[5]*x_tmp[0])-sx_tmp[1]*(p[1]*x_tmp[3]-p[1]*x_tmp[5])+p[1]*sx_tmp[5]*x_tmp[1]+p[4]*sx_tmp[2]*t*x_tmp[0];
  sxdot_tmp[4] = -sx_tmp[1]*(dx_tmp[4]-(p[2]-k[0]*p[3]*x_tmp[4])/k[0])-sdx_tmp[4]*x_tmp[1]+((k[0]*k[0])*x_tmp[0]*x_tmp[2]*x_tmp[3]-(k[0]*k[0])*x_tmp[0]*x_tmp[3]*x_tmp[4])/k[0]+(sx_tmp[3]*((k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[2]-(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[4]))/k[0]+(sx_tmp[2]*(k[0]*p[0]*x_tmp[0]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]))/k[0]+(sx_tmp[0]*(k[0]*p[0]*x_tmp[2]-k[0]*p[0]*x_tmp[4]+(k[0]*k[0])*p[6]*x_tmp[2]*x_tmp[3]-(k[0]*k[0])*p[6]*x_tmp[3]*x_tmp[4]))/k[0]-(sx_tmp[4]*(k[0]*p[0]*x_tmp[0]+k[0]*p[3]*x_tmp[1]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]))/k[0];
  sxdot_tmp[5] = sx_tmp[0]*(p[0]*x_tmp[3]-p[0]*x_tmp[5]+k[0]*p[6]*(x_tmp[3]*x_tmp[3])-k[0]*p[6]*x_tmp[3]*x_tmp[5])-sdx_tmp[5]*x_tmp[1]-sx_tmp[1]*(dx_tmp[5]+p[5]*x_tmp[5]-p[4]*t*x_tmp[4])+sx_tmp[3]*(p[0]*x_tmp[0]+k[0]*p[6]*x_tmp[0]*x_tmp[3]*2.0-k[0]*p[6]*x_tmp[0]*x_tmp[5])-sx_tmp[5]*(p[0]*x_tmp[0]+p[5]*x_tmp[1]+k[0]*p[6]*x_tmp[0]*x_tmp[3])+k[0]*x_tmp[0]*(x_tmp[3]*x_tmp[3])+p[4]*sx_tmp[4]*t*x_tmp[1]-k[0]*x_tmp[0]*x_tmp[3]*x_tmp[5];

  } break;

  case 7: {
  sxdot_tmp[0] = -sdx_tmp[0]+p[1]*sx_tmp[1]-sx_tmp[0]*(p[0]+k[0]*p[6]*x_tmp[3])-k[0]*p[6]*sx_tmp[3]*x_tmp[0];
  sxdot_tmp[1] = -sdx_tmp[1]-p[1]*sx_tmp[1]+sx_tmp[0]*(p[0]+k[0]*p[6]*x_tmp[3])+k[0]*p[6]*sx_tmp[3]*x_tmp[0];
  sxdot_tmp[2] = -sdx_tmp[2]*x_tmp[0]-sx_tmp[2]*(p[1]*x_tmp[1]+p[3]*x_tmp[0])-sx_tmp[1]*(p[1]*x_tmp[2]-p[1]*x_tmp[4])-sx_tmp[0]*(dx_tmp[2]+p[3]*x_tmp[2])+p[1]*sx_tmp[4]*x_tmp[1];
  sxdot_tmp[3] = -sdx_tmp[3]*x_tmp[0]-sx_tmp[0]*(dx_tmp[3]+p[5]*x_tmp[3]-p[4]*t*x_tmp[2])-sx_tmp[3]*(p[1]*x_tmp[1]+p[5]*x_tmp[0])-sx_tmp[1]*(p[1]*x_tmp[3]-p[1]*x_tmp[5])+p[1]*sx_tmp[5]*x_tmp[1]+p[4]*sx_tmp[2]*t*x_tmp[0];
  sxdot_tmp[4] = -sx_tmp[1]*(dx_tmp[4]-(p[2]-k[0]*p[3]*x_tmp[4])/k[0])-sdx_tmp[4]*x_tmp[1]+(sx_tmp[3]*((k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[2]-(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[4]))/k[0]+(sx_tmp[2]*(k[0]*p[0]*x_tmp[0]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]))/k[0]+(sx_tmp[0]*(k[0]*p[0]*x_tmp[2]-k[0]*p[0]*x_tmp[4]+(k[0]*k[0])*p[6]*x_tmp[2]*x_tmp[3]-(k[0]*k[0])*p[6]*x_tmp[3]*x_tmp[4]))/k[0]-(sx_tmp[4]*(k[0]*p[0]*x_tmp[0]+k[0]*p[3]*x_tmp[1]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]))/k[0];
  sxdot_tmp[5] = sx_tmp[0]*(p[0]*x_tmp[3]-p[0]*x_tmp[5]+k[0]*p[6]*(x_tmp[3]*x_tmp[3])-k[0]*p[6]*x_tmp[3]*x_tmp[5])-sdx_tmp[5]*x_tmp[1]-sx_tmp[1]*(dx_tmp[5]+p[5]*x_tmp[5]-p[4]*t*x_tmp[4])+sx_tmp[3]*(p[0]*x_tmp[0]+k[0]*p[6]*x_tmp[0]*x_tmp[3]*2.0-k[0]*p[6]*x_tmp[0]*x_tmp[5])-sx_tmp[5]*(p[0]*x_tmp[0]+p[5]*x_tmp[1]+k[0]*p[6]*x_tmp[0]*x_tmp[3])+p[4]*sx_tmp[4]*t*x_tmp[1];

  } break;

  case 8: {
  sxdot_tmp[0] = -sdx_tmp[0]+p[1]*sx_tmp[1]-sx_tmp[0]*(p[0]+k[0]*p[6]*x_tmp[3])-k[0]*p[6]*sx_tmp[3]*x_tmp[0];
  sxdot_tmp[1] = -sdx_tmp[1]-p[1]*sx_tmp[1]+sx_tmp[0]*(p[0]+k[0]*p[6]*x_tmp[3])+k[0]*p[6]*sx_tmp[3]*x_tmp[0];
  sxdot_tmp[2] = -sdx_tmp[2]*x_tmp[0]-sx_tmp[2]*(p[1]*x_tmp[1]+p[3]*x_tmp[0])-sx_tmp[1]*(p[1]*x_tmp[2]-p[1]*x_tmp[4])-sx_tmp[0]*(dx_tmp[2]+p[3]*x_tmp[2])+p[1]*sx_tmp[4]*x_tmp[1];
  sxdot_tmp[3] = -sdx_tmp[3]*x_tmp[0]-sx_tmp[0]*(dx_tmp[3]+p[5]*x_tmp[3]-p[4]*t*x_tmp[2])-sx_tmp[3]*(p[1]*x_tmp[1]+p[5]*x_tmp[0])-sx_tmp[1]*(p[1]*x_tmp[3]-p[1]*x_tmp[5])+p[1]*sx_tmp[5]*x_tmp[1]+p[4]*sx_tmp[2]*t*x_tmp[0];
  sxdot_tmp[4] = -sx_tmp[1]*(dx_tmp[4]-(p[2]-k[0]*p[3]*x_tmp[4])/k[0])-sdx_tmp[4]*x_tmp[1]+(sx_tmp[3]*((k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[2]-(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[4]))/k[0]+(sx_tmp[2]*(k[0]*p[0]*x_tmp[0]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]))/k[0]+(sx_tmp[0]*(k[0]*p[0]*x_tmp[2]-k[0]*p[0]*x_tmp[4]+(k[0]*k[0])*p[6]*x_tmp[2]*x_tmp[3]-(k[0]*k[0])*p[6]*x_tmp[3]*x_tmp[4]))/k[0]-(sx_tmp[4]*(k[0]*p[0]*x_tmp[0]+k[0]*p[3]*x_tmp[1]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]))/k[0];
  sxdot_tmp[5] = sx_tmp[0]*(p[0]*x_tmp[3]-p[0]*x_tmp[5]+k[0]*p[6]*(x_tmp[3]*x_tmp[3])-k[0]*p[6]*x_tmp[3]*x_tmp[5])-sdx_tmp[5]*x_tmp[1]-sx_tmp[1]*(dx_tmp[5]+p[5]*x_tmp[5]-p[4]*t*x_tmp[4])+sx_tmp[3]*(p[0]*x_tmp[0]+k[0]*p[6]*x_tmp[0]*x_tmp[3]*2.0-k[0]*p[6]*x_tmp[0]*x_tmp[5])-sx_tmp[5]*(p[0]*x_tmp[0]+p[5]*x_tmp[1]+k[0]*p[6]*x_tmp[0]*x_tmp[3])+p[4]*sx_tmp[4]*t*x_tmp[1];

  } break;

  case 9: {
  sxdot_tmp[0] = -sdx_tmp[0]+p[1]*sx_tmp[1]-sx_tmp[0]*(p[0]+k[0]*p[6]*x_tmp[3])-k[0]*p[6]*sx_tmp[3]*x_tmp[0];
  sxdot_tmp[1] = -sdx_tmp[1]-p[1]*sx_tmp[1]+sx_tmp[0]*(p[0]+k[0]*p[6]*x_tmp[3])+k[0]*p[6]*sx_tmp[3]*x_tmp[0];
  sxdot_tmp[2] = -sdx_tmp[2]*x_tmp[0]-sx_tmp[2]*(p[1]*x_tmp[1]+p[3]*x_tmp[0])-sx_tmp[1]*(p[1]*x_tmp[2]-p[1]*x_tmp[4])-sx_tmp[0]*(dx_tmp[2]+p[3]*x_tmp[2])+p[1]*sx_tmp[4]*x_tmp[1];
  sxdot_tmp[3] = -sdx_tmp[3]*x_tmp[0]-sx_tmp[0]*(dx_tmp[3]+p[5]*x_tmp[3]-p[4]*t*x_tmp[2])-sx_tmp[3]*(p[1]*x_tmp[1]+p[5]*x_tmp[0])-sx_tmp[1]*(p[1]*x_tmp[3]-p[1]*x_tmp[5])+p[1]*sx_tmp[5]*x_tmp[1]+p[4]*sx_tmp[2]*t*x_tmp[0];
  sxdot_tmp[4] = -sx_tmp[1]*(dx_tmp[4]-(p[2]-k[0]*p[3]*x_tmp[4])/k[0])-sdx_tmp[4]*x_tmp[1]+(sx_tmp[3]*((k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[2]-(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[4]))/k[0]+(sx_tmp[2]*(k[0]*p[0]*x_tmp[0]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]))/k[0]+(sx_tmp[0]*(k[0]*p[0]*x_tmp[2]-k[0]*p[0]*x_tmp[4]+(k[0]*k[0])*p[6]*x_tmp[2]*x_tmp[3]-(k[0]*k[0])*p[6]*x_tmp[3]*x_tmp[4]))/k[0]-(sx_tmp[4]*(k[0]*p[0]*x_tmp[0]+k[0]*p[3]*x_tmp[1]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]))/k[0];
  sxdot_tmp[5] = sx_tmp[0]*(p[0]*x_tmp[3]-p[0]*x_tmp[5]+k[0]*p[6]*(x_tmp[3]*x_tmp[3])-k[0]*p[6]*x_tmp[3]*x_tmp[5])-sdx_tmp[5]*x_tmp[1]-sx_tmp[1]*(dx_tmp[5]+p[5]*x_tmp[5]-p[4]*t*x_tmp[4])+sx_tmp[3]*(p[0]*x_tmp[0]+k[0]*p[6]*x_tmp[0]*x_tmp[3]*2.0-k[0]*p[6]*x_tmp[0]*x_tmp[5])-sx_tmp[5]*(p[0]*x_tmp[0]+p[5]*x_tmp[1]+k[0]*p[6]*x_tmp[0]*x_tmp[3])+p[4]*sx_tmp[4]*t*x_tmp[1];

  } break;

}
}
return(status);

}


