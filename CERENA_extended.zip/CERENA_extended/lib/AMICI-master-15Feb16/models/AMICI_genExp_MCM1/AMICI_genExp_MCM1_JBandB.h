#ifndef _am_AMICI_genExp_MCM1_JBandB_h
#define _am_AMICI_genExp_MCM1_JBandB_h

int JBandB_AMICI_genExp_MCM1(long int NeqBdot, long int mupper, long int mlower, realtype t, realtype cj, N_Vector x, N_Vector dx, N_Vector xB, N_Vector dxB, N_Vector xBdot, DlsMat JB, void *user_data, N_Vector tmp1B, N_Vector tmp2B, N_Vector tmp3B);


#endif /* _am_AMICI_genExp_MCM1_JBandB_h */
