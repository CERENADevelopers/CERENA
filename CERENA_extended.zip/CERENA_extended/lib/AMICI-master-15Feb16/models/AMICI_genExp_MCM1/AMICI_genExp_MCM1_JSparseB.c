
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int JSparseB_AMICI_genExp_MCM1(realtype t, realtype cj, N_Vector x, N_Vector dx, N_Vector xB, N_Vector dxB, N_Vector xBdot, SlsMat JB, void *user_data, N_Vector tmp1B, N_Vector tmp2B, N_Vector tmp3B) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *dx_tmp = N_VGetArrayPointer(dx);
realtype *xB_tmp = N_VGetArrayPointer(xB);
realtype *dxB_tmp = N_VGetArrayPointer(dxB);
realtype *xBdot_tmp = N_VGetArrayPointer(xBdot);
  SlsSetToZero(JB);
  JB->rowvals[0] = 0;
  JB->rowvals[1] = 1;
  JB->rowvals[2] = 3;
  JB->rowvals[3] = 0;
  JB->rowvals[4] = 1;
  JB->rowvals[5] = 3;
  JB->rowvals[6] = 0;
  JB->rowvals[7] = 1;
  JB->rowvals[8] = 2;
  JB->rowvals[9] = 4;
  JB->rowvals[10] = 0;
  JB->rowvals[11] = 1;
  JB->rowvals[12] = 2;
  JB->rowvals[13] = 3;
  JB->rowvals[14] = 5;
  JB->rowvals[15] = 0;
  JB->rowvals[16] = 1;
  JB->rowvals[17] = 2;
  JB->rowvals[18] = 3;
  JB->rowvals[19] = 4;
  JB->rowvals[20] = 0;
  JB->rowvals[21] = 1;
  JB->rowvals[22] = 3;
  JB->rowvals[23] = 4;
  JB->rowvals[24] = 5;
  JB->colptrs[0] = 0;
  JB->colptrs[1] = 3;
  JB->colptrs[2] = 6;
  JB->colptrs[3] = 10;
  JB->colptrs[4] = 15;
  JB->colptrs[5] = 20;
  JB->colptrs[6] = 25;
  JB->data[0] = cj+p[0]+k[0]*p[6]*x_tmp[3];
  JB->data[1] = -p[1];
  JB->data[2] = k[0]*p[6]*x_tmp[0];
  JB->data[3] = -p[0]-k[0]*p[6]*x_tmp[3];
  JB->data[4] = cj+p[1];
  JB->data[5] = -k[0]*p[6]*x_tmp[0];
  JB->data[6] = dx_tmp[2]+p[3]*x_tmp[2];
  JB->data[7] = p[1]*x_tmp[2]-p[1]*x_tmp[4];
  JB->data[8] = cj*x_tmp[0]+p[1]*x_tmp[1]+p[3]*x_tmp[0];
  JB->data[9] = -p[1]*x_tmp[1];
  JB->data[10] = dx_tmp[3]+p[5]*x_tmp[3]-p[4]*t*x_tmp[2];
  JB->data[11] = p[1]*x_tmp[3]-p[1]*x_tmp[5];
  JB->data[12] = -p[4]*t*x_tmp[0];
  JB->data[13] = cj*x_tmp[0]+p[1]*x_tmp[1]+p[5]*x_tmp[0];
  JB->data[14] = -p[1]*x_tmp[1];
  JB->data[15] = -(k[0]*p[0]*x_tmp[2]-k[0]*p[0]*x_tmp[4]+(k[0]*k[0])*p[6]*x_tmp[2]*x_tmp[3]-(k[0]*k[0])*p[6]*x_tmp[3]*x_tmp[4])/k[0];
  JB->data[16] = dx_tmp[4]-(p[2]-k[0]*p[3]*x_tmp[4])/k[0];
  JB->data[17] = -(k[0]*p[0]*x_tmp[0]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3])/k[0];
  JB->data[18] = -((k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[2]-(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[4])/k[0];
  JB->data[19] = cj*x_tmp[1]+(k[0]*p[0]*x_tmp[0]+k[0]*p[3]*x_tmp[1]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3])/k[0];
  JB->data[20] = -p[0]*x_tmp[3]+p[0]*x_tmp[5]-k[0]*p[6]*(x_tmp[3]*x_tmp[3])+k[0]*p[6]*x_tmp[3]*x_tmp[5];
  JB->data[21] = dx_tmp[5]+p[5]*x_tmp[5]-p[4]*t*x_tmp[4];
  JB->data[22] = -p[0]*x_tmp[0]-k[0]*p[6]*x_tmp[0]*x_tmp[3]*2.0+k[0]*p[6]*x_tmp[0]*x_tmp[5];
  JB->data[23] = -p[4]*t*x_tmp[1];
  JB->data[24] = cj*x_tmp[1]+p[0]*x_tmp[0]+p[5]*x_tmp[1]+k[0]*p[6]*x_tmp[0]*x_tmp[3];
return(0);

}


