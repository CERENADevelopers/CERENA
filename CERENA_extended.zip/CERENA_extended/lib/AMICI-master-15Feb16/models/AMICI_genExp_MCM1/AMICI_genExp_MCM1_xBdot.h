#ifndef _am_AMICI_genExp_MCM1_xBdot_h
#define _am_AMICI_genExp_MCM1_xBdot_h

int xBdot_AMICI_genExp_MCM1(realtype t, N_Vector x, N_Vector dx, N_Vector xB, N_Vector dxB, N_Vector xBdot, void *user_data);


#endif /* _am_AMICI_genExp_MCM1_xBdot_h */
