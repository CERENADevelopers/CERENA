#ifndef _am_AMICI_genExp_MCM1_sigma_z_h
#define _am_AMICI_genExp_MCM1_sigma_z_h

int sigma_z_AMICI_genExp_MCM1(realtype t, int ie, realtype *sigma_z, void *user_data);


#endif /* _am_AMICI_genExp_MCM1_sigma_z_h */
