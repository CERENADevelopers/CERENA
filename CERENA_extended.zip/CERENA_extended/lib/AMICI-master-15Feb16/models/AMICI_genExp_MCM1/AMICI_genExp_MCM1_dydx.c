
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int dydx_AMICI_genExp_MCM1(realtype t, int it, realtype *dydx, N_Vector x, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
  dydx[0] = 1.0;
  dydx[2] = x_tmp[2];
  dydx[3] = x_tmp[3];
  dydx[4] = p[7]*x_tmp[3];
  dydx[6] = 1.0;
  dydx[7] = x_tmp[4];
  dydx[8] = x_tmp[5];
  dydx[9] = p[7]*x_tmp[5];
  dydx[12] = x_tmp[0];
  dydx[18] = x_tmp[0];
  dydx[19] = p[7]*x_tmp[0];
  dydx[22] = x_tmp[1];
  dydx[28] = x_tmp[1];
  dydx[29] = p[7]*x_tmp[1];
return(0);

}


