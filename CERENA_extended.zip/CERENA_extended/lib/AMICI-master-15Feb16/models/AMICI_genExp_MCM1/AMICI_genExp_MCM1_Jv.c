
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int Jv_AMICI_genExp_MCM1(realtype t, N_Vector x, N_Vector dx, N_Vector xdot, N_Vector v, N_Vector Jv, realtype cj, void *user_data, N_Vector tmp1, N_Vector tmp2) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *dx_tmp = N_VGetArrayPointer(dx);
realtype *xdot_tmp = N_VGetArrayPointer(xdot);
realtype *v_tmp = N_VGetArrayPointer(v);
realtype *Jv_tmp = N_VGetArrayPointer(Jv);
memset(Jv_tmp,0,sizeof(realtype)*6);
  Jv_tmp[0] = p[1]*v_tmp[1]-v_tmp[0]*(cj+p[0]+k[0]*p[6]*x_tmp[3])-k[0]*p[6]*v_tmp[3]*x_tmp[0];
  Jv_tmp[1] = -v_tmp[1]*(cj+p[1])+v_tmp[0]*(p[0]+k[0]*p[6]*x_tmp[3])+k[0]*p[6]*v_tmp[3]*x_tmp[0];
  Jv_tmp[2] = -v_tmp[2]*(cj*x_tmp[0]+p[1]*x_tmp[1]+p[3]*x_tmp[0])-v_tmp[1]*(p[1]*x_tmp[2]-p[1]*x_tmp[4])-v_tmp[0]*(dx_tmp[2]+p[3]*x_tmp[2])+p[1]*v_tmp[4]*x_tmp[1];
  Jv_tmp[3] = -v_tmp[3]*(cj*x_tmp[0]+p[1]*x_tmp[1]+p[5]*x_tmp[0])-v_tmp[0]*(dx_tmp[3]+p[5]*x_tmp[3]-p[4]*t*x_tmp[2])-v_tmp[1]*(p[1]*x_tmp[3]-p[1]*x_tmp[5])+p[1]*v_tmp[5]*x_tmp[1]+p[4]*t*v_tmp[2]*x_tmp[0];
  Jv_tmp[4] = -v_tmp[1]*(dx_tmp[4]-(p[2]-k[0]*p[3]*x_tmp[4])/k[0])-v_tmp[4]*(cj*x_tmp[1]+(k[0]*p[0]*x_tmp[0]+k[0]*p[3]*x_tmp[1]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3])/k[0])+(v_tmp[3]*((k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[2]-(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[4]))/k[0]+(v_tmp[2]*(k[0]*p[0]*x_tmp[0]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]))/k[0]+(v_tmp[0]*(k[0]*p[0]*x_tmp[2]-k[0]*p[0]*x_tmp[4]+(k[0]*k[0])*p[6]*x_tmp[2]*x_tmp[3]-(k[0]*k[0])*p[6]*x_tmp[3]*x_tmp[4]))/k[0];
  Jv_tmp[5] = v_tmp[0]*(p[0]*x_tmp[3]-p[0]*x_tmp[5]+k[0]*p[6]*(x_tmp[3]*x_tmp[3])-k[0]*p[6]*x_tmp[3]*x_tmp[5])-v_tmp[5]*(cj*x_tmp[1]+p[0]*x_tmp[0]+p[5]*x_tmp[1]+k[0]*p[6]*x_tmp[0]*x_tmp[3])-v_tmp[1]*(dx_tmp[5]+p[5]*x_tmp[5]-p[4]*t*x_tmp[4])+v_tmp[3]*(p[0]*x_tmp[0]+k[0]*p[6]*x_tmp[0]*x_tmp[3]*2.0-k[0]*p[6]*x_tmp[0]*x_tmp[5])+p[4]*t*v_tmp[4]*x_tmp[1];
return(0);

}


