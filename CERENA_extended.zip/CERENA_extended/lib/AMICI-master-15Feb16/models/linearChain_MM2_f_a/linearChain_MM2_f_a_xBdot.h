#ifndef _am_linearChain_MM2_f_a_xBdot_h
#define _am_linearChain_MM2_f_a_xBdot_h

int xBdot_linearChain_MM2_f_a(realtype t, N_Vector x, N_Vector xB, N_Vector xBdot, void *user_data);


#endif /* _am_linearChain_MM2_f_a_xBdot_h */
