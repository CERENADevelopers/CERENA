
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int JvB_linearChain_MM2_f_a(N_Vector vB, N_Vector JvB, realtype t, N_Vector x, N_Vector xB, N_Vector xBdot, void *user_data, N_Vector tmpB) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *xB_tmp = N_VGetArrayPointer(xB);
realtype *xBdot_tmp = N_VGetArrayPointer(xBdot);
realtype *vB_tmp = N_VGetArrayPointer(vB);
realtype *JvB_tmp = N_VGetArrayPointer(JvB);
memset(JvB_tmp,0,sizeof(realtype)*65);
  JvB_tmp[0] = p[1]*vB_tmp[0]-p[1]*vB_tmp[1]-p[1]*vB_tmp[10]+p[1]*vB_tmp[11]-p[1]*vB_tmp[20];
  JvB_tmp[1] = vB_tmp[1]*(p[2]+p[3])-vB_tmp[20]*(p[2]+p[3])-p[2]*vB_tmp[0]-p[3]*vB_tmp[2]-p[2]*vB_tmp[10]+p[2]*vB_tmp[11]+p[3]*vB_tmp[21]-p[3]*vB_tmp[29];
  JvB_tmp[2] = vB_tmp[2]*(p[4]+p[5])-vB_tmp[29]*(p[4]+p[5])-p[4]*vB_tmp[1]-p[5]*vB_tmp[3]-p[4]*vB_tmp[20]+p[4]*vB_tmp[21]+p[5]*vB_tmp[30]-p[5]*vB_tmp[37];
  JvB_tmp[3] = vB_tmp[3]*(p[6]+p[7])-vB_tmp[37]*(p[6]+p[7])-p[6]*vB_tmp[2]-p[7]*vB_tmp[4]-p[6]*vB_tmp[29]+p[6]*vB_tmp[30]+p[7]*vB_tmp[38]-p[7]*vB_tmp[44];
  JvB_tmp[4] = vB_tmp[4]*(p[8]+p[9])-vB_tmp[44]*(p[8]+p[9])-p[8]*vB_tmp[3]-p[9]*vB_tmp[5]-p[8]*vB_tmp[37]+p[8]*vB_tmp[38]+p[9]*vB_tmp[45]-p[9]*vB_tmp[50];
  JvB_tmp[5] = vB_tmp[5]*(p[10]+p[11])-vB_tmp[50]*(p[10]+p[11])-p[10]*vB_tmp[4]-p[11]*vB_tmp[6]-p[10]*vB_tmp[44]+p[10]*vB_tmp[45]+p[11]*vB_tmp[51]-p[11]*vB_tmp[55];
  JvB_tmp[6] = vB_tmp[6]*(p[12]+p[13])-vB_tmp[55]*(p[12]+p[13])-p[12]*vB_tmp[5]-p[13]*vB_tmp[7]-p[12]*vB_tmp[50]+p[12]*vB_tmp[51]+p[13]*vB_tmp[56]-p[13]*vB_tmp[59];
  JvB_tmp[7] = vB_tmp[7]*(p[14]+p[15])-vB_tmp[59]*(p[14]+p[15])-p[14]*vB_tmp[6]-p[15]*vB_tmp[8]-p[14]*vB_tmp[55]+p[14]*vB_tmp[56]+p[15]*vB_tmp[60]-p[15]*vB_tmp[62];
  JvB_tmp[8] = vB_tmp[8]*(p[16]+p[17])-vB_tmp[62]*(p[16]+p[17])-p[16]*vB_tmp[7]-p[17]*vB_tmp[9]-p[16]*vB_tmp[59]+p[16]*vB_tmp[60]+p[17]*vB_tmp[63]-p[17]*vB_tmp[64];
  JvB_tmp[9] = vB_tmp[9]*(p[18]+p[19])-vB_tmp[64]*(p[18]+p[19])-p[18]*vB_tmp[8]-p[18]*vB_tmp[62]+p[18]*vB_tmp[63];
  JvB_tmp[10] = p[1]*vB_tmp[10]*2.0-p[1]*vB_tmp[11];
  JvB_tmp[11] = p[2]*vB_tmp[10]*-2.0-p[3]*vB_tmp[12]-p[1]*vB_tmp[20]*2.0+vB_tmp[11]*(p[1]+p[2]+p[3]);
  JvB_tmp[12] = -p[4]*vB_tmp[11]-p[5]*vB_tmp[13]-p[1]*vB_tmp[21]+vB_tmp[12]*(p[1]+p[4]+p[5]);
  JvB_tmp[13] = -p[6]*vB_tmp[12]-p[7]*vB_tmp[14]-p[1]*vB_tmp[22]+vB_tmp[13]*(p[1]+p[6]+p[7]);
  JvB_tmp[14] = -p[8]*vB_tmp[13]-p[1]*vB_tmp[23]-p[9]*vB_tmp[15]+vB_tmp[14]*(p[1]+p[8]+p[9]);
  JvB_tmp[15] = -p[10]*vB_tmp[14]-p[1]*vB_tmp[24]-p[11]*vB_tmp[16]+vB_tmp[15]*(p[1]+p[10]+p[11]);
  JvB_tmp[16] = -p[1]*vB_tmp[25]-p[12]*vB_tmp[15]-p[13]*vB_tmp[17]+vB_tmp[16]*(p[1]+p[12]+p[13]);
  JvB_tmp[17] = -p[1]*vB_tmp[26]-p[14]*vB_tmp[16]-p[15]*vB_tmp[18]+vB_tmp[17]*(p[1]+p[14]+p[15]);
  JvB_tmp[18] = -p[1]*vB_tmp[27]-p[16]*vB_tmp[17]-p[17]*vB_tmp[19]+vB_tmp[18]*(p[1]+p[16]+p[17]);
  JvB_tmp[19] = -p[1]*vB_tmp[28]-p[18]*vB_tmp[18]+vB_tmp[19]*(p[1]+p[18]+p[19]);
  JvB_tmp[20] = -p[2]*vB_tmp[11]-p[3]*vB_tmp[21]+vB_tmp[20]*(p[2]*2.0+p[3]*2.0);
  JvB_tmp[21] = -p[2]*vB_tmp[12]-p[4]*vB_tmp[20]*2.0-p[5]*vB_tmp[22]-p[3]*vB_tmp[29]*2.0+vB_tmp[21]*(p[2]+p[3]+p[4]+p[5]);
  JvB_tmp[22] = -p[2]*vB_tmp[13]-p[6]*vB_tmp[21]-p[7]*vB_tmp[23]-p[3]*vB_tmp[30]+vB_tmp[22]*(p[2]+p[3]+p[6]+p[7]);
  JvB_tmp[23] = -p[2]*vB_tmp[14]-p[8]*vB_tmp[22]-p[9]*vB_tmp[24]-p[3]*vB_tmp[31]+vB_tmp[23]*(p[2]+p[3]+p[8]+p[9]);
  JvB_tmp[24] = -p[2]*vB_tmp[15]-p[10]*vB_tmp[23]-p[3]*vB_tmp[32]-p[11]*vB_tmp[25]+vB_tmp[24]*(p[2]+p[3]+p[10]+p[11]);
  JvB_tmp[25] = -p[2]*vB_tmp[16]-p[3]*vB_tmp[33]-p[12]*vB_tmp[24]-p[13]*vB_tmp[26]+vB_tmp[25]*(p[2]+p[3]+p[12]+p[13]);
  JvB_tmp[26] = -p[2]*vB_tmp[17]-p[3]*vB_tmp[34]-p[14]*vB_tmp[25]-p[15]*vB_tmp[27]+vB_tmp[26]*(p[2]+p[3]+p[14]+p[15]);
  JvB_tmp[27] = -p[2]*vB_tmp[18]-p[3]*vB_tmp[35]-p[16]*vB_tmp[26]-p[17]*vB_tmp[28]+vB_tmp[27]*(p[2]+p[3]+p[16]+p[17]);
  JvB_tmp[28] = -p[2]*vB_tmp[19]-p[3]*vB_tmp[36]-p[18]*vB_tmp[27]+vB_tmp[28]*(p[2]+p[3]+p[18]+p[19]);
  JvB_tmp[29] = -p[4]*vB_tmp[21]-p[5]*vB_tmp[30]+vB_tmp[29]*(p[4]*2.0+p[5]*2.0);
  JvB_tmp[30] = -p[4]*vB_tmp[22]-p[6]*vB_tmp[29]*2.0-p[7]*vB_tmp[31]-p[5]*vB_tmp[37]*2.0+vB_tmp[30]*(p[4]+p[5]+p[6]+p[7]);
  JvB_tmp[31] = -p[4]*vB_tmp[23]-p[8]*vB_tmp[30]-p[9]*vB_tmp[32]-p[5]*vB_tmp[38]+vB_tmp[31]*(p[4]+p[5]+p[8]+p[9]);
  JvB_tmp[32] = -p[4]*vB_tmp[24]-p[10]*vB_tmp[31]-p[5]*vB_tmp[39]-p[11]*vB_tmp[33]+vB_tmp[32]*(p[4]+p[5]+p[10]+p[11]);
  JvB_tmp[33] = -p[4]*vB_tmp[25]-p[12]*vB_tmp[32]-p[5]*vB_tmp[40]-p[13]*vB_tmp[34]+vB_tmp[33]*(p[4]+p[5]+p[12]+p[13]);
  JvB_tmp[34] = -p[4]*vB_tmp[26]-p[5]*vB_tmp[41]-p[14]*vB_tmp[33]-p[15]*vB_tmp[35]+vB_tmp[34]*(p[4]+p[5]+p[14]+p[15]);
  JvB_tmp[35] = -p[4]*vB_tmp[27]-p[5]*vB_tmp[42]-p[16]*vB_tmp[34]-p[17]*vB_tmp[36]+vB_tmp[35]*(p[4]+p[5]+p[16]+p[17]);
  JvB_tmp[36] = -p[4]*vB_tmp[28]-p[5]*vB_tmp[43]-p[18]*vB_tmp[35]+vB_tmp[36]*(p[4]+p[5]+p[18]+p[19]);
  JvB_tmp[37] = -p[6]*vB_tmp[30]-p[7]*vB_tmp[38]+vB_tmp[37]*(p[6]*2.0+p[7]*2.0);
  JvB_tmp[38] = -p[6]*vB_tmp[31]-p[8]*vB_tmp[37]*2.0-p[9]*vB_tmp[39]-p[7]*vB_tmp[44]*2.0+vB_tmp[38]*(p[6]+p[7]+p[8]+p[9]);
  JvB_tmp[39] = -p[6]*vB_tmp[32]-p[10]*vB_tmp[38]-p[11]*vB_tmp[40]-p[7]*vB_tmp[45]+vB_tmp[39]*(p[6]+p[7]+p[10]+p[11]);
  JvB_tmp[40] = -p[6]*vB_tmp[33]-p[12]*vB_tmp[39]-p[7]*vB_tmp[46]-p[13]*vB_tmp[41]+vB_tmp[40]*(p[6]+p[7]+p[12]+p[13]);
  JvB_tmp[41] = -p[6]*vB_tmp[34]-p[7]*vB_tmp[47]-p[14]*vB_tmp[40]-p[15]*vB_tmp[42]+vB_tmp[41]*(p[6]+p[7]+p[14]+p[15]);
  JvB_tmp[42] = -p[6]*vB_tmp[35]-p[7]*vB_tmp[48]-p[16]*vB_tmp[41]-p[17]*vB_tmp[43]+vB_tmp[42]*(p[6]+p[7]+p[16]+p[17]);
  JvB_tmp[43] = -p[6]*vB_tmp[36]-p[7]*vB_tmp[49]-p[18]*vB_tmp[42]+vB_tmp[43]*(p[6]+p[7]+p[18]+p[19]);
  JvB_tmp[44] = -p[8]*vB_tmp[38]-p[9]*vB_tmp[45]+vB_tmp[44]*(p[8]*2.0+p[9]*2.0);
  JvB_tmp[45] = -p[8]*vB_tmp[39]-p[10]*vB_tmp[44]*2.0-p[11]*vB_tmp[46]-p[9]*vB_tmp[50]*2.0+vB_tmp[45]*(p[8]+p[9]+p[10]+p[11]);
  JvB_tmp[46] = -p[8]*vB_tmp[40]-p[12]*vB_tmp[45]-p[9]*vB_tmp[51]-p[13]*vB_tmp[47]+vB_tmp[46]*(p[8]+p[9]+p[12]+p[13]);
  JvB_tmp[47] = -p[8]*vB_tmp[41]-p[14]*vB_tmp[46]-p[9]*vB_tmp[52]-p[15]*vB_tmp[48]+vB_tmp[47]*(p[8]+p[9]+p[14]+p[15]);
  JvB_tmp[48] = -p[8]*vB_tmp[42]-p[9]*vB_tmp[53]-p[16]*vB_tmp[47]-p[17]*vB_tmp[49]+vB_tmp[48]*(p[8]+p[9]+p[16]+p[17]);
  JvB_tmp[49] = -p[8]*vB_tmp[43]-p[9]*vB_tmp[54]-p[18]*vB_tmp[48]+vB_tmp[49]*(p[8]+p[9]+p[18]+p[19]);
  JvB_tmp[50] = -p[10]*vB_tmp[45]-p[11]*vB_tmp[51]+vB_tmp[50]*(p[10]*2.0+p[11]*2.0);
  JvB_tmp[51] = -p[10]*vB_tmp[46]-p[12]*vB_tmp[50]*2.0-p[13]*vB_tmp[52]-p[11]*vB_tmp[55]*2.0+vB_tmp[51]*(p[10]+p[11]+p[12]+p[13]);
  JvB_tmp[52] = -p[10]*vB_tmp[47]-p[14]*vB_tmp[51]-p[11]*vB_tmp[56]-p[15]*vB_tmp[53]+vB_tmp[52]*(p[10]+p[11]+p[14]+p[15]);
  JvB_tmp[53] = -p[10]*vB_tmp[48]-p[11]*vB_tmp[57]-p[16]*vB_tmp[52]-p[17]*vB_tmp[54]+vB_tmp[53]*(p[10]+p[11]+p[16]+p[17]);
  JvB_tmp[54] = -p[10]*vB_tmp[49]-p[11]*vB_tmp[58]-p[18]*vB_tmp[53]+vB_tmp[54]*(p[10]+p[11]+p[18]+p[19]);
  JvB_tmp[55] = -p[12]*vB_tmp[51]-p[13]*vB_tmp[56]+vB_tmp[55]*(p[12]*2.0+p[13]*2.0);
  JvB_tmp[56] = -p[12]*vB_tmp[52]-p[14]*vB_tmp[55]*2.0-p[13]*vB_tmp[59]*2.0-p[15]*vB_tmp[57]+vB_tmp[56]*(p[12]+p[13]+p[14]+p[15]);
  JvB_tmp[57] = -p[12]*vB_tmp[53]-p[16]*vB_tmp[56]-p[13]*vB_tmp[60]-p[17]*vB_tmp[58]+vB_tmp[57]*(p[12]+p[13]+p[16]+p[17]);
  JvB_tmp[58] = -p[12]*vB_tmp[54]-p[13]*vB_tmp[61]-p[18]*vB_tmp[57]+vB_tmp[58]*(p[12]+p[13]+p[18]+p[19]);
  JvB_tmp[59] = -p[14]*vB_tmp[56]-p[15]*vB_tmp[60]+vB_tmp[59]*(p[14]*2.0+p[15]*2.0);
  JvB_tmp[60] = -p[14]*vB_tmp[57]-p[16]*vB_tmp[59]*2.0-p[15]*vB_tmp[62]*2.0-p[17]*vB_tmp[61]+vB_tmp[60]*(p[14]+p[15]+p[16]+p[17]);
  JvB_tmp[61] = -p[14]*vB_tmp[58]-p[15]*vB_tmp[63]-p[18]*vB_tmp[60]+vB_tmp[61]*(p[14]+p[15]+p[18]+p[19]);
  JvB_tmp[62] = -p[16]*vB_tmp[60]-p[17]*vB_tmp[63]+vB_tmp[62]*(p[16]*2.0+p[17]*2.0);
  JvB_tmp[63] = -p[16]*vB_tmp[61]-p[18]*vB_tmp[62]*2.0-p[17]*vB_tmp[64]*2.0+vB_tmp[63]*(p[16]+p[17]+p[18]+p[19]);
  JvB_tmp[64] = -p[18]*vB_tmp[63]+vB_tmp[64]*(p[18]*2.0+p[19]*2.0);
return(0);

}


