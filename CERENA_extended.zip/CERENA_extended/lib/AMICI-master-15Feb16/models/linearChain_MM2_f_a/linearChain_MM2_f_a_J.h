#ifndef _am_linearChain_MM2_f_a_J_h
#define _am_linearChain_MM2_f_a_J_h

int J_linearChain_MM2_f_a(long int N, realtype t, N_Vector x, N_Vector xdot, DlsMat J, void *user_data, N_Vector tmp1, N_Vector tmp2, N_Vector tmp3);


#endif /* _am_linearChain_MM2_f_a_J_h */
