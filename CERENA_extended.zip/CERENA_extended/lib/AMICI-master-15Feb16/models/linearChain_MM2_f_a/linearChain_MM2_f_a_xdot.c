
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int xdot_linearChain_MM2_f_a(realtype t, N_Vector x, N_Vector xdot, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *xdot_tmp = N_VGetArrayPointer(xdot);
memset(xdot_tmp,0,sizeof(realtype)*65);
  xdot_tmp[0] = p[0]-p[1]*x_tmp[0]+p[2]*x_tmp[1];
  xdot_tmp[1] = p[1]*x_tmp[0]-p[2]*x_tmp[1]-p[3]*x_tmp[1]+p[4]*x_tmp[2];
  xdot_tmp[2] = p[3]*x_tmp[1]-p[4]*x_tmp[2]-p[5]*x_tmp[2]+p[6]*x_tmp[3];
  xdot_tmp[3] = p[5]*x_tmp[2]-p[6]*x_tmp[3]-p[7]*x_tmp[3]+p[8]*x_tmp[4];
  xdot_tmp[4] = p[7]*x_tmp[3]-p[8]*x_tmp[4]-p[9]*x_tmp[4]+p[10]*x_tmp[5];
  xdot_tmp[5] = p[9]*x_tmp[4]-p[10]*x_tmp[5]-p[11]*x_tmp[5]+p[12]*x_tmp[6];
  xdot_tmp[6] = p[11]*x_tmp[5]-p[12]*x_tmp[6]-p[13]*x_tmp[6]+p[14]*x_tmp[7];
  xdot_tmp[7] = p[13]*x_tmp[6]-p[14]*x_tmp[7]-p[15]*x_tmp[7]+p[16]*x_tmp[8];
  xdot_tmp[8] = p[15]*x_tmp[7]-p[16]*x_tmp[8]-p[17]*x_tmp[8]+p[18]*x_tmp[9];
  xdot_tmp[9] = p[17]*x_tmp[8]-p[18]*x_tmp[9]-p[19]*x_tmp[9];
  xdot_tmp[10] = p[0]+p[1]*x_tmp[0]+p[2]*x_tmp[1]-p[1]*x_tmp[10]*2.0+p[2]*x_tmp[11]*2.0;
  xdot_tmp[11] = -p[1]*x_tmp[0]-p[2]*x_tmp[1]+p[1]*x_tmp[10]-p[1]*x_tmp[11]-p[2]*x_tmp[11]-p[3]*x_tmp[11]+p[4]*x_tmp[12]+p[2]*x_tmp[20];
  xdot_tmp[12] = -p[1]*x_tmp[12]+p[3]*x_tmp[11]-p[4]*x_tmp[12]-p[5]*x_tmp[12]+p[6]*x_tmp[13]+p[2]*x_tmp[21];
  xdot_tmp[13] = -p[1]*x_tmp[13]+p[5]*x_tmp[12]-p[6]*x_tmp[13]-p[7]*x_tmp[13]+p[8]*x_tmp[14]+p[2]*x_tmp[22];
  xdot_tmp[14] = -p[1]*x_tmp[14]+p[7]*x_tmp[13]-p[8]*x_tmp[14]-p[9]*x_tmp[14]+p[2]*x_tmp[23]+p[10]*x_tmp[15];
  xdot_tmp[15] = -p[1]*x_tmp[15]+p[9]*x_tmp[14]-p[10]*x_tmp[15]+p[2]*x_tmp[24]-p[11]*x_tmp[15]+p[12]*x_tmp[16];
  xdot_tmp[16] = -p[1]*x_tmp[16]+p[11]*x_tmp[15]+p[2]*x_tmp[25]-p[12]*x_tmp[16]-p[13]*x_tmp[16]+p[14]*x_tmp[17];
  xdot_tmp[17] = -p[1]*x_tmp[17]+p[2]*x_tmp[26]+p[13]*x_tmp[16]-p[14]*x_tmp[17]-p[15]*x_tmp[17]+p[16]*x_tmp[18];
  xdot_tmp[18] = -p[1]*x_tmp[18]+p[2]*x_tmp[27]+p[15]*x_tmp[17]-p[16]*x_tmp[18]-p[17]*x_tmp[18]+p[18]*x_tmp[19];
  xdot_tmp[19] = -p[1]*x_tmp[19]+p[2]*x_tmp[28]+p[17]*x_tmp[18]-p[18]*x_tmp[19]-p[19]*x_tmp[19];
  xdot_tmp[20] = p[1]*x_tmp[0]+p[2]*x_tmp[1]+p[3]*x_tmp[1]+p[4]*x_tmp[2]+p[1]*x_tmp[11]*2.0-p[2]*x_tmp[20]*2.0-p[3]*x_tmp[20]*2.0+p[4]*x_tmp[21]*2.0;
  xdot_tmp[21] = -p[3]*x_tmp[1]-p[4]*x_tmp[2]+p[1]*x_tmp[12]-p[2]*x_tmp[21]+p[3]*x_tmp[20]-p[3]*x_tmp[21]-p[4]*x_tmp[21]-p[5]*x_tmp[21]+p[6]*x_tmp[22]+p[4]*x_tmp[29];
  xdot_tmp[22] = p[1]*x_tmp[13]-p[2]*x_tmp[22]-p[3]*x_tmp[22]+p[5]*x_tmp[21]-p[6]*x_tmp[22]-p[7]*x_tmp[22]+p[8]*x_tmp[23]+p[4]*x_tmp[30];
  xdot_tmp[23] = p[1]*x_tmp[14]-p[2]*x_tmp[23]-p[3]*x_tmp[23]+p[7]*x_tmp[22]-p[8]*x_tmp[23]-p[9]*x_tmp[23]+p[10]*x_tmp[24]+p[4]*x_tmp[31];
  xdot_tmp[24] = p[1]*x_tmp[15]-p[2]*x_tmp[24]-p[3]*x_tmp[24]+p[9]*x_tmp[23]-p[10]*x_tmp[24]-p[11]*x_tmp[24]+p[4]*x_tmp[32]+p[12]*x_tmp[25];
  xdot_tmp[25] = p[1]*x_tmp[16]-p[2]*x_tmp[25]-p[3]*x_tmp[25]+p[11]*x_tmp[24]+p[4]*x_tmp[33]-p[12]*x_tmp[25]-p[13]*x_tmp[25]+p[14]*x_tmp[26];
  xdot_tmp[26] = p[1]*x_tmp[17]-p[2]*x_tmp[26]-p[3]*x_tmp[26]+p[4]*x_tmp[34]+p[13]*x_tmp[25]-p[14]*x_tmp[26]-p[15]*x_tmp[26]+p[16]*x_tmp[27];
  xdot_tmp[27] = p[1]*x_tmp[18]-p[2]*x_tmp[27]-p[3]*x_tmp[27]+p[4]*x_tmp[35]+p[15]*x_tmp[26]-p[16]*x_tmp[27]-p[17]*x_tmp[27]+p[18]*x_tmp[28];
  xdot_tmp[28] = p[1]*x_tmp[19]-p[2]*x_tmp[28]-p[3]*x_tmp[28]+p[4]*x_tmp[36]+p[17]*x_tmp[27]-p[18]*x_tmp[28]-p[19]*x_tmp[28];
  xdot_tmp[29] = p[3]*x_tmp[1]+p[4]*x_tmp[2]+p[5]*x_tmp[2]+p[6]*x_tmp[3]+p[3]*x_tmp[21]*2.0-p[4]*x_tmp[29]*2.0-p[5]*x_tmp[29]*2.0+p[6]*x_tmp[30]*2.0;
  xdot_tmp[30] = -p[5]*x_tmp[2]-p[6]*x_tmp[3]+p[3]*x_tmp[22]-p[4]*x_tmp[30]+p[5]*x_tmp[29]-p[5]*x_tmp[30]-p[6]*x_tmp[30]-p[7]*x_tmp[30]+p[8]*x_tmp[31]+p[6]*x_tmp[37];
  xdot_tmp[31] = p[3]*x_tmp[23]-p[4]*x_tmp[31]-p[5]*x_tmp[31]+p[7]*x_tmp[30]-p[8]*x_tmp[31]-p[9]*x_tmp[31]+p[10]*x_tmp[32]+p[6]*x_tmp[38];
  xdot_tmp[32] = p[3]*x_tmp[24]-p[4]*x_tmp[32]-p[5]*x_tmp[32]+p[9]*x_tmp[31]-p[10]*x_tmp[32]-p[11]*x_tmp[32]+p[6]*x_tmp[39]+p[12]*x_tmp[33];
  xdot_tmp[33] = p[3]*x_tmp[25]-p[4]*x_tmp[33]-p[5]*x_tmp[33]+p[11]*x_tmp[32]-p[12]*x_tmp[33]+p[6]*x_tmp[40]-p[13]*x_tmp[33]+p[14]*x_tmp[34];
  xdot_tmp[34] = p[3]*x_tmp[26]-p[4]*x_tmp[34]-p[5]*x_tmp[34]+p[13]*x_tmp[33]+p[6]*x_tmp[41]-p[14]*x_tmp[34]-p[15]*x_tmp[34]+p[16]*x_tmp[35];
  xdot_tmp[35] = p[3]*x_tmp[27]-p[4]*x_tmp[35]-p[5]*x_tmp[35]+p[6]*x_tmp[42]+p[15]*x_tmp[34]-p[16]*x_tmp[35]-p[17]*x_tmp[35]+p[18]*x_tmp[36];
  xdot_tmp[36] = p[3]*x_tmp[28]-p[4]*x_tmp[36]-p[5]*x_tmp[36]+p[6]*x_tmp[43]+p[17]*x_tmp[35]-p[18]*x_tmp[36]-p[19]*x_tmp[36];
  xdot_tmp[37] = p[5]*x_tmp[2]+p[6]*x_tmp[3]+p[7]*x_tmp[3]+p[8]*x_tmp[4]+p[5]*x_tmp[30]*2.0-p[6]*x_tmp[37]*2.0-p[7]*x_tmp[37]*2.0+p[8]*x_tmp[38]*2.0;
  xdot_tmp[38] = -p[7]*x_tmp[3]-p[8]*x_tmp[4]+p[5]*x_tmp[31]-p[6]*x_tmp[38]+p[7]*x_tmp[37]-p[7]*x_tmp[38]-p[8]*x_tmp[38]-p[9]*x_tmp[38]+p[10]*x_tmp[39]+p[8]*x_tmp[44];
  xdot_tmp[39] = p[5]*x_tmp[32]-p[6]*x_tmp[39]-p[7]*x_tmp[39]+p[9]*x_tmp[38]-p[10]*x_tmp[39]-p[11]*x_tmp[39]+p[12]*x_tmp[40]+p[8]*x_tmp[45];
  xdot_tmp[40] = p[5]*x_tmp[33]-p[6]*x_tmp[40]-p[7]*x_tmp[40]+p[11]*x_tmp[39]-p[12]*x_tmp[40]-p[13]*x_tmp[40]+p[8]*x_tmp[46]+p[14]*x_tmp[41];
  xdot_tmp[41] = p[5]*x_tmp[34]-p[6]*x_tmp[41]-p[7]*x_tmp[41]+p[13]*x_tmp[40]+p[8]*x_tmp[47]-p[14]*x_tmp[41]-p[15]*x_tmp[41]+p[16]*x_tmp[42];
  xdot_tmp[42] = p[5]*x_tmp[35]-p[6]*x_tmp[42]-p[7]*x_tmp[42]+p[8]*x_tmp[48]+p[15]*x_tmp[41]-p[16]*x_tmp[42]-p[17]*x_tmp[42]+p[18]*x_tmp[43];
  xdot_tmp[43] = p[5]*x_tmp[36]-p[6]*x_tmp[43]-p[7]*x_tmp[43]+p[8]*x_tmp[49]+p[17]*x_tmp[42]-p[18]*x_tmp[43]-p[19]*x_tmp[43];
  xdot_tmp[44] = p[7]*x_tmp[3]+p[8]*x_tmp[4]+p[9]*x_tmp[4]+p[10]*x_tmp[5]+p[7]*x_tmp[38]*2.0-p[8]*x_tmp[44]*2.0-p[9]*x_tmp[44]*2.0+p[10]*x_tmp[45]*2.0;
  xdot_tmp[45] = -p[9]*x_tmp[4]-p[10]*x_tmp[5]+p[7]*x_tmp[39]-p[8]*x_tmp[45]+p[9]*x_tmp[44]-p[9]*x_tmp[45]-p[10]*x_tmp[45]-p[11]*x_tmp[45]+p[12]*x_tmp[46]+p[10]*x_tmp[50];
  xdot_tmp[46] = p[7]*x_tmp[40]-p[8]*x_tmp[46]-p[9]*x_tmp[46]+p[11]*x_tmp[45]-p[12]*x_tmp[46]-p[13]*x_tmp[46]+p[10]*x_tmp[51]+p[14]*x_tmp[47];
  xdot_tmp[47] = p[7]*x_tmp[41]-p[8]*x_tmp[47]-p[9]*x_tmp[47]+p[13]*x_tmp[46]-p[14]*x_tmp[47]+p[10]*x_tmp[52]-p[15]*x_tmp[47]+p[16]*x_tmp[48];
  xdot_tmp[48] = p[7]*x_tmp[42]-p[8]*x_tmp[48]-p[9]*x_tmp[48]+p[15]*x_tmp[47]+p[10]*x_tmp[53]-p[16]*x_tmp[48]-p[17]*x_tmp[48]+p[18]*x_tmp[49];
  xdot_tmp[49] = p[7]*x_tmp[43]-p[8]*x_tmp[49]-p[9]*x_tmp[49]+p[10]*x_tmp[54]+p[17]*x_tmp[48]-p[18]*x_tmp[49]-p[19]*x_tmp[49];
  xdot_tmp[50] = p[9]*x_tmp[4]+p[10]*x_tmp[5]+p[11]*x_tmp[5]+p[12]*x_tmp[6]+p[9]*x_tmp[45]*2.0-p[10]*x_tmp[50]*2.0-p[11]*x_tmp[50]*2.0+p[12]*x_tmp[51]*2.0;
  xdot_tmp[51] = -p[11]*x_tmp[5]-p[12]*x_tmp[6]+p[9]*x_tmp[46]-p[10]*x_tmp[51]+p[11]*x_tmp[50]-p[11]*x_tmp[51]-p[12]*x_tmp[51]-p[13]*x_tmp[51]+p[14]*x_tmp[52]+p[12]*x_tmp[55];
  xdot_tmp[52] = p[9]*x_tmp[47]-p[10]*x_tmp[52]-p[11]*x_tmp[52]+p[13]*x_tmp[51]-p[14]*x_tmp[52]-p[15]*x_tmp[52]+p[12]*x_tmp[56]+p[16]*x_tmp[53];
  xdot_tmp[53] = p[9]*x_tmp[48]-p[10]*x_tmp[53]-p[11]*x_tmp[53]+p[15]*x_tmp[52]+p[12]*x_tmp[57]-p[16]*x_tmp[53]-p[17]*x_tmp[53]+p[18]*x_tmp[54];
  xdot_tmp[54] = p[9]*x_tmp[49]-p[10]*x_tmp[54]-p[11]*x_tmp[54]+p[12]*x_tmp[58]+p[17]*x_tmp[53]-p[18]*x_tmp[54]-p[19]*x_tmp[54];
  xdot_tmp[55] = p[11]*x_tmp[5]+p[12]*x_tmp[6]+p[13]*x_tmp[6]+p[14]*x_tmp[7]+p[11]*x_tmp[51]*2.0-p[12]*x_tmp[55]*2.0-p[13]*x_tmp[55]*2.0+p[14]*x_tmp[56]*2.0;
  xdot_tmp[56] = -p[13]*x_tmp[6]-p[14]*x_tmp[7]+p[11]*x_tmp[52]-p[12]*x_tmp[56]+p[13]*x_tmp[55]-p[13]*x_tmp[56]-p[14]*x_tmp[56]-p[15]*x_tmp[56]+p[14]*x_tmp[59]+p[16]*x_tmp[57];
  xdot_tmp[57] = p[11]*x_tmp[53]-p[12]*x_tmp[57]-p[13]*x_tmp[57]+p[15]*x_tmp[56]-p[16]*x_tmp[57]+p[14]*x_tmp[60]-p[17]*x_tmp[57]+p[18]*x_tmp[58];
  xdot_tmp[58] = p[11]*x_tmp[54]-p[12]*x_tmp[58]-p[13]*x_tmp[58]+p[17]*x_tmp[57]+p[14]*x_tmp[61]-p[18]*x_tmp[58]-p[19]*x_tmp[58];
  xdot_tmp[59] = p[13]*x_tmp[6]+p[14]*x_tmp[7]+p[15]*x_tmp[7]+p[16]*x_tmp[8]+p[13]*x_tmp[56]*2.0-p[14]*x_tmp[59]*2.0-p[15]*x_tmp[59]*2.0+p[16]*x_tmp[60]*2.0;
  xdot_tmp[60] = -p[15]*x_tmp[7]-p[16]*x_tmp[8]+p[13]*x_tmp[57]-p[14]*x_tmp[60]+p[15]*x_tmp[59]-p[15]*x_tmp[60]-p[16]*x_tmp[60]-p[17]*x_tmp[60]+p[16]*x_tmp[62]+p[18]*x_tmp[61];
  xdot_tmp[61] = p[13]*x_tmp[58]-p[14]*x_tmp[61]-p[15]*x_tmp[61]+p[17]*x_tmp[60]+p[16]*x_tmp[63]-p[18]*x_tmp[61]-p[19]*x_tmp[61];
  xdot_tmp[62] = p[15]*x_tmp[7]+p[16]*x_tmp[8]+p[17]*x_tmp[8]+p[18]*x_tmp[9]+p[15]*x_tmp[60]*2.0-p[16]*x_tmp[62]*2.0-p[17]*x_tmp[62]*2.0+p[18]*x_tmp[63]*2.0;
  xdot_tmp[63] = -p[17]*x_tmp[8]-p[18]*x_tmp[9]+p[15]*x_tmp[61]-p[16]*x_tmp[63]+p[17]*x_tmp[62]-p[17]*x_tmp[63]-p[18]*x_tmp[63]+p[18]*x_tmp[64]-p[19]*x_tmp[63];
  xdot_tmp[64] = p[17]*x_tmp[8]+p[18]*x_tmp[9]+p[19]*x_tmp[9]+p[17]*x_tmp[63]*2.0-p[18]*x_tmp[64]*2.0-p[19]*x_tmp[64]*2.0;
int ix;
for(ix = 0; ix<65; ix++) {
   if(mxIsNaN(xdot_tmp[ix])) {
       xdot_tmp[ix] = 0;       if(!udata->am_nan_xdot) {
           mexWarnMsgIdAndTxt("AMICI:mex:fxdot:NaN","AMICI replaced a NaN value in xdot and replaced it by 0.0. This will not be reported again for this simulation run.");           udata->am_nan_xdot = TRUE;
       }
   }   if(mxIsInf(xdot_tmp[ix])) {
       mexWarnMsgIdAndTxt("AMICI:mex:fxdot:Inf","AMICI encountered an Inf value in xdot! Aborting simulation ... ");       return(-1);   }}
return(0);

}


