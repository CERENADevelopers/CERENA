#ifndef _am_linearChain_MM2_f_a_sz_h
#define _am_linearChain_MM2_f_a_sz_h

int sz_linearChain_MM2_f_a(realtype t, int ie, int *nroots, realtype *sz, N_Vector x, N_Vector *sx, void *user_data);


#endif /* _am_linearChain_MM2_f_a_sz_h */
