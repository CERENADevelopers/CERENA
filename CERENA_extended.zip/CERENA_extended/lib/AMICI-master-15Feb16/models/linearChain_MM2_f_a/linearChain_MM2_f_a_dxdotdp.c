
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int dxdotdp_linearChain_MM2_f_a(realtype t, realtype *dxdotdp, N_Vector x, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
memset(dxdotdp,0,sizeof(realtype)*65*np);
int ip;
for(ip = 0; ip<np; ip++) {
switch (plist[ip]) {
  case 0: {
  dxdotdp[(0+ip*65)] = 1.0;
  dxdotdp[(10+ip*65)] = 1.0;

  } break;

  case 1: {
  dxdotdp[(0+ip*65)] = -x_tmp[0];
  dxdotdp[(1+ip*65)] = x_tmp[0];
  dxdotdp[(10+ip*65)] = x_tmp[0]-x_tmp[10]*2.0;
  dxdotdp[(11+ip*65)] = -x_tmp[0]+x_tmp[10]-x_tmp[11];
  dxdotdp[(12+ip*65)] = -x_tmp[12];
  dxdotdp[(13+ip*65)] = -x_tmp[13];
  dxdotdp[(14+ip*65)] = -x_tmp[14];
  dxdotdp[(15+ip*65)] = -x_tmp[15];
  dxdotdp[(16+ip*65)] = -x_tmp[16];
  dxdotdp[(17+ip*65)] = -x_tmp[17];
  dxdotdp[(18+ip*65)] = -x_tmp[18];
  dxdotdp[(19+ip*65)] = -x_tmp[19];
  dxdotdp[(20+ip*65)] = x_tmp[0]+x_tmp[11]*2.0;
  dxdotdp[(21+ip*65)] = x_tmp[12];
  dxdotdp[(22+ip*65)] = x_tmp[13];
  dxdotdp[(23+ip*65)] = x_tmp[14];
  dxdotdp[(24+ip*65)] = x_tmp[15];
  dxdotdp[(25+ip*65)] = x_tmp[16];
  dxdotdp[(26+ip*65)] = x_tmp[17];
  dxdotdp[(27+ip*65)] = x_tmp[18];
  dxdotdp[(28+ip*65)] = x_tmp[19];

  } break;

  case 2: {
  dxdotdp[(0+ip*65)] = x_tmp[1];
  dxdotdp[(1+ip*65)] = -x_tmp[1];
  dxdotdp[(10+ip*65)] = x_tmp[1]+x_tmp[11]*2.0;
  dxdotdp[(11+ip*65)] = -x_tmp[1]-x_tmp[11]+x_tmp[20];
  dxdotdp[(12+ip*65)] = x_tmp[21];
  dxdotdp[(13+ip*65)] = x_tmp[22];
  dxdotdp[(14+ip*65)] = x_tmp[23];
  dxdotdp[(15+ip*65)] = x_tmp[24];
  dxdotdp[(16+ip*65)] = x_tmp[25];
  dxdotdp[(17+ip*65)] = x_tmp[26];
  dxdotdp[(18+ip*65)] = x_tmp[27];
  dxdotdp[(19+ip*65)] = x_tmp[28];
  dxdotdp[(20+ip*65)] = x_tmp[1]-x_tmp[20]*2.0;
  dxdotdp[(21+ip*65)] = -x_tmp[21];
  dxdotdp[(22+ip*65)] = -x_tmp[22];
  dxdotdp[(23+ip*65)] = -x_tmp[23];
  dxdotdp[(24+ip*65)] = -x_tmp[24];
  dxdotdp[(25+ip*65)] = -x_tmp[25];
  dxdotdp[(26+ip*65)] = -x_tmp[26];
  dxdotdp[(27+ip*65)] = -x_tmp[27];
  dxdotdp[(28+ip*65)] = -x_tmp[28];

  } break;

  case 3: {
  dxdotdp[(1+ip*65)] = -x_tmp[1];
  dxdotdp[(2+ip*65)] = x_tmp[1];
  dxdotdp[(11+ip*65)] = -x_tmp[11];
  dxdotdp[(12+ip*65)] = x_tmp[11];
  dxdotdp[(20+ip*65)] = x_tmp[1]-x_tmp[20]*2.0;
  dxdotdp[(21+ip*65)] = -x_tmp[1]+x_tmp[20]-x_tmp[21];
  dxdotdp[(22+ip*65)] = -x_tmp[22];
  dxdotdp[(23+ip*65)] = -x_tmp[23];
  dxdotdp[(24+ip*65)] = -x_tmp[24];
  dxdotdp[(25+ip*65)] = -x_tmp[25];
  dxdotdp[(26+ip*65)] = -x_tmp[26];
  dxdotdp[(27+ip*65)] = -x_tmp[27];
  dxdotdp[(28+ip*65)] = -x_tmp[28];
  dxdotdp[(29+ip*65)] = x_tmp[1]+x_tmp[21]*2.0;
  dxdotdp[(30+ip*65)] = x_tmp[22];
  dxdotdp[(31+ip*65)] = x_tmp[23];
  dxdotdp[(32+ip*65)] = x_tmp[24];
  dxdotdp[(33+ip*65)] = x_tmp[25];
  dxdotdp[(34+ip*65)] = x_tmp[26];
  dxdotdp[(35+ip*65)] = x_tmp[27];
  dxdotdp[(36+ip*65)] = x_tmp[28];

  } break;

  case 4: {
  dxdotdp[(1+ip*65)] = x_tmp[2];
  dxdotdp[(2+ip*65)] = -x_tmp[2];
  dxdotdp[(11+ip*65)] = x_tmp[12];
  dxdotdp[(12+ip*65)] = -x_tmp[12];
  dxdotdp[(20+ip*65)] = x_tmp[2]+x_tmp[21]*2.0;
  dxdotdp[(21+ip*65)] = -x_tmp[2]-x_tmp[21]+x_tmp[29];
  dxdotdp[(22+ip*65)] = x_tmp[30];
  dxdotdp[(23+ip*65)] = x_tmp[31];
  dxdotdp[(24+ip*65)] = x_tmp[32];
  dxdotdp[(25+ip*65)] = x_tmp[33];
  dxdotdp[(26+ip*65)] = x_tmp[34];
  dxdotdp[(27+ip*65)] = x_tmp[35];
  dxdotdp[(28+ip*65)] = x_tmp[36];
  dxdotdp[(29+ip*65)] = x_tmp[2]-x_tmp[29]*2.0;
  dxdotdp[(30+ip*65)] = -x_tmp[30];
  dxdotdp[(31+ip*65)] = -x_tmp[31];
  dxdotdp[(32+ip*65)] = -x_tmp[32];
  dxdotdp[(33+ip*65)] = -x_tmp[33];
  dxdotdp[(34+ip*65)] = -x_tmp[34];
  dxdotdp[(35+ip*65)] = -x_tmp[35];
  dxdotdp[(36+ip*65)] = -x_tmp[36];

  } break;

  case 5: {
  dxdotdp[(2+ip*65)] = -x_tmp[2];
  dxdotdp[(3+ip*65)] = x_tmp[2];
  dxdotdp[(12+ip*65)] = -x_tmp[12];
  dxdotdp[(13+ip*65)] = x_tmp[12];
  dxdotdp[(21+ip*65)] = -x_tmp[21];
  dxdotdp[(22+ip*65)] = x_tmp[21];
  dxdotdp[(29+ip*65)] = x_tmp[2]-x_tmp[29]*2.0;
  dxdotdp[(30+ip*65)] = -x_tmp[2]+x_tmp[29]-x_tmp[30];
  dxdotdp[(31+ip*65)] = -x_tmp[31];
  dxdotdp[(32+ip*65)] = -x_tmp[32];
  dxdotdp[(33+ip*65)] = -x_tmp[33];
  dxdotdp[(34+ip*65)] = -x_tmp[34];
  dxdotdp[(35+ip*65)] = -x_tmp[35];
  dxdotdp[(36+ip*65)] = -x_tmp[36];
  dxdotdp[(37+ip*65)] = x_tmp[2]+x_tmp[30]*2.0;
  dxdotdp[(38+ip*65)] = x_tmp[31];
  dxdotdp[(39+ip*65)] = x_tmp[32];
  dxdotdp[(40+ip*65)] = x_tmp[33];
  dxdotdp[(41+ip*65)] = x_tmp[34];
  dxdotdp[(42+ip*65)] = x_tmp[35];
  dxdotdp[(43+ip*65)] = x_tmp[36];

  } break;

  case 6: {
  dxdotdp[(2+ip*65)] = x_tmp[3];
  dxdotdp[(3+ip*65)] = -x_tmp[3];
  dxdotdp[(12+ip*65)] = x_tmp[13];
  dxdotdp[(13+ip*65)] = -x_tmp[13];
  dxdotdp[(21+ip*65)] = x_tmp[22];
  dxdotdp[(22+ip*65)] = -x_tmp[22];
  dxdotdp[(29+ip*65)] = x_tmp[3]+x_tmp[30]*2.0;
  dxdotdp[(30+ip*65)] = -x_tmp[3]-x_tmp[30]+x_tmp[37];
  dxdotdp[(31+ip*65)] = x_tmp[38];
  dxdotdp[(32+ip*65)] = x_tmp[39];
  dxdotdp[(33+ip*65)] = x_tmp[40];
  dxdotdp[(34+ip*65)] = x_tmp[41];
  dxdotdp[(35+ip*65)] = x_tmp[42];
  dxdotdp[(36+ip*65)] = x_tmp[43];
  dxdotdp[(37+ip*65)] = x_tmp[3]-x_tmp[37]*2.0;
  dxdotdp[(38+ip*65)] = -x_tmp[38];
  dxdotdp[(39+ip*65)] = -x_tmp[39];
  dxdotdp[(40+ip*65)] = -x_tmp[40];
  dxdotdp[(41+ip*65)] = -x_tmp[41];
  dxdotdp[(42+ip*65)] = -x_tmp[42];
  dxdotdp[(43+ip*65)] = -x_tmp[43];

  } break;

  case 7: {
  dxdotdp[(3+ip*65)] = -x_tmp[3];
  dxdotdp[(4+ip*65)] = x_tmp[3];
  dxdotdp[(13+ip*65)] = -x_tmp[13];
  dxdotdp[(14+ip*65)] = x_tmp[13];
  dxdotdp[(22+ip*65)] = -x_tmp[22];
  dxdotdp[(23+ip*65)] = x_tmp[22];
  dxdotdp[(30+ip*65)] = -x_tmp[30];
  dxdotdp[(31+ip*65)] = x_tmp[30];
  dxdotdp[(37+ip*65)] = x_tmp[3]-x_tmp[37]*2.0;
  dxdotdp[(38+ip*65)] = -x_tmp[3]+x_tmp[37]-x_tmp[38];
  dxdotdp[(39+ip*65)] = -x_tmp[39];
  dxdotdp[(40+ip*65)] = -x_tmp[40];
  dxdotdp[(41+ip*65)] = -x_tmp[41];
  dxdotdp[(42+ip*65)] = -x_tmp[42];
  dxdotdp[(43+ip*65)] = -x_tmp[43];
  dxdotdp[(44+ip*65)] = x_tmp[3]+x_tmp[38]*2.0;
  dxdotdp[(45+ip*65)] = x_tmp[39];
  dxdotdp[(46+ip*65)] = x_tmp[40];
  dxdotdp[(47+ip*65)] = x_tmp[41];
  dxdotdp[(48+ip*65)] = x_tmp[42];
  dxdotdp[(49+ip*65)] = x_tmp[43];

  } break;

  case 8: {
  dxdotdp[(3+ip*65)] = x_tmp[4];
  dxdotdp[(4+ip*65)] = -x_tmp[4];
  dxdotdp[(13+ip*65)] = x_tmp[14];
  dxdotdp[(14+ip*65)] = -x_tmp[14];
  dxdotdp[(22+ip*65)] = x_tmp[23];
  dxdotdp[(23+ip*65)] = -x_tmp[23];
  dxdotdp[(30+ip*65)] = x_tmp[31];
  dxdotdp[(31+ip*65)] = -x_tmp[31];
  dxdotdp[(37+ip*65)] = x_tmp[4]+x_tmp[38]*2.0;
  dxdotdp[(38+ip*65)] = -x_tmp[4]-x_tmp[38]+x_tmp[44];
  dxdotdp[(39+ip*65)] = x_tmp[45];
  dxdotdp[(40+ip*65)] = x_tmp[46];
  dxdotdp[(41+ip*65)] = x_tmp[47];
  dxdotdp[(42+ip*65)] = x_tmp[48];
  dxdotdp[(43+ip*65)] = x_tmp[49];
  dxdotdp[(44+ip*65)] = x_tmp[4]-x_tmp[44]*2.0;
  dxdotdp[(45+ip*65)] = -x_tmp[45];
  dxdotdp[(46+ip*65)] = -x_tmp[46];
  dxdotdp[(47+ip*65)] = -x_tmp[47];
  dxdotdp[(48+ip*65)] = -x_tmp[48];
  dxdotdp[(49+ip*65)] = -x_tmp[49];

  } break;

  case 9: {
  dxdotdp[(4+ip*65)] = -x_tmp[4];
  dxdotdp[(5+ip*65)] = x_tmp[4];
  dxdotdp[(14+ip*65)] = -x_tmp[14];
  dxdotdp[(15+ip*65)] = x_tmp[14];
  dxdotdp[(23+ip*65)] = -x_tmp[23];
  dxdotdp[(24+ip*65)] = x_tmp[23];
  dxdotdp[(31+ip*65)] = -x_tmp[31];
  dxdotdp[(32+ip*65)] = x_tmp[31];
  dxdotdp[(38+ip*65)] = -x_tmp[38];
  dxdotdp[(39+ip*65)] = x_tmp[38];
  dxdotdp[(44+ip*65)] = x_tmp[4]-x_tmp[44]*2.0;
  dxdotdp[(45+ip*65)] = -x_tmp[4]+x_tmp[44]-x_tmp[45];
  dxdotdp[(46+ip*65)] = -x_tmp[46];
  dxdotdp[(47+ip*65)] = -x_tmp[47];
  dxdotdp[(48+ip*65)] = -x_tmp[48];
  dxdotdp[(49+ip*65)] = -x_tmp[49];
  dxdotdp[(50+ip*65)] = x_tmp[4]+x_tmp[45]*2.0;
  dxdotdp[(51+ip*65)] = x_tmp[46];
  dxdotdp[(52+ip*65)] = x_tmp[47];
  dxdotdp[(53+ip*65)] = x_tmp[48];
  dxdotdp[(54+ip*65)] = x_tmp[49];

  } break;

  case 10: {
  dxdotdp[(4+ip*65)] = x_tmp[5];
  dxdotdp[(5+ip*65)] = -x_tmp[5];
  dxdotdp[(14+ip*65)] = x_tmp[15];
  dxdotdp[(15+ip*65)] = -x_tmp[15];
  dxdotdp[(23+ip*65)] = x_tmp[24];
  dxdotdp[(24+ip*65)] = -x_tmp[24];
  dxdotdp[(31+ip*65)] = x_tmp[32];
  dxdotdp[(32+ip*65)] = -x_tmp[32];
  dxdotdp[(38+ip*65)] = x_tmp[39];
  dxdotdp[(39+ip*65)] = -x_tmp[39];
  dxdotdp[(44+ip*65)] = x_tmp[5]+x_tmp[45]*2.0;
  dxdotdp[(45+ip*65)] = -x_tmp[5]-x_tmp[45]+x_tmp[50];
  dxdotdp[(46+ip*65)] = x_tmp[51];
  dxdotdp[(47+ip*65)] = x_tmp[52];
  dxdotdp[(48+ip*65)] = x_tmp[53];
  dxdotdp[(49+ip*65)] = x_tmp[54];
  dxdotdp[(50+ip*65)] = x_tmp[5]-x_tmp[50]*2.0;
  dxdotdp[(51+ip*65)] = -x_tmp[51];
  dxdotdp[(52+ip*65)] = -x_tmp[52];
  dxdotdp[(53+ip*65)] = -x_tmp[53];
  dxdotdp[(54+ip*65)] = -x_tmp[54];

  } break;

  case 11: {
  dxdotdp[(5+ip*65)] = -x_tmp[5];
  dxdotdp[(6+ip*65)] = x_tmp[5];
  dxdotdp[(15+ip*65)] = -x_tmp[15];
  dxdotdp[(16+ip*65)] = x_tmp[15];
  dxdotdp[(24+ip*65)] = -x_tmp[24];
  dxdotdp[(25+ip*65)] = x_tmp[24];
  dxdotdp[(32+ip*65)] = -x_tmp[32];
  dxdotdp[(33+ip*65)] = x_tmp[32];
  dxdotdp[(39+ip*65)] = -x_tmp[39];
  dxdotdp[(40+ip*65)] = x_tmp[39];
  dxdotdp[(45+ip*65)] = -x_tmp[45];
  dxdotdp[(46+ip*65)] = x_tmp[45];
  dxdotdp[(50+ip*65)] = x_tmp[5]-x_tmp[50]*2.0;
  dxdotdp[(51+ip*65)] = -x_tmp[5]+x_tmp[50]-x_tmp[51];
  dxdotdp[(52+ip*65)] = -x_tmp[52];
  dxdotdp[(53+ip*65)] = -x_tmp[53];
  dxdotdp[(54+ip*65)] = -x_tmp[54];
  dxdotdp[(55+ip*65)] = x_tmp[5]+x_tmp[51]*2.0;
  dxdotdp[(56+ip*65)] = x_tmp[52];
  dxdotdp[(57+ip*65)] = x_tmp[53];
  dxdotdp[(58+ip*65)] = x_tmp[54];

  } break;

  case 12: {
  dxdotdp[(5+ip*65)] = x_tmp[6];
  dxdotdp[(6+ip*65)] = -x_tmp[6];
  dxdotdp[(15+ip*65)] = x_tmp[16];
  dxdotdp[(16+ip*65)] = -x_tmp[16];
  dxdotdp[(24+ip*65)] = x_tmp[25];
  dxdotdp[(25+ip*65)] = -x_tmp[25];
  dxdotdp[(32+ip*65)] = x_tmp[33];
  dxdotdp[(33+ip*65)] = -x_tmp[33];
  dxdotdp[(39+ip*65)] = x_tmp[40];
  dxdotdp[(40+ip*65)] = -x_tmp[40];
  dxdotdp[(45+ip*65)] = x_tmp[46];
  dxdotdp[(46+ip*65)] = -x_tmp[46];
  dxdotdp[(50+ip*65)] = x_tmp[6]+x_tmp[51]*2.0;
  dxdotdp[(51+ip*65)] = -x_tmp[6]-x_tmp[51]+x_tmp[55];
  dxdotdp[(52+ip*65)] = x_tmp[56];
  dxdotdp[(53+ip*65)] = x_tmp[57];
  dxdotdp[(54+ip*65)] = x_tmp[58];
  dxdotdp[(55+ip*65)] = x_tmp[6]-x_tmp[55]*2.0;
  dxdotdp[(56+ip*65)] = -x_tmp[56];
  dxdotdp[(57+ip*65)] = -x_tmp[57];
  dxdotdp[(58+ip*65)] = -x_tmp[58];

  } break;

  case 13: {
  dxdotdp[(6+ip*65)] = -x_tmp[6];
  dxdotdp[(7+ip*65)] = x_tmp[6];
  dxdotdp[(16+ip*65)] = -x_tmp[16];
  dxdotdp[(17+ip*65)] = x_tmp[16];
  dxdotdp[(25+ip*65)] = -x_tmp[25];
  dxdotdp[(26+ip*65)] = x_tmp[25];
  dxdotdp[(33+ip*65)] = -x_tmp[33];
  dxdotdp[(34+ip*65)] = x_tmp[33];
  dxdotdp[(40+ip*65)] = -x_tmp[40];
  dxdotdp[(41+ip*65)] = x_tmp[40];
  dxdotdp[(46+ip*65)] = -x_tmp[46];
  dxdotdp[(47+ip*65)] = x_tmp[46];
  dxdotdp[(51+ip*65)] = -x_tmp[51];
  dxdotdp[(52+ip*65)] = x_tmp[51];
  dxdotdp[(55+ip*65)] = x_tmp[6]-x_tmp[55]*2.0;
  dxdotdp[(56+ip*65)] = -x_tmp[6]+x_tmp[55]-x_tmp[56];
  dxdotdp[(57+ip*65)] = -x_tmp[57];
  dxdotdp[(58+ip*65)] = -x_tmp[58];
  dxdotdp[(59+ip*65)] = x_tmp[6]+x_tmp[56]*2.0;
  dxdotdp[(60+ip*65)] = x_tmp[57];
  dxdotdp[(61+ip*65)] = x_tmp[58];

  } break;

  case 14: {
  dxdotdp[(6+ip*65)] = x_tmp[7];
  dxdotdp[(7+ip*65)] = -x_tmp[7];
  dxdotdp[(16+ip*65)] = x_tmp[17];
  dxdotdp[(17+ip*65)] = -x_tmp[17];
  dxdotdp[(25+ip*65)] = x_tmp[26];
  dxdotdp[(26+ip*65)] = -x_tmp[26];
  dxdotdp[(33+ip*65)] = x_tmp[34];
  dxdotdp[(34+ip*65)] = -x_tmp[34];
  dxdotdp[(40+ip*65)] = x_tmp[41];
  dxdotdp[(41+ip*65)] = -x_tmp[41];
  dxdotdp[(46+ip*65)] = x_tmp[47];
  dxdotdp[(47+ip*65)] = -x_tmp[47];
  dxdotdp[(51+ip*65)] = x_tmp[52];
  dxdotdp[(52+ip*65)] = -x_tmp[52];
  dxdotdp[(55+ip*65)] = x_tmp[7]+x_tmp[56]*2.0;
  dxdotdp[(56+ip*65)] = -x_tmp[7]-x_tmp[56]+x_tmp[59];
  dxdotdp[(57+ip*65)] = x_tmp[60];
  dxdotdp[(58+ip*65)] = x_tmp[61];
  dxdotdp[(59+ip*65)] = x_tmp[7]-x_tmp[59]*2.0;
  dxdotdp[(60+ip*65)] = -x_tmp[60];
  dxdotdp[(61+ip*65)] = -x_tmp[61];

  } break;

  case 15: {
  dxdotdp[(7+ip*65)] = -x_tmp[7];
  dxdotdp[(8+ip*65)] = x_tmp[7];
  dxdotdp[(17+ip*65)] = -x_tmp[17];
  dxdotdp[(18+ip*65)] = x_tmp[17];
  dxdotdp[(26+ip*65)] = -x_tmp[26];
  dxdotdp[(27+ip*65)] = x_tmp[26];
  dxdotdp[(34+ip*65)] = -x_tmp[34];
  dxdotdp[(35+ip*65)] = x_tmp[34];
  dxdotdp[(41+ip*65)] = -x_tmp[41];
  dxdotdp[(42+ip*65)] = x_tmp[41];
  dxdotdp[(47+ip*65)] = -x_tmp[47];
  dxdotdp[(48+ip*65)] = x_tmp[47];
  dxdotdp[(52+ip*65)] = -x_tmp[52];
  dxdotdp[(53+ip*65)] = x_tmp[52];
  dxdotdp[(56+ip*65)] = -x_tmp[56];
  dxdotdp[(57+ip*65)] = x_tmp[56];
  dxdotdp[(59+ip*65)] = x_tmp[7]-x_tmp[59]*2.0;
  dxdotdp[(60+ip*65)] = -x_tmp[7]+x_tmp[59]-x_tmp[60];
  dxdotdp[(61+ip*65)] = -x_tmp[61];
  dxdotdp[(62+ip*65)] = x_tmp[7]+x_tmp[60]*2.0;
  dxdotdp[(63+ip*65)] = x_tmp[61];

  } break;

  case 16: {
  dxdotdp[(7+ip*65)] = x_tmp[8];
  dxdotdp[(8+ip*65)] = -x_tmp[8];
  dxdotdp[(17+ip*65)] = x_tmp[18];
  dxdotdp[(18+ip*65)] = -x_tmp[18];
  dxdotdp[(26+ip*65)] = x_tmp[27];
  dxdotdp[(27+ip*65)] = -x_tmp[27];
  dxdotdp[(34+ip*65)] = x_tmp[35];
  dxdotdp[(35+ip*65)] = -x_tmp[35];
  dxdotdp[(41+ip*65)] = x_tmp[42];
  dxdotdp[(42+ip*65)] = -x_tmp[42];
  dxdotdp[(47+ip*65)] = x_tmp[48];
  dxdotdp[(48+ip*65)] = -x_tmp[48];
  dxdotdp[(52+ip*65)] = x_tmp[53];
  dxdotdp[(53+ip*65)] = -x_tmp[53];
  dxdotdp[(56+ip*65)] = x_tmp[57];
  dxdotdp[(57+ip*65)] = -x_tmp[57];
  dxdotdp[(59+ip*65)] = x_tmp[8]+x_tmp[60]*2.0;
  dxdotdp[(60+ip*65)] = -x_tmp[8]-x_tmp[60]+x_tmp[62];
  dxdotdp[(61+ip*65)] = x_tmp[63];
  dxdotdp[(62+ip*65)] = x_tmp[8]-x_tmp[62]*2.0;
  dxdotdp[(63+ip*65)] = -x_tmp[63];

  } break;

  case 17: {
  dxdotdp[(8+ip*65)] = -x_tmp[8];
  dxdotdp[(9+ip*65)] = x_tmp[8];
  dxdotdp[(18+ip*65)] = -x_tmp[18];
  dxdotdp[(19+ip*65)] = x_tmp[18];
  dxdotdp[(27+ip*65)] = -x_tmp[27];
  dxdotdp[(28+ip*65)] = x_tmp[27];
  dxdotdp[(35+ip*65)] = -x_tmp[35];
  dxdotdp[(36+ip*65)] = x_tmp[35];
  dxdotdp[(42+ip*65)] = -x_tmp[42];
  dxdotdp[(43+ip*65)] = x_tmp[42];
  dxdotdp[(48+ip*65)] = -x_tmp[48];
  dxdotdp[(49+ip*65)] = x_tmp[48];
  dxdotdp[(53+ip*65)] = -x_tmp[53];
  dxdotdp[(54+ip*65)] = x_tmp[53];
  dxdotdp[(57+ip*65)] = -x_tmp[57];
  dxdotdp[(58+ip*65)] = x_tmp[57];
  dxdotdp[(60+ip*65)] = -x_tmp[60];
  dxdotdp[(61+ip*65)] = x_tmp[60];
  dxdotdp[(62+ip*65)] = x_tmp[8]-x_tmp[62]*2.0;
  dxdotdp[(63+ip*65)] = -x_tmp[8]+x_tmp[62]-x_tmp[63];
  dxdotdp[(64+ip*65)] = x_tmp[8]+x_tmp[63]*2.0;

  } break;

  case 18: {
  dxdotdp[(8+ip*65)] = x_tmp[9];
  dxdotdp[(9+ip*65)] = -x_tmp[9];
  dxdotdp[(18+ip*65)] = x_tmp[19];
  dxdotdp[(19+ip*65)] = -x_tmp[19];
  dxdotdp[(27+ip*65)] = x_tmp[28];
  dxdotdp[(28+ip*65)] = -x_tmp[28];
  dxdotdp[(35+ip*65)] = x_tmp[36];
  dxdotdp[(36+ip*65)] = -x_tmp[36];
  dxdotdp[(42+ip*65)] = x_tmp[43];
  dxdotdp[(43+ip*65)] = -x_tmp[43];
  dxdotdp[(48+ip*65)] = x_tmp[49];
  dxdotdp[(49+ip*65)] = -x_tmp[49];
  dxdotdp[(53+ip*65)] = x_tmp[54];
  dxdotdp[(54+ip*65)] = -x_tmp[54];
  dxdotdp[(57+ip*65)] = x_tmp[58];
  dxdotdp[(58+ip*65)] = -x_tmp[58];
  dxdotdp[(60+ip*65)] = x_tmp[61];
  dxdotdp[(61+ip*65)] = -x_tmp[61];
  dxdotdp[(62+ip*65)] = x_tmp[9]+x_tmp[63]*2.0;
  dxdotdp[(63+ip*65)] = -x_tmp[9]-x_tmp[63]+x_tmp[64];
  dxdotdp[(64+ip*65)] = x_tmp[9]-x_tmp[64]*2.0;

  } break;

  case 19: {
  dxdotdp[(9+ip*65)] = -x_tmp[9];
  dxdotdp[(19+ip*65)] = -x_tmp[19];
  dxdotdp[(28+ip*65)] = -x_tmp[28];
  dxdotdp[(36+ip*65)] = -x_tmp[36];
  dxdotdp[(43+ip*65)] = -x_tmp[43];
  dxdotdp[(49+ip*65)] = -x_tmp[49];
  dxdotdp[(54+ip*65)] = -x_tmp[54];
  dxdotdp[(58+ip*65)] = -x_tmp[58];
  dxdotdp[(61+ip*65)] = -x_tmp[61];
  dxdotdp[(63+ip*65)] = -x_tmp[63];
  dxdotdp[(64+ip*65)] = x_tmp[9]-x_tmp[64]*2.0;

  } break;

}
}
int ix;
for(ip = 0; ip<np; ip++) {
   for(ix = 0; ix<65; ix++) {
       if(mxIsNaN(dxdotdp[ix+ip*65])) {
           dxdotdp[ix+ip*65] = 0;
           if(!udata->am_nan_dxdotdp) {
               mexWarnMsgIdAndTxt("AMICI:mex:fdxdotdp:NaN","AMICI replaced a NaN value in dxdotdp and replaced it by 0.0. This will not be reported again.");
               udata->am_nan_dxdotdp = TRUE;
           }
       }
       if(mxIsInf(dxdotdp[ix+ip*65])) {
           mexWarnMsgIdAndTxt("AMICI:mex:fdxdotdp:Inf","AMICI encountered an Inf value in dxdotdp, aborting.");
           return(-1);
       }
   }
}
return(0);

}


