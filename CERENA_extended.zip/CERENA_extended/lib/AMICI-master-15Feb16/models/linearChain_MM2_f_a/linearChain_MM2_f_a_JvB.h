#ifndef _am_linearChain_MM2_f_a_JvB_h
#define _am_linearChain_MM2_f_a_JvB_h

int JvB_linearChain_MM2_f_a(N_Vector vB, N_Vector JvB, realtype t, N_Vector x, N_Vector xB, N_Vector xBdot, void *user_data, N_Vector tmpB);


#endif /* _am_linearChain_MM2_f_a_JvB_h */
