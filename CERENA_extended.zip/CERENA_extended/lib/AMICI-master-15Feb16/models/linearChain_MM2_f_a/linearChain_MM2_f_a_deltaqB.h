#ifndef _am_linearChain_MM2_f_a_deltaqB_h
#define _am_linearChain_MM2_f_a_deltaqB_h

int deltaqB_linearChain_MM2_f_a(realtype t, int ie, realtype *deltaqB, N_Vector x, N_Vector xB, N_Vector qBdot, N_Vector xdot, N_Vector xdot_old, void *user_data);


#endif /* _am_linearChain_MM2_f_a_deltaqB_h */
