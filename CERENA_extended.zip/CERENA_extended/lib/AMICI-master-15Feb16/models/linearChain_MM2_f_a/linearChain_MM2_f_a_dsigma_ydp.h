#ifndef _am_linearChain_MM2_f_a_dsigma_ydp_h
#define _am_linearChain_MM2_f_a_dsigma_ydp_h

int dsigma_ydp_linearChain_MM2_f_a(realtype t, realtype *dsigma_ydp, void *user_data);


#endif /* _am_linearChain_MM2_f_a_dsigma_ydp_h */
