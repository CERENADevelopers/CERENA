#ifndef _am_linearChain_MM2_f_a_Jy_h
#define _am_linearChain_MM2_f_a_Jy_h

int Jy_linearChain_MM2_f_a(realtype t, int it, realtype *Jy, realtype *y, N_Vector x, realtype *my, realtype *sd_y, void *user_data);


#endif /* _am_linearChain_MM2_f_a_Jy_h */
