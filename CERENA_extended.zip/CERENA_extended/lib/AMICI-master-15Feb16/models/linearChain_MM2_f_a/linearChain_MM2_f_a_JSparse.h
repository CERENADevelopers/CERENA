#ifndef _am_linearChain_MM2_f_a_JSparse_h
#define _am_linearChain_MM2_f_a_JSparse_h

int JSparse_linearChain_MM2_f_a(realtype t, N_Vector x, N_Vector xdot, SlsMat J, void *user_data, N_Vector tmp1, N_Vector tmp2, N_Vector tmp3);


#endif /* _am_linearChain_MM2_f_a_JSparse_h */
