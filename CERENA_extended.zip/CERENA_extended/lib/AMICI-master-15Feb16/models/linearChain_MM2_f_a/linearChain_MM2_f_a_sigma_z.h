#ifndef _am_linearChain_MM2_f_a_sigma_z_h
#define _am_linearChain_MM2_f_a_sigma_z_h

int sigma_z_linearChain_MM2_f_a(realtype t, int ie, realtype *sigma_z, void *user_data);


#endif /* _am_linearChain_MM2_f_a_sigma_z_h */
