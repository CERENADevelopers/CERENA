#ifndef _am_linearChain_MM2_f_a_h
#define _am_linearChain_MM2_f_a_h

#include "linearChain_MM2_f_a_J.h"
#include "linearChain_MM2_f_a_JB.h"
#include "linearChain_MM2_f_a_JBand.h"
#include "linearChain_MM2_f_a_JBandB.h"
#include "linearChain_MM2_f_a_JSparse.h"
#include "linearChain_MM2_f_a_JSparseB.h"
#include "linearChain_MM2_f_a_Jv.h"
#include "linearChain_MM2_f_a_JvB.h"
#include "linearChain_MM2_f_a_Jy.h"
#include "linearChain_MM2_f_a_Jz.h"
#include "linearChain_MM2_f_a_dJydp.h"
#include "linearChain_MM2_f_a_dJydx.h"
#include "linearChain_MM2_f_a_dJzdp.h"
#include "linearChain_MM2_f_a_dJzdx.h"
#include "linearChain_MM2_f_a_deltaqB.h"
#include "linearChain_MM2_f_a_deltasx.h"
#include "linearChain_MM2_f_a_deltax.h"
#include "linearChain_MM2_f_a_deltaxB.h"
#include "linearChain_MM2_f_a_dsigma_ydp.h"
#include "linearChain_MM2_f_a_dsigma_zdp.h"
#include "linearChain_MM2_f_a_dxdotdp.h"
#include "linearChain_MM2_f_a_dydp.h"
#include "linearChain_MM2_f_a_dydx.h"
#include "linearChain_MM2_f_a_dzdp.h"
#include "linearChain_MM2_f_a_dzdx.h"
#include "linearChain_MM2_f_a_qBdot.h"
#include "linearChain_MM2_f_a_root.h"
#include "linearChain_MM2_f_a_sJy.h"
#include "linearChain_MM2_f_a_sJz.h"
#include "linearChain_MM2_f_a_sigma_y.h"
#include "linearChain_MM2_f_a_sigma_z.h"
#include "linearChain_MM2_f_a_stau.h"
#include "linearChain_MM2_f_a_sx0.h"
#include "linearChain_MM2_f_a_sxdot.h"
#include "linearChain_MM2_f_a_sy.h"
#include "linearChain_MM2_f_a_sz.h"
#include "linearChain_MM2_f_a_sz_tf.h"
#include "linearChain_MM2_f_a_x0.h"
#include "linearChain_MM2_f_a_xBdot.h"
#include "linearChain_MM2_f_a_xdot.h"
#include "linearChain_MM2_f_a_y.h"
#include "linearChain_MM2_f_a_z.h"

int J_linearChain_MM2_f_a(long int N, realtype t, N_Vector x, N_Vector xdot, DlsMat J, void *user_data, N_Vector tmp1, N_Vector tmp2, N_Vector tmp3);
int JB_linearChain_MM2_f_a(long int NeqBdot, realtype t, N_Vector x, N_Vector xB, N_Vector xBdot, DlsMat JB, void *user_data, N_Vector tmp1B, N_Vector tmp2B, N_Vector tmp3B);
int JBand_linearChain_MM2_f_a(long int N, long int mupper, long int mlower, realtype t, N_Vector x, N_Vector xdot, DlsMat J, void *user_data, N_Vector tmp1, N_Vector tmp2, N_Vector tmp3);
int JBandB_linearChain_MM2_f_a(long int NeqBdot, long int mupper, long int mlower, realtype t, N_Vector x, N_Vector xB, N_Vector xBdot, DlsMat JB, void *user_data, N_Vector tmp1B, N_Vector tmp2B, N_Vector tmp3B);
int JSparse_linearChain_MM2_f_a(realtype t, N_Vector x, N_Vector xdot, SlsMat J, void *user_data, N_Vector tmp1, N_Vector tmp2, N_Vector tmp3);
int JSparseB_linearChain_MM2_f_a(realtype t, N_Vector x, N_Vector xB, N_Vector xBdot, SlsMat JB, void *user_data, N_Vector tmp1B, N_Vector tmp2B, N_Vector tmp3B);
int Jv_linearChain_MM2_f_a(N_Vector v, N_Vector Jv, realtype t, N_Vector x, N_Vector xdot, void *user_data, N_Vector tmp);
int JvB_linearChain_MM2_f_a(N_Vector vB, N_Vector JvB, realtype t, N_Vector x, N_Vector xB, N_Vector xBdot, void *user_data, N_Vector tmpB);
int Jy_linearChain_MM2_f_a(realtype t, int it, realtype *Jy, realtype *y, N_Vector x, realtype *my, realtype *sd_y, void *user_data);
int Jz_linearChain_MM2_f_a(realtype t, int ie, realtype *Jz, realtype *z, N_Vector x, realtype *mz, realtype *sd_z, void *user_data, void *temp_data);
int dJydp_linearChain_MM2_f_a(realtype t, int it, realtype *dJydp, realtype *y, N_Vector x, realtype *dydp, realtype *my, realtype *sd_y, realtype *dsigma_ydp, void *user_data);
int dJydx_linearChain_MM2_f_a(realtype t, int it, realtype *dJydx, realtype *y, N_Vector x, realtype *dydx, realtype *my, realtype *sd_y, void *user_data);
int dJzdp_linearChain_MM2_f_a(realtype t, int ie, realtype *dJzdp, realtype *z, N_Vector x, realtype *dzdp, realtype *mz, realtype *sd_z, realtype *dsigma_zdp, void *user_data, void *temp_data);
int dJzdx_linearChain_MM2_f_a(realtype t, int ie, realtype *dJzdx, realtype *z, N_Vector x, realtype *dzdx, realtype *mz, realtype *sd_z, void *user_data, void *temp_data);
int deltaqB_linearChain_MM2_f_a(realtype t, int ie, realtype *deltaqB, N_Vector x, N_Vector xB, N_Vector qBdot, N_Vector xdot, N_Vector xdot_old, void *user_data);
int deltasx_linearChain_MM2_f_a(realtype t, int ie, realtype *deltasx, N_Vector x, N_Vector xdot, N_Vector xdot_old, N_Vector *sx, void *user_data);
int deltax_linearChain_MM2_f_a(realtype t, int ie, realtype *deltax, N_Vector x, N_Vector xdot, N_Vector xdot_old, void *user_data);
int deltaxB_linearChain_MM2_f_a(realtype t, int ie, realtype *deltaxB, N_Vector x, N_Vector xB, N_Vector xdot, N_Vector xdot_old, void *user_data);
int dsigma_ydp_linearChain_MM2_f_a(realtype t, realtype *dsigma_ydp, void *user_data);
int dsigma_zdp_linearChain_MM2_f_a(realtype t, int ie, realtype *dsigma_zdp, void *user_data);
int dxdotdp_linearChain_MM2_f_a(realtype t, realtype *dxdotdp, N_Vector x, void *user_data);
int dydp_linearChain_MM2_f_a(realtype t, int it, realtype *dydp, N_Vector x, void *user_data);
int dydx_linearChain_MM2_f_a(realtype t, int it, realtype *dydx, N_Vector x, void *user_data);
int dzdp_linearChain_MM2_f_a(realtype t, int ie, realtype *dzdp, N_Vector x, void *user_data);
int dzdx_linearChain_MM2_f_a(realtype t, int ie, realtype *dzdx, N_Vector x, void *user_data);
int qBdot_linearChain_MM2_f_a(realtype t, N_Vector x, N_Vector xB, N_Vector qBdot, void *user_data);
int root_linearChain_MM2_f_a(realtype t, N_Vector x, realtype *root, void *user_data);
int sJy_linearChain_MM2_f_a(realtype t, int it, realtype *sJy, realtype *y, N_Vector x, realtype *dydp, realtype *sy, realtype *my, realtype *sd_y, realtype *dsigma_ydp, void *user_data);
int sJz_linearChain_MM2_f_a(realtype t, int ie, realtype *sJz, realtype *z, N_Vector x, realtype *dzdp, realtype *sz, realtype *mz, realtype *sd_z, realtype *dsigma_zdp, void *user_data, void *temp_data);
int sigma_y_linearChain_MM2_f_a(realtype t, realtype *sigma_y, void *user_data);
int sigma_z_linearChain_MM2_f_a(realtype t, int ie, realtype *sigma_z, void *user_data);
int stau_linearChain_MM2_f_a(realtype t, int ie, realtype *stau, N_Vector x, N_Vector *sx, void *user_data);
int sx0_linearChain_MM2_f_a(N_Vector *sx0, N_Vector x, N_Vector dx, void *user_data);
int sxdot_linearChain_MM2_f_a(int Ns, realtype t, N_Vector x, N_Vector xdot,int ip,  N_Vector sx, N_Vector sxdot, void *user_data, N_Vector tmp1, N_Vector tmp2);
int sy_linearChain_MM2_f_a(realtype t, int it, realtype *sy, N_Vector x, N_Vector *sx, void *user_data);
int sz_linearChain_MM2_f_a(realtype t, int ie, int *nroots, realtype *sz, N_Vector x, N_Vector *sx, void *user_data);
int sz_tf_linearChain_MM2_f_a(realtype t, int ie, int *nroots, realtype *sz, N_Vector x, N_Vector *sx, void *user_data);
int x0_linearChain_MM2_f_a(N_Vector x0, void *user_data);
int xBdot_linearChain_MM2_f_a(realtype t, N_Vector x, N_Vector xB, N_Vector xBdot, void *user_data);
int xdot_linearChain_MM2_f_a(realtype t, N_Vector x, N_Vector xdot, void *user_data);
int y_linearChain_MM2_f_a(realtype t, int it, realtype *y, N_Vector x, void *user_data);
int z_linearChain_MM2_f_a(realtype t, int ie, int *nroots, realtype *z, N_Vector x, void *user_data);


#endif /* _am_linearChain_MM2_f_a_h */
