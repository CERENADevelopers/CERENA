#ifndef _am_AMICI_genExp_timeDep_y_h
#define _am_AMICI_genExp_timeDep_y_h

int y_AMICI_genExp_timeDep(realtype t, int it, realtype *y, N_Vector x, void *user_data);


#endif /* _am_AMICI_genExp_timeDep_y_h */
