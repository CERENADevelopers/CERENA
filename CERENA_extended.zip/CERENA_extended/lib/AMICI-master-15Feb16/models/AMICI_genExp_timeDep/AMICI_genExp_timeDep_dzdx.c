
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int dzdx_AMICI_genExp_timeDep(realtype t, int ie, realtype *dzdx, N_Vector x, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
return(0);

}


