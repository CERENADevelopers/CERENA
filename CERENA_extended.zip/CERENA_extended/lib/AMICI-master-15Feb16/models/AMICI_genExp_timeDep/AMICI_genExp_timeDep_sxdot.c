
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>
#include "AMICI_genExp_timeDep_JSparse.h"
#include "AMICI_genExp_timeDep_dxdotdp.h"

int sxdot_AMICI_genExp_timeDep(int Ns, realtype t, N_Vector x, N_Vector xdot,int ip,  N_Vector sx, N_Vector sxdot, void *user_data, N_Vector tmp1, N_Vector tmp2) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *sx_tmp = N_VGetArrayPointer(sx);
realtype *sxdot_tmp = N_VGetArrayPointer(sxdot);
realtype *xdot_tmp = N_VGetArrayPointer(xdot);
memset(sxdot_tmp,0,sizeof(realtype)*14);
int status = 0;
if(ip == 0) {
    status = JSparse_AMICI_genExp_timeDep(t,x,xdot,tmp_J,user_data,NULL,NULL,NULL);
    status = dxdotdp_AMICI_genExp_timeDep(t,tmp_dxdotdp,x,user_data);
}
  sxdot_tmp[0] = tmp_dxdotdp[0 + ip*14]+sx_tmp[0]*tmp_J->data[0]+sx_tmp[1]*tmp_J->data[9]+sx_tmp[3]*tmp_J->data[20]+sx_tmp[7]*tmp_J->data[40];
  sxdot_tmp[1] = tmp_dxdotdp[1 + ip*14]+sx_tmp[0]*tmp_J->data[1]+sx_tmp[1]*tmp_J->data[10]+sx_tmp[3]*tmp_J->data[21]+sx_tmp[7]*tmp_J->data[41];
  sxdot_tmp[2] = tmp_dxdotdp[2 + ip*14]+sx_tmp[1]*tmp_J->data[11]+sx_tmp[2]*tmp_J->data[16];
  sxdot_tmp[3] = tmp_dxdotdp[3 + ip*14]+sx_tmp[2]*tmp_J->data[17]+sx_tmp[3]*tmp_J->data[22];
  sxdot_tmp[4] = tmp_dxdotdp[4 + ip*14]+sx_tmp[0]*tmp_J->data[2]+sx_tmp[1]*tmp_J->data[12]+sx_tmp[3]*tmp_J->data[23]+sx_tmp[4]*tmp_J->data[31]+sx_tmp[5]*tmp_J->data[33]+sx_tmp[7]*tmp_J->data[42];
  sxdot_tmp[5] = tmp_dxdotdp[5 + ip*14]+sx_tmp[0]*tmp_J->data[3]+sx_tmp[1]*tmp_J->data[13]+sx_tmp[3]*tmp_J->data[24]+sx_tmp[4]*tmp_J->data[32]+sx_tmp[5]*tmp_J->data[34]+sx_tmp[7]*tmp_J->data[43]+sx_tmp[8]*tmp_J->data[47]+sx_tmp[10]*tmp_J->data[54];
  sxdot_tmp[6] = tmp_dxdotdp[6 + ip*14]+sx_tmp[0]*tmp_J->data[4]+sx_tmp[3]*tmp_J->data[25]+sx_tmp[5]*tmp_J->data[35]+sx_tmp[6]*tmp_J->data[37]+sx_tmp[9]*tmp_J->data[50]+sx_tmp[12]*tmp_J->data[61];
  sxdot_tmp[7] = tmp_dxdotdp[7 + ip*14]+sx_tmp[0]*tmp_J->data[5]+sx_tmp[3]*tmp_J->data[26]+sx_tmp[6]*tmp_J->data[38]+sx_tmp[7]*tmp_J->data[44]+sx_tmp[10]*tmp_J->data[55]+sx_tmp[13]*tmp_J->data[65];
  sxdot_tmp[8] = tmp_dxdotdp[8 + ip*14]+sx_tmp[0]*tmp_J->data[6]+sx_tmp[1]*tmp_J->data[14]+sx_tmp[3]*tmp_J->data[27]+sx_tmp[5]*tmp_J->data[36]+sx_tmp[7]*tmp_J->data[45]+sx_tmp[8]*tmp_J->data[48]+sx_tmp[10]*tmp_J->data[56];
  sxdot_tmp[9] = tmp_dxdotdp[9 + ip*14]+sx_tmp[0]*tmp_J->data[7]+sx_tmp[3]*tmp_J->data[28]+sx_tmp[6]*tmp_J->data[39]+sx_tmp[8]*tmp_J->data[49]+sx_tmp[9]*tmp_J->data[51]+sx_tmp[12]*tmp_J->data[62];
  sxdot_tmp[10] = tmp_dxdotdp[10 + ip*14]+sx_tmp[0]*tmp_J->data[8]+sx_tmp[3]*tmp_J->data[29]+sx_tmp[7]*tmp_J->data[46]+sx_tmp[9]*tmp_J->data[52]+sx_tmp[10]*tmp_J->data[57]+sx_tmp[13]*tmp_J->data[66];
  sxdot_tmp[11] = tmp_dxdotdp[11 + ip*14]+sx_tmp[1]*tmp_J->data[15]+sx_tmp[2]*tmp_J->data[18]+sx_tmp[9]*tmp_J->data[53]+sx_tmp[11]*tmp_J->data[59];
  sxdot_tmp[12] = tmp_dxdotdp[12 + ip*14]+sx_tmp[10]*tmp_J->data[58]+sx_tmp[11]*tmp_J->data[60]+sx_tmp[12]*tmp_J->data[63];
  sxdot_tmp[13] = tmp_dxdotdp[13 + ip*14]+sx_tmp[2]*tmp_J->data[19]+sx_tmp[3]*tmp_J->data[30]+sx_tmp[12]*tmp_J->data[64]+sx_tmp[13]*tmp_J->data[67];
return(status);

}


