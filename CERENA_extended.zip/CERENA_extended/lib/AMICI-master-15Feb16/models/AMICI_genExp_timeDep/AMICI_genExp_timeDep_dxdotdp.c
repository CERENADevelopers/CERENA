
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int dxdotdp_AMICI_genExp_timeDep(realtype t, realtype *dxdotdp, N_Vector x, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
memset(dxdotdp,0,sizeof(realtype)*14*np);
int ip;
for(ip = 0; ip<np; ip++) {
switch (plist[ip]) {
  case 0: {
  dxdotdp[(0+ip*14)] = -x_tmp[0];
  dxdotdp[(1+ip*14)] = x_tmp[0];
  dxdotdp[(4+ip*14)] = 1.0/(k[0]*k[0])*(k[0]*x_tmp[0]-(k[0]*k[0])*x_tmp[4]*2.0);
  dxdotdp[(5+ip*14)] = -1.0/(k[0]*k[0])*(k[0]*x_tmp[0]-(k[0]*k[0])*x_tmp[4]+(k[0]*k[0])*x_tmp[5]);
  dxdotdp[(6+ip*14)] = -x_tmp[6];
  dxdotdp[(7+ip*14)] = -x_tmp[7];
  dxdotdp[(8+ip*14)] = 1.0/(k[0]*k[0])*(k[0]*x_tmp[0]+(k[0]*k[0])*x_tmp[5]*2.0);
  dxdotdp[(9+ip*14)] = x_tmp[6];
  dxdotdp[(10+ip*14)] = x_tmp[7];

  } break;

  case 1: {
  dxdotdp[(0+ip*14)] = x_tmp[1];
  dxdotdp[(1+ip*14)] = -x_tmp[1];
  dxdotdp[(4+ip*14)] = 1.0/(k[0]*k[0])*(k[0]*x_tmp[1]+(k[0]*k[0])*x_tmp[5]*2.0);
  dxdotdp[(5+ip*14)] = -1.0/(k[0]*k[0])*(k[0]*x_tmp[1]+(k[0]*k[0])*x_tmp[5]-(k[0]*k[0])*x_tmp[8]);
  dxdotdp[(6+ip*14)] = x_tmp[9];
  dxdotdp[(7+ip*14)] = x_tmp[10];
  dxdotdp[(8+ip*14)] = 1.0/(k[0]*k[0])*(k[0]*x_tmp[1]-(k[0]*k[0])*x_tmp[8]*2.0);
  dxdotdp[(9+ip*14)] = -x_tmp[9];
  dxdotdp[(10+ip*14)] = -x_tmp[10];

  } break;

  case 2: {
  dxdotdp[(2+ip*14)] = x_tmp[1];
  dxdotdp[(6+ip*14)] = x_tmp[5];
  dxdotdp[(9+ip*14)] = x_tmp[8];
  dxdotdp[(11+ip*14)] = 1.0/(k[0]*k[0])*(k[0]*x_tmp[1]+(k[0]*k[0])*x_tmp[9]*2.0);
  dxdotdp[(12+ip*14)] = x_tmp[10];

  } break;

  case 3: {
  dxdotdp[(2+ip*14)] = -x_tmp[2];
  dxdotdp[(6+ip*14)] = -x_tmp[6];
  dxdotdp[(9+ip*14)] = -x_tmp[9];
  dxdotdp[(11+ip*14)] = 1.0/(k[0]*k[0])*(k[0]*x_tmp[2]-(k[0]*k[0])*x_tmp[11]*2.0);
  dxdotdp[(12+ip*14)] = -x_tmp[12];

  } break;

  case 4: {
  dxdotdp[(3+ip*14)] = t*x_tmp[2];
  dxdotdp[(7+ip*14)] = t*x_tmp[6];
  dxdotdp[(10+ip*14)] = t*x_tmp[9];
  dxdotdp[(12+ip*14)] = t*x_tmp[11];
  dxdotdp[(13+ip*14)] = 1.0/(k[0]*k[0])*((k[0]*k[0])*t*x_tmp[12]*2.0+k[0]*t*x_tmp[2]);

  } break;

  case 5: {
  dxdotdp[(3+ip*14)] = -x_tmp[3];
  dxdotdp[(7+ip*14)] = -x_tmp[7];
  dxdotdp[(10+ip*14)] = -x_tmp[10];
  dxdotdp[(12+ip*14)] = -x_tmp[12];
  dxdotdp[(13+ip*14)] = 1.0/(k[0]*k[0])*(k[0]*x_tmp[3]-(k[0]*k[0])*x_tmp[13]*2.0);

  } break;

  case 6: {
  dxdotdp[(0+ip*14)] = -((k[0]*k[0])*x_tmp[7]+(k[0]*k[0])*x_tmp[0]*x_tmp[3])/k[0];
  dxdotdp[(1+ip*14)] = ((k[0]*k[0])*x_tmp[7]+(k[0]*k[0])*x_tmp[0]*x_tmp[3])/k[0];
  dxdotdp[(4+ip*14)] = 1.0/(k[0]*k[0])*((k[0]*k[0])*x_tmp[7]+(k[0]*k[0])*x_tmp[0]*x_tmp[3]-(k[0]*k[0]*k[0])*x_tmp[0]*x_tmp[7]*2.0-(k[0]*k[0]*k[0])*x_tmp[3]*x_tmp[4]*2.0);
  dxdotdp[(5+ip*14)] = -1.0/(k[0]*k[0])*((k[0]*k[0])*x_tmp[7]+(k[0]*k[0])*x_tmp[0]*x_tmp[3]-(k[0]*k[0]*k[0])*x_tmp[0]*x_tmp[7]-(k[0]*k[0]*k[0])*x_tmp[3]*x_tmp[4]+(k[0]*k[0]*k[0])*x_tmp[3]*x_tmp[5]+(k[0]*k[0]*k[0])*x_tmp[0]*x_tmp[10]);
  dxdotdp[(6+ip*14)] = -1.0/(k[0]*k[0])*((k[0]*k[0]*k[0])*x_tmp[3]*x_tmp[6]+(k[0]*k[0]*k[0])*x_tmp[0]*x_tmp[12]);
  dxdotdp[(7+ip*14)] = -1.0/(k[0]*k[0])*((k[0]*k[0]*k[0])*x_tmp[3]*x_tmp[7]+(k[0]*k[0]*k[0])*x_tmp[0]*x_tmp[13]);
  dxdotdp[(8+ip*14)] = 1.0/(k[0]*k[0])*((k[0]*k[0])*x_tmp[7]+(k[0]*k[0])*x_tmp[0]*x_tmp[3]+(k[0]*k[0]*k[0])*x_tmp[3]*x_tmp[5]*2.0+(k[0]*k[0]*k[0])*x_tmp[0]*x_tmp[10]*2.0);
  dxdotdp[(9+ip*14)] = 1.0/(k[0]*k[0])*((k[0]*k[0]*k[0])*x_tmp[3]*x_tmp[6]+(k[0]*k[0]*k[0])*x_tmp[0]*x_tmp[12]);
  dxdotdp[(10+ip*14)] = 1.0/(k[0]*k[0])*((k[0]*k[0]*k[0])*x_tmp[3]*x_tmp[7]+(k[0]*k[0]*k[0])*x_tmp[0]*x_tmp[13]);

  } break;

}
}
int ix;
for(ip = 0; ip<np; ip++) {
   for(ix = 0; ix<14; ix++) {
       if(mxIsNaN(dxdotdp[ix+ip*14])) {
           dxdotdp[ix+ip*14] = 0;
           if(!udata->am_nan_dxdotdp) {
               mexWarnMsgIdAndTxt("AMICI:mex:fdxdotdp:NaN","AMICI replaced a NaN value in dxdotdp and replaced it by 0.0. This will not be reported again.");
               udata->am_nan_dxdotdp = TRUE;
           }
       }
       if(mxIsInf(dxdotdp[ix+ip*14])) {
           mexWarnMsgIdAndTxt("AMICI:mex:fdxdotdp:Inf","AMICI encountered an Inf value in dxdotdp, aborting.");
           return(-1);
       }
   }
}
return(0);

}


