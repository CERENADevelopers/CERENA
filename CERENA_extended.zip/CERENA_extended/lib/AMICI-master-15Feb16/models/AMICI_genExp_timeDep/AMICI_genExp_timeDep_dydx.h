#ifndef _am_AMICI_genExp_timeDep_dydx_h
#define _am_AMICI_genExp_timeDep_dydx_h

int dydx_AMICI_genExp_timeDep(realtype t, int it, realtype *dydx, N_Vector x, void *user_data);


#endif /* _am_AMICI_genExp_timeDep_dydx_h */
