#ifndef _am_AMICI_genExp_timeDep_sJy_h
#define _am_AMICI_genExp_timeDep_sJy_h

int sJy_AMICI_genExp_timeDep(realtype t, int it, realtype *sJy, realtype *y, N_Vector x, realtype *dydp, realtype *sy, realtype *my, realtype *sd_y, realtype *dsigma_ydp, void *user_data);


#endif /* _am_AMICI_genExp_timeDep_sJy_h */
