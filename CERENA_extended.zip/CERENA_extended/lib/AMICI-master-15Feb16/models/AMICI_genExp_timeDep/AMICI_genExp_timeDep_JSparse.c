
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int JSparse_AMICI_genExp_timeDep(realtype t, N_Vector x, N_Vector xdot, SlsMat J, void *user_data, N_Vector tmp1, N_Vector tmp2, N_Vector tmp3) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *xdot_tmp = N_VGetArrayPointer(xdot);
SlsSetToZero(J);
J->rowvals[0] = 0;
J->rowvals[1] = 1;
J->rowvals[2] = 4;
J->rowvals[3] = 5;
J->rowvals[4] = 6;
J->rowvals[5] = 7;
J->rowvals[6] = 8;
J->rowvals[7] = 9;
J->rowvals[8] = 10;
J->rowvals[9] = 0;
J->rowvals[10] = 1;
J->rowvals[11] = 2;
J->rowvals[12] = 4;
J->rowvals[13] = 5;
J->rowvals[14] = 8;
J->rowvals[15] = 11;
J->rowvals[16] = 2;
J->rowvals[17] = 3;
J->rowvals[18] = 11;
J->rowvals[19] = 13;
J->rowvals[20] = 0;
J->rowvals[21] = 1;
J->rowvals[22] = 3;
J->rowvals[23] = 4;
J->rowvals[24] = 5;
J->rowvals[25] = 6;
J->rowvals[26] = 7;
J->rowvals[27] = 8;
J->rowvals[28] = 9;
J->rowvals[29] = 10;
J->rowvals[30] = 13;
J->rowvals[31] = 4;
J->rowvals[32] = 5;
J->rowvals[33] = 4;
J->rowvals[34] = 5;
J->rowvals[35] = 6;
J->rowvals[36] = 8;
J->rowvals[37] = 6;
J->rowvals[38] = 7;
J->rowvals[39] = 9;
J->rowvals[40] = 0;
J->rowvals[41] = 1;
J->rowvals[42] = 4;
J->rowvals[43] = 5;
J->rowvals[44] = 7;
J->rowvals[45] = 8;
J->rowvals[46] = 10;
J->rowvals[47] = 5;
J->rowvals[48] = 8;
J->rowvals[49] = 9;
J->rowvals[50] = 6;
J->rowvals[51] = 9;
J->rowvals[52] = 10;
J->rowvals[53] = 11;
J->rowvals[54] = 5;
J->rowvals[55] = 7;
J->rowvals[56] = 8;
J->rowvals[57] = 10;
J->rowvals[58] = 12;
J->rowvals[59] = 11;
J->rowvals[60] = 12;
J->rowvals[61] = 6;
J->rowvals[62] = 9;
J->rowvals[63] = 12;
J->rowvals[64] = 13;
J->rowvals[65] = 7;
J->rowvals[66] = 10;
J->rowvals[67] = 13;
J->colptrs[0] = 0;
J->colptrs[1] = 9;
J->colptrs[2] = 16;
J->colptrs[3] = 20;
J->colptrs[4] = 31;
J->colptrs[5] = 33;
J->colptrs[6] = 37;
J->colptrs[7] = 40;
J->colptrs[8] = 47;
J->colptrs[9] = 50;
J->colptrs[10] = 54;
J->colptrs[11] = 59;
J->colptrs[12] = 61;
J->colptrs[13] = 65;
J->colptrs[14] = 68;
  J->data[0] = -(k[0]*p[0]+(k[0]*k[0])*p[6]*x_tmp[3])/k[0];
  J->data[1] = (k[0]*p[0]+(k[0]*k[0])*p[6]*x_tmp[3])/k[0];
  J->data[2] = 1.0/(k[0]*k[0])*(k[0]*p[0]+(k[0]*k[0])*p[6]*x_tmp[3]-(k[0]*k[0]*k[0])*p[6]*x_tmp[7]*2.0);
  J->data[3] = -1.0/(k[0]*k[0])*(k[0]*p[0]+(k[0]*k[0])*p[6]*x_tmp[3]-(k[0]*k[0]*k[0])*p[6]*x_tmp[7]+(k[0]*k[0]*k[0])*p[6]*x_tmp[10]);
  J->data[4] = -k[0]*p[6]*x_tmp[12];
  J->data[5] = -k[0]*p[6]*x_tmp[13];
  J->data[6] = 1.0/(k[0]*k[0])*(k[0]*p[0]+(k[0]*k[0])*p[6]*x_tmp[3]+(k[0]*k[0]*k[0])*p[6]*x_tmp[10]*2.0);
  J->data[7] = k[0]*p[6]*x_tmp[12];
  J->data[8] = k[0]*p[6]*x_tmp[13];
  J->data[9] = p[1];
  J->data[10] = -p[1];
  J->data[11] = p[2];
  J->data[12] = p[1]/k[0];
  J->data[13] = -p[1]/k[0];
  J->data[14] = p[1]/k[0];
  J->data[15] = p[2]/k[0];
  J->data[16] = -p[3];
  J->data[17] = p[4]*t;
  J->data[18] = p[3]/k[0];
  J->data[19] = (p[4]*t)/k[0];
  J->data[20] = -k[0]*p[6]*x_tmp[0];
  J->data[21] = k[0]*p[6]*x_tmp[0];
  J->data[22] = -p[5];
  J->data[23] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[6]*x_tmp[0]-(k[0]*k[0]*k[0])*p[6]*x_tmp[4]*2.0);
  J->data[24] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[6]*x_tmp[0]-(k[0]*k[0]*k[0])*p[6]*x_tmp[4]+(k[0]*k[0]*k[0])*p[6]*x_tmp[5]);
  J->data[25] = -k[0]*p[6]*x_tmp[6];
  J->data[26] = -k[0]*p[6]*x_tmp[7];
  J->data[27] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[6]*x_tmp[0]+(k[0]*k[0]*k[0])*p[6]*x_tmp[5]*2.0);
  J->data[28] = k[0]*p[6]*x_tmp[6];
  J->data[29] = k[0]*p[6]*x_tmp[7];
  J->data[30] = p[5]/k[0];
  J->data[31] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]*2.0+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]*2.0);
  J->data[32] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]);
  J->data[33] = p[1]*2.0;
  J->data[34] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]+(k[0]*k[0])*p[1]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]);
  J->data[35] = p[2];
  J->data[36] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]*2.0+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]*2.0);
  J->data[37] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]+(k[0]*k[0])*p[3]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]);
  J->data[38] = p[4]*t;
  J->data[39] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]);
  J->data[40] = -k[0]*p[6];
  J->data[41] = k[0]*p[6];
  J->data[42] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[6]-(k[0]*k[0]*k[0])*p[6]*x_tmp[0]*2.0);
  J->data[43] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[6]-(k[0]*k[0]*k[0])*p[6]*x_tmp[0]);
  J->data[44] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]+(k[0]*k[0])*p[5]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]);
  J->data[45] = p[6];
  J->data[46] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]);
  J->data[47] = p[1];
  J->data[48] = p[1]*-2.0;
  J->data[49] = p[2];
  J->data[50] = p[1];
  J->data[51] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[1]+(k[0]*k[0])*p[3]);
  J->data[52] = p[4]*t;
  J->data[53] = p[2]*2.0;
  J->data[54] = -k[0]*p[6]*x_tmp[0];
  J->data[55] = p[1];
  J->data[56] = k[0]*p[6]*x_tmp[0]*2.0;
  J->data[57] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[1]+(k[0]*k[0])*p[5]);
  J->data[58] = p[2];
  J->data[59] = p[3]*-2.0;
  J->data[60] = p[4]*t;
  J->data[61] = -k[0]*p[6]*x_tmp[0];
  J->data[62] = k[0]*p[6]*x_tmp[0];
  J->data[63] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[3]+(k[0]*k[0])*p[5]);
  J->data[64] = p[4]*t*2.0;
  J->data[65] = -k[0]*p[6]*x_tmp[0];
  J->data[66] = k[0]*p[6]*x_tmp[0];
  J->data[67] = p[5]*-2.0;
int inz;
for(inz = 0; inz<68; inz++) {
   if(mxIsNaN(J->data[inz])) {
       J->data[inz] = 0;       if(!udata->am_nan_JSparse) {
           mexWarnMsgIdAndTxt("AMICI:mex:fJ:NaN","AMICI replaced a NaN value in Jacobian and replaced it by 0.0. This will not be reported again for this simulation run.");           udata->am_nan_JSparse = TRUE;
       }
   }   if(mxIsInf(J->data[inz])) {
       mexWarnMsgIdAndTxt("AMICI:mex:fJ:Inf","AMICI encountered an Inf value in Jacobian! Aborting simulation ... ");       return(-1);   }}
return(0);

}


