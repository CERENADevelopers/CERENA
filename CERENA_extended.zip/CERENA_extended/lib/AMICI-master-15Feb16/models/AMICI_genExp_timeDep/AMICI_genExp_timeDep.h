#ifndef _am_AMICI_genExp_timeDep_h
#define _am_AMICI_genExp_timeDep_h

#include "AMICI_genExp_timeDep_J.h"
#include "AMICI_genExp_timeDep_JB.h"
#include "AMICI_genExp_timeDep_JBand.h"
#include "AMICI_genExp_timeDep_JBandB.h"
#include "AMICI_genExp_timeDep_JSparse.h"
#include "AMICI_genExp_timeDep_JSparseB.h"
#include "AMICI_genExp_timeDep_Jv.h"
#include "AMICI_genExp_timeDep_JvB.h"
#include "AMICI_genExp_timeDep_Jy.h"
#include "AMICI_genExp_timeDep_Jz.h"
#include "AMICI_genExp_timeDep_dJydp.h"
#include "AMICI_genExp_timeDep_dJydx.h"
#include "AMICI_genExp_timeDep_dJzdp.h"
#include "AMICI_genExp_timeDep_dJzdx.h"
#include "AMICI_genExp_timeDep_deltaqB.h"
#include "AMICI_genExp_timeDep_deltasx.h"
#include "AMICI_genExp_timeDep_deltax.h"
#include "AMICI_genExp_timeDep_deltaxB.h"
#include "AMICI_genExp_timeDep_dsigma_ydp.h"
#include "AMICI_genExp_timeDep_dsigma_zdp.h"
#include "AMICI_genExp_timeDep_dxdotdp.h"
#include "AMICI_genExp_timeDep_dydp.h"
#include "AMICI_genExp_timeDep_dydx.h"
#include "AMICI_genExp_timeDep_dzdp.h"
#include "AMICI_genExp_timeDep_dzdx.h"
#include "AMICI_genExp_timeDep_qBdot.h"
#include "AMICI_genExp_timeDep_root.h"
#include "AMICI_genExp_timeDep_sJy.h"
#include "AMICI_genExp_timeDep_sJz.h"
#include "AMICI_genExp_timeDep_sigma_y.h"
#include "AMICI_genExp_timeDep_sigma_z.h"
#include "AMICI_genExp_timeDep_stau.h"
#include "AMICI_genExp_timeDep_sx0.h"
#include "AMICI_genExp_timeDep_sxdot.h"
#include "AMICI_genExp_timeDep_sy.h"
#include "AMICI_genExp_timeDep_sz.h"
#include "AMICI_genExp_timeDep_sz_tf.h"
#include "AMICI_genExp_timeDep_x0.h"
#include "AMICI_genExp_timeDep_xBdot.h"
#include "AMICI_genExp_timeDep_xdot.h"
#include "AMICI_genExp_timeDep_y.h"
#include "AMICI_genExp_timeDep_z.h"

int J_AMICI_genExp_timeDep(long int N, realtype t, N_Vector x, N_Vector xdot, DlsMat J, void *user_data, N_Vector tmp1, N_Vector tmp2, N_Vector tmp3);
int JB_AMICI_genExp_timeDep(long int NeqBdot, realtype t, N_Vector x, N_Vector xB, N_Vector xBdot, DlsMat JB, void *user_data, N_Vector tmp1B, N_Vector tmp2B, N_Vector tmp3B);
int JBand_AMICI_genExp_timeDep(long int N, long int mupper, long int mlower, realtype t, N_Vector x, N_Vector xdot, DlsMat J, void *user_data, N_Vector tmp1, N_Vector tmp2, N_Vector tmp3);
int JBandB_AMICI_genExp_timeDep(long int NeqBdot, long int mupper, long int mlower, realtype t, N_Vector x, N_Vector xB, N_Vector xBdot, DlsMat JB, void *user_data, N_Vector tmp1B, N_Vector tmp2B, N_Vector tmp3B);
int JSparse_AMICI_genExp_timeDep(realtype t, N_Vector x, N_Vector xdot, SlsMat J, void *user_data, N_Vector tmp1, N_Vector tmp2, N_Vector tmp3);
int JSparseB_AMICI_genExp_timeDep(realtype t, N_Vector x, N_Vector xB, N_Vector xBdot, SlsMat JB, void *user_data, N_Vector tmp1B, N_Vector tmp2B, N_Vector tmp3B);
int Jv_AMICI_genExp_timeDep(N_Vector v, N_Vector Jv, realtype t, N_Vector x, N_Vector xdot, void *user_data, N_Vector tmp);
int JvB_AMICI_genExp_timeDep(N_Vector vB, N_Vector JvB, realtype t, N_Vector x, N_Vector xB, N_Vector xBdot, void *user_data, N_Vector tmpB);
int Jy_AMICI_genExp_timeDep(realtype t, int it, realtype *Jy, realtype *y, N_Vector x, realtype *my, realtype *sd_y, void *user_data);
int Jz_AMICI_genExp_timeDep(realtype t, int ie, realtype *Jz, realtype *z, N_Vector x, realtype *mz, realtype *sd_z, void *user_data, void *temp_data);
int dJydp_AMICI_genExp_timeDep(realtype t, int it, realtype *dJydp, realtype *y, N_Vector x, realtype *dydp, realtype *my, realtype *sd_y, realtype *dsigma_ydp, void *user_data);
int dJydx_AMICI_genExp_timeDep(realtype t, int it, realtype *dJydx, realtype *y, N_Vector x, realtype *dydx, realtype *my, realtype *sd_y, void *user_data);
int dJzdp_AMICI_genExp_timeDep(realtype t, int ie, realtype *dJzdp, realtype *z, N_Vector x, realtype *dzdp, realtype *mz, realtype *sd_z, realtype *dsigma_zdp, void *user_data, void *temp_data);
int dJzdx_AMICI_genExp_timeDep(realtype t, int ie, realtype *dJzdx, realtype *z, N_Vector x, realtype *dzdx, realtype *mz, realtype *sd_z, void *user_data, void *temp_data);
int deltaqB_AMICI_genExp_timeDep(realtype t, int ie, realtype *deltaqB, N_Vector x, N_Vector xB, N_Vector qBdot, N_Vector xdot, N_Vector xdot_old, void *user_data);
int deltasx_AMICI_genExp_timeDep(realtype t, int ie, realtype *deltasx, N_Vector x, N_Vector xdot, N_Vector xdot_old, N_Vector *sx, void *user_data);
int deltax_AMICI_genExp_timeDep(realtype t, int ie, realtype *deltax, N_Vector x, N_Vector xdot, N_Vector xdot_old, void *user_data);
int deltaxB_AMICI_genExp_timeDep(realtype t, int ie, realtype *deltaxB, N_Vector x, N_Vector xB, N_Vector xdot, N_Vector xdot_old, void *user_data);
int dsigma_ydp_AMICI_genExp_timeDep(realtype t, realtype *dsigma_ydp, void *user_data);
int dsigma_zdp_AMICI_genExp_timeDep(realtype t, int ie, realtype *dsigma_zdp, void *user_data);
int dxdotdp_AMICI_genExp_timeDep(realtype t, realtype *dxdotdp, N_Vector x, void *user_data);
int dydp_AMICI_genExp_timeDep(realtype t, int it, realtype *dydp, N_Vector x, void *user_data);
int dydx_AMICI_genExp_timeDep(realtype t, int it, realtype *dydx, N_Vector x, void *user_data);
int dzdp_AMICI_genExp_timeDep(realtype t, int ie, realtype *dzdp, N_Vector x, void *user_data);
int dzdx_AMICI_genExp_timeDep(realtype t, int ie, realtype *dzdx, N_Vector x, void *user_data);
int qBdot_AMICI_genExp_timeDep(realtype t, N_Vector x, N_Vector xB, N_Vector qBdot, void *user_data);
int root_AMICI_genExp_timeDep(realtype t, N_Vector x, realtype *root, void *user_data);
int sJy_AMICI_genExp_timeDep(realtype t, int it, realtype *sJy, realtype *y, N_Vector x, realtype *dydp, realtype *sy, realtype *my, realtype *sd_y, realtype *dsigma_ydp, void *user_data);
int sJz_AMICI_genExp_timeDep(realtype t, int ie, realtype *sJz, realtype *z, N_Vector x, realtype *dzdp, realtype *sz, realtype *mz, realtype *sd_z, realtype *dsigma_zdp, void *user_data, void *temp_data);
int sigma_y_AMICI_genExp_timeDep(realtype t, realtype *sigma_y, void *user_data);
int sigma_z_AMICI_genExp_timeDep(realtype t, int ie, realtype *sigma_z, void *user_data);
int stau_AMICI_genExp_timeDep(realtype t, int ie, realtype *stau, N_Vector x, N_Vector *sx, void *user_data);
int sx0_AMICI_genExp_timeDep(N_Vector *sx0, N_Vector x, N_Vector dx, void *user_data);
int sxdot_AMICI_genExp_timeDep(int Ns, realtype t, N_Vector x, N_Vector xdot,int ip,  N_Vector sx, N_Vector sxdot, void *user_data, N_Vector tmp1, N_Vector tmp2);
int sy_AMICI_genExp_timeDep(realtype t, int it, realtype *sy, N_Vector x, N_Vector *sx, void *user_data);
int sz_AMICI_genExp_timeDep(realtype t, int ie, int *nroots, realtype *sz, N_Vector x, N_Vector *sx, void *user_data);
int sz_tf_AMICI_genExp_timeDep(realtype t, int ie, int *nroots, realtype *sz, N_Vector x, N_Vector *sx, void *user_data);
int x0_AMICI_genExp_timeDep(N_Vector x0, void *user_data);
int xBdot_AMICI_genExp_timeDep(realtype t, N_Vector x, N_Vector xB, N_Vector xBdot, void *user_data);
int xdot_AMICI_genExp_timeDep(realtype t, N_Vector x, N_Vector xdot, void *user_data);
int y_AMICI_genExp_timeDep(realtype t, int it, realtype *y, N_Vector x, void *user_data);
int z_AMICI_genExp_timeDep(realtype t, int ie, int *nroots, realtype *z, N_Vector x, void *user_data);


#endif /* _am_AMICI_genExp_timeDep_h */
