
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int x0_AMICI_genExp_timeDep(N_Vector x0, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x0_tmp = N_VGetArrayPointer(x0);
memset(x0_tmp,0,sizeof(realtype)*14);
  x0_tmp[0] = (-k[1]+k[1]*k[15]+1.0)/k[0];
  x0_tmp[1] = (k[2]*k[16])/k[0];
  x0_tmp[2] = (k[3]*k[17]-p[9]*(k[3]-1.0))/k[0];
  x0_tmp[3] = (k[4]*k[18])/k[0];
  x0_tmp[4] = 1.0/(k[0]*k[0])*k[5]*k[19];
  x0_tmp[5] = 1.0/(k[0]*k[0])*k[6]*k[20];
  x0_tmp[6] = 1.0/(k[0]*k[0])*k[7]*k[21];
  x0_tmp[7] = 1.0/(k[0]*k[0])*k[8]*k[22];
  x0_tmp[8] = 1.0/(k[0]*k[0])*k[9]*k[23];
  x0_tmp[9] = 1.0/(k[0]*k[0])*k[10]*k[24];
  x0_tmp[10] = 1.0/(k[0]*k[0])*k[11]*k[25];
  x0_tmp[11] = 1.0/(k[0]*k[0])*k[12]*k[26];
  x0_tmp[12] = 1.0/(k[0]*k[0])*k[13]*k[27];
  x0_tmp[13] = 1.0/(k[0]*k[0])*k[14]*k[28];
return(0);

}


