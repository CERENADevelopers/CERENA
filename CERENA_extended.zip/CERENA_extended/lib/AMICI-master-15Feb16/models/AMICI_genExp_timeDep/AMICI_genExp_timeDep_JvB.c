
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int JvB_AMICI_genExp_timeDep(N_Vector vB, N_Vector JvB, realtype t, N_Vector x, N_Vector xB, N_Vector xBdot, void *user_data, N_Vector tmpB) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *xB_tmp = N_VGetArrayPointer(xB);
realtype *xBdot_tmp = N_VGetArrayPointer(xBdot);
realtype *vB_tmp = N_VGetArrayPointer(vB);
realtype *JvB_tmp = N_VGetArrayPointer(JvB);
memset(JvB_tmp,0,sizeof(realtype)*14);
  JvB_tmp[0] = (vB_tmp[0]*(k[0]*p[0]+(k[0]*k[0])*p[6]*x_tmp[3]))/k[0]-(vB_tmp[1]*(k[0]*p[0]+(k[0]*k[0])*p[6]*x_tmp[3]))/k[0]-1.0/(k[0]*k[0])*vB_tmp[4]*(k[0]*p[0]+(k[0]*k[0])*p[6]*x_tmp[3]-(k[0]*k[0]*k[0])*p[6]*x_tmp[7]*2.0)-1.0/(k[0]*k[0])*vB_tmp[8]*(k[0]*p[0]+(k[0]*k[0])*p[6]*x_tmp[3]+(k[0]*k[0]*k[0])*p[6]*x_tmp[10]*2.0)+1.0/(k[0]*k[0])*vB_tmp[5]*(k[0]*p[0]+(k[0]*k[0])*p[6]*x_tmp[3]-(k[0]*k[0]*k[0])*p[6]*x_tmp[7]+(k[0]*k[0]*k[0])*p[6]*x_tmp[10])+k[0]*p[6]*vB_tmp[6]*x_tmp[12]+k[0]*p[6]*vB_tmp[7]*x_tmp[13]-k[0]*p[6]*vB_tmp[9]*x_tmp[12]-k[0]*p[6]*vB_tmp[10]*x_tmp[13];
  JvB_tmp[1] = -p[1]*vB_tmp[0]+p[1]*vB_tmp[1]-p[2]*vB_tmp[2]-(p[1]*vB_tmp[4])/k[0]+(p[1]*vB_tmp[5])/k[0]-(p[1]*vB_tmp[8])/k[0]-(p[2]*vB_tmp[11])/k[0];
  JvB_tmp[2] = p[3]*vB_tmp[2]-(p[3]*vB_tmp[11])/k[0]-p[4]*t*vB_tmp[3]-(p[4]*t*vB_tmp[13])/k[0];
  JvB_tmp[3] = p[5]*vB_tmp[3]-(p[5]*vB_tmp[13])/k[0]-1.0/(k[0]*k[0])*vB_tmp[4]*((k[0]*k[0])*p[6]*x_tmp[0]-(k[0]*k[0]*k[0])*p[6]*x_tmp[4]*2.0)-1.0/(k[0]*k[0])*vB_tmp[8]*((k[0]*k[0])*p[6]*x_tmp[0]+(k[0]*k[0]*k[0])*p[6]*x_tmp[5]*2.0)+1.0/(k[0]*k[0])*vB_tmp[5]*((k[0]*k[0])*p[6]*x_tmp[0]-(k[0]*k[0]*k[0])*p[6]*x_tmp[4]+(k[0]*k[0]*k[0])*p[6]*x_tmp[5])+k[0]*p[6]*vB_tmp[0]*x_tmp[0]-k[0]*p[6]*vB_tmp[1]*x_tmp[0]+k[0]*p[6]*vB_tmp[6]*x_tmp[6]+k[0]*p[6]*vB_tmp[7]*x_tmp[7]-k[0]*p[6]*vB_tmp[9]*x_tmp[6]-k[0]*p[6]*vB_tmp[10]*x_tmp[7];
  JvB_tmp[4] = -1.0/(k[0]*k[0])*vB_tmp[5]*((k[0]*k[0])*p[0]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3])+1.0/(k[0]*k[0])*vB_tmp[4]*((k[0]*k[0])*p[0]*2.0+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]*2.0);
  JvB_tmp[5] = p[1]*vB_tmp[4]*-2.0-p[2]*vB_tmp[6]+1.0/(k[0]*k[0])*vB_tmp[5]*((k[0]*k[0])*p[0]+(k[0]*k[0])*p[1]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3])-1.0/(k[0]*k[0])*vB_tmp[8]*((k[0]*k[0])*p[0]*2.0+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]*2.0);
  JvB_tmp[6] = 1.0/(k[0]*k[0])*vB_tmp[6]*((k[0]*k[0])*p[0]+(k[0]*k[0])*p[3]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3])-1.0/(k[0]*k[0])*vB_tmp[9]*((k[0]*k[0])*p[0]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3])-p[4]*t*vB_tmp[7];
  JvB_tmp[7] = -p[6]*vB_tmp[8]+1.0/(k[0]*k[0])*vB_tmp[7]*((k[0]*k[0])*p[0]+(k[0]*k[0])*p[5]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3])-1.0/(k[0]*k[0])*vB_tmp[4]*((k[0]*k[0])*p[6]-(k[0]*k[0]*k[0])*p[6]*x_tmp[0]*2.0)+1.0/(k[0]*k[0])*vB_tmp[5]*((k[0]*k[0])*p[6]-(k[0]*k[0]*k[0])*p[6]*x_tmp[0])-1.0/(k[0]*k[0])*vB_tmp[10]*((k[0]*k[0])*p[0]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3])+k[0]*p[6]*vB_tmp[0]-k[0]*p[6]*vB_tmp[1];
  JvB_tmp[8] = -p[1]*vB_tmp[5]+p[1]*vB_tmp[8]*2.0-p[2]*vB_tmp[9];
  JvB_tmp[9] = -p[1]*vB_tmp[6]-p[2]*vB_tmp[11]*2.0+1.0/(k[0]*k[0])*vB_tmp[9]*((k[0]*k[0])*p[1]+(k[0]*k[0])*p[3])-p[4]*t*vB_tmp[10];
  JvB_tmp[10] = -p[1]*vB_tmp[7]-p[2]*vB_tmp[12]+1.0/(k[0]*k[0])*vB_tmp[10]*((k[0]*k[0])*p[1]+(k[0]*k[0])*p[5])+k[0]*p[6]*vB_tmp[5]*x_tmp[0]-k[0]*p[6]*vB_tmp[8]*x_tmp[0]*2.0;
  JvB_tmp[11] = p[3]*vB_tmp[11]*2.0-p[4]*t*vB_tmp[12];
  JvB_tmp[12] = 1.0/(k[0]*k[0])*vB_tmp[12]*((k[0]*k[0])*p[3]+(k[0]*k[0])*p[5])-p[4]*t*vB_tmp[13]*2.0+k[0]*p[6]*vB_tmp[6]*x_tmp[0]-k[0]*p[6]*vB_tmp[9]*x_tmp[0];
  JvB_tmp[13] = p[5]*vB_tmp[13]*2.0+k[0]*p[6]*vB_tmp[7]*x_tmp[0]-k[0]*p[6]*vB_tmp[10]*x_tmp[0];
return(0);

}


