#ifndef _am_AMICI_genExp_timeDep_dJzdx_h
#define _am_AMICI_genExp_timeDep_dJzdx_h

int dJzdx_AMICI_genExp_timeDep(realtype t, int ie, realtype *dJzdx, realtype *z, N_Vector x, realtype *dzdx, realtype *mz, realtype *sd_z, void *user_data, void *temp_data);


#endif /* _am_AMICI_genExp_timeDep_dJzdx_h */
