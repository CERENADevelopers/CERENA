#ifndef _am_AMICI_genExp_timeDep_dxdotdp_h
#define _am_AMICI_genExp_timeDep_dxdotdp_h

int dxdotdp_AMICI_genExp_timeDep(realtype t, realtype *dxdotdp, N_Vector x, void *user_data);


#endif /* _am_AMICI_genExp_timeDep_dxdotdp_h */
