
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int xBdot_AMICI_genExp_timeDep(realtype t, N_Vector x, N_Vector xB, N_Vector xBdot, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *xB_tmp = N_VGetArrayPointer(xB);
realtype *xBdot_tmp = N_VGetArrayPointer(xBdot);
memset(xBdot_tmp,0,sizeof(realtype)*14);
  xBdot_tmp[0] = (xB_tmp[0]*(k[0]*p[0]+(k[0]*k[0])*p[6]*x_tmp[3]))/k[0]-(xB_tmp[1]*(k[0]*p[0]+(k[0]*k[0])*p[6]*x_tmp[3]))/k[0]-1.0/(k[0]*k[0])*xB_tmp[4]*(k[0]*p[0]+(k[0]*k[0])*p[6]*x_tmp[3]-(k[0]*k[0]*k[0])*p[6]*x_tmp[7]*2.0)-1.0/(k[0]*k[0])*xB_tmp[8]*(k[0]*p[0]+(k[0]*k[0])*p[6]*x_tmp[3]+(k[0]*k[0]*k[0])*p[6]*x_tmp[10]*2.0)+1.0/(k[0]*k[0])*xB_tmp[5]*(k[0]*p[0]+(k[0]*k[0])*p[6]*x_tmp[3]-(k[0]*k[0]*k[0])*p[6]*x_tmp[7]+(k[0]*k[0]*k[0])*p[6]*x_tmp[10])+k[0]*p[6]*xB_tmp[6]*x_tmp[12]+k[0]*p[6]*xB_tmp[7]*x_tmp[13]-k[0]*p[6]*xB_tmp[9]*x_tmp[12]-k[0]*p[6]*xB_tmp[10]*x_tmp[13];
  xBdot_tmp[1] = -p[1]*xB_tmp[0]+p[1]*xB_tmp[1]-p[2]*xB_tmp[2]-(p[1]*xB_tmp[4])/k[0]+(p[1]*xB_tmp[5])/k[0]-(p[1]*xB_tmp[8])/k[0]-(p[2]*xB_tmp[11])/k[0];
  xBdot_tmp[2] = p[3]*xB_tmp[2]-(p[3]*xB_tmp[11])/k[0]-p[4]*t*xB_tmp[3]-(p[4]*t*xB_tmp[13])/k[0];
  xBdot_tmp[3] = p[5]*xB_tmp[3]-(p[5]*xB_tmp[13])/k[0]-1.0/(k[0]*k[0])*xB_tmp[4]*((k[0]*k[0])*p[6]*x_tmp[0]-(k[0]*k[0]*k[0])*p[6]*x_tmp[4]*2.0)-1.0/(k[0]*k[0])*xB_tmp[8]*((k[0]*k[0])*p[6]*x_tmp[0]+(k[0]*k[0]*k[0])*p[6]*x_tmp[5]*2.0)+1.0/(k[0]*k[0])*xB_tmp[5]*((k[0]*k[0])*p[6]*x_tmp[0]-(k[0]*k[0]*k[0])*p[6]*x_tmp[4]+(k[0]*k[0]*k[0])*p[6]*x_tmp[5])+k[0]*p[6]*xB_tmp[0]*x_tmp[0]-k[0]*p[6]*xB_tmp[1]*x_tmp[0]+k[0]*p[6]*xB_tmp[6]*x_tmp[6]+k[0]*p[6]*xB_tmp[7]*x_tmp[7]-k[0]*p[6]*xB_tmp[9]*x_tmp[6]-k[0]*p[6]*xB_tmp[10]*x_tmp[7];
  xBdot_tmp[4] = -1.0/(k[0]*k[0])*xB_tmp[5]*((k[0]*k[0])*p[0]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3])+1.0/(k[0]*k[0])*xB_tmp[4]*((k[0]*k[0])*p[0]*2.0+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]*2.0);
  xBdot_tmp[5] = p[1]*xB_tmp[4]*-2.0-p[2]*xB_tmp[6]+1.0/(k[0]*k[0])*xB_tmp[5]*((k[0]*k[0])*p[0]+(k[0]*k[0])*p[1]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3])-1.0/(k[0]*k[0])*xB_tmp[8]*((k[0]*k[0])*p[0]*2.0+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]*2.0);
  xBdot_tmp[6] = 1.0/(k[0]*k[0])*xB_tmp[6]*((k[0]*k[0])*p[0]+(k[0]*k[0])*p[3]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3])-1.0/(k[0]*k[0])*xB_tmp[9]*((k[0]*k[0])*p[0]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3])-p[4]*t*xB_tmp[7];
  xBdot_tmp[7] = -p[6]*xB_tmp[8]+1.0/(k[0]*k[0])*xB_tmp[7]*((k[0]*k[0])*p[0]+(k[0]*k[0])*p[5]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3])-1.0/(k[0]*k[0])*xB_tmp[4]*((k[0]*k[0])*p[6]-(k[0]*k[0]*k[0])*p[6]*x_tmp[0]*2.0)+1.0/(k[0]*k[0])*xB_tmp[5]*((k[0]*k[0])*p[6]-(k[0]*k[0]*k[0])*p[6]*x_tmp[0])-1.0/(k[0]*k[0])*xB_tmp[10]*((k[0]*k[0])*p[0]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3])+k[0]*p[6]*xB_tmp[0]-k[0]*p[6]*xB_tmp[1];
  xBdot_tmp[8] = -p[1]*xB_tmp[5]+p[1]*xB_tmp[8]*2.0-p[2]*xB_tmp[9];
  xBdot_tmp[9] = -p[1]*xB_tmp[6]-p[2]*xB_tmp[11]*2.0+1.0/(k[0]*k[0])*xB_tmp[9]*((k[0]*k[0])*p[1]+(k[0]*k[0])*p[3])-p[4]*t*xB_tmp[10];
  xBdot_tmp[10] = -p[1]*xB_tmp[7]-p[2]*xB_tmp[12]+1.0/(k[0]*k[0])*xB_tmp[10]*((k[0]*k[0])*p[1]+(k[0]*k[0])*p[5])+k[0]*p[6]*xB_tmp[5]*x_tmp[0]-k[0]*p[6]*xB_tmp[8]*x_tmp[0]*2.0;
  xBdot_tmp[11] = p[3]*xB_tmp[11]*2.0-p[4]*t*xB_tmp[12];
  xBdot_tmp[12] = 1.0/(k[0]*k[0])*xB_tmp[12]*((k[0]*k[0])*p[3]+(k[0]*k[0])*p[5])-p[4]*t*xB_tmp[13]*2.0+k[0]*p[6]*xB_tmp[6]*x_tmp[0]-k[0]*p[6]*xB_tmp[9]*x_tmp[0];
  xBdot_tmp[13] = p[5]*xB_tmp[13]*2.0+k[0]*p[6]*xB_tmp[7]*x_tmp[0]-k[0]*p[6]*xB_tmp[10]*x_tmp[0];
int ix;
for(ix = 0; ix<14; ix++) {
   if(mxIsNaN(xBdot_tmp[ix])) {
       xBdot_tmp[ix] = 0;       if(!udata->am_nan_xBdot) {
           mexWarnMsgIdAndTxt("AMICI:mex:fxBdot:NaN","AMICI replaced a NaN value in xBdot and replaced it by 0.0. This will not be reported again for this simulation run.");           udata->am_nan_xBdot = TRUE;
       }
   }   if(mxIsInf(xBdot_tmp[ix])) {
       mexWarnMsgIdAndTxt("AMICI:mex:fxBdot:Inf","AMICI encountered an Inf value in xBdot! Aborting simulation ... ");       return(-1);   }}
return(0);

}


