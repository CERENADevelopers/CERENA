#ifndef _am_AMICI_genExp_timeDep_Jz_h
#define _am_AMICI_genExp_timeDep_Jz_h

int Jz_AMICI_genExp_timeDep(realtype t, int ie, realtype *Jz, realtype *z, N_Vector x, realtype *mz, realtype *sd_z, void *user_data, void *temp_data);


#endif /* _am_AMICI_genExp_timeDep_Jz_h */
