
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int dydx_AMICI_genExp_timeDep(realtype t, int it, realtype *dydx, N_Vector x, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
  dydx[6] = p[7];
  dydx[27] = p[7]*p[7];
return(0);

}


