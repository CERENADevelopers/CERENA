#ifndef _am_AMICI_genExp_timeDep_dsigma_ydp_h
#define _am_AMICI_genExp_timeDep_dsigma_ydp_h

int dsigma_ydp_AMICI_genExp_timeDep(realtype t, realtype *dsigma_ydp, void *user_data);


#endif /* _am_AMICI_genExp_timeDep_dsigma_ydp_h */
