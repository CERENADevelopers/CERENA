#ifndef _am_AMICI_genExp_timeDep_dJzdp_h
#define _am_AMICI_genExp_timeDep_dJzdp_h

int dJzdp_AMICI_genExp_timeDep(realtype t, int ie, realtype *dJzdp, realtype *z, N_Vector x, realtype *dzdp, realtype *mz, realtype *sd_z, realtype *dsigma_zdp, void *user_data, void *temp_data);


#endif /* _am_AMICI_genExp_timeDep_dJzdp_h */
