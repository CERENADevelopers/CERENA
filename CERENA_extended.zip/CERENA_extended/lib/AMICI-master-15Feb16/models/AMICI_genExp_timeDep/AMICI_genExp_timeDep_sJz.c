
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>
#include <include/tdata.h>
#undef t
#undef x
#undef x_tmp
#undef dzdp
#undef dzdx
#undef dsigma_zdp

int sJz_AMICI_genExp_timeDep(realtype t, int ie, realtype *sJz, realtype *z, N_Vector x, realtype *dzdp, realtype *sz, realtype *mz, realtype *sd_z, realtype *dsigma_zdp, void *user_data, void *temp_data) {
UserData udata = (UserData) user_data;
TempData tdata = (TempData) temp_data;
realtype *x_tmp = N_VGetArrayPointer(x);
int ip;
for(ip = 0; ip<np; ip++) {
switch (plist[ip]) {
}
}
return(0);

}


