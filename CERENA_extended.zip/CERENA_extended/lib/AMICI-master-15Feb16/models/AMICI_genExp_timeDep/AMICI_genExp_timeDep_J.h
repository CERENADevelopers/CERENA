#ifndef _am_AMICI_genExp_timeDep_J_h
#define _am_AMICI_genExp_timeDep_J_h

int J_AMICI_genExp_timeDep(long int N, realtype t, N_Vector x, N_Vector xdot, DlsMat J, void *user_data, N_Vector tmp1, N_Vector tmp2, N_Vector tmp3);


#endif /* _am_AMICI_genExp_timeDep_J_h */
