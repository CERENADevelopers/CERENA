#ifndef _am_AMICI_genExp_timeDep_deltasx_h
#define _am_AMICI_genExp_timeDep_deltasx_h

int deltasx_AMICI_genExp_timeDep(realtype t, int ie, realtype *deltasx, N_Vector x, N_Vector xdot, N_Vector xdot_old, N_Vector *sx, void *user_data);


#endif /* _am_AMICI_genExp_timeDep_deltasx_h */
