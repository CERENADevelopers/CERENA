#ifndef _am_AMICI_genExp_timeDep_dydp_h
#define _am_AMICI_genExp_timeDep_dydp_h

int dydp_AMICI_genExp_timeDep(realtype t, int it, realtype *dydp, N_Vector x, void *user_data);


#endif /* _am_AMICI_genExp_timeDep_dydp_h */
