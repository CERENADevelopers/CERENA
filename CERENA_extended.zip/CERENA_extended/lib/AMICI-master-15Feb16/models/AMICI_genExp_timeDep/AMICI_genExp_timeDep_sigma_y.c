
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int sigma_y_AMICI_genExp_timeDep(realtype t, realtype *sigma_y, void *user_data) {
UserData udata = (UserData) user_data;
memset(sigma_y,0,sizeof(realtype)*2);
  sigma_y[0] = 1.0;
  sigma_y[1] = 1.0;
return(0);

}


