
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int sy_AMICI_genExp_timeDep(realtype t, int it, realtype *sy, N_Vector x, N_Vector *sx, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *sx_tmp;
int ip;
for(ip = 0; ip<np; ip++) {
sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
switch (plist[ip]) {
  case 0: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*2)] = p[7]*sx_tmp[3];
  sy[it+nt*(1+ip*2)] = (p[7]*p[7])*sx_tmp[13];

  } break;

  case 1: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*2)] = p[7]*sx_tmp[3];
  sy[it+nt*(1+ip*2)] = (p[7]*p[7])*sx_tmp[13];

  } break;

  case 2: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*2)] = p[7]*sx_tmp[3];
  sy[it+nt*(1+ip*2)] = (p[7]*p[7])*sx_tmp[13];

  } break;

  case 3: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*2)] = p[7]*sx_tmp[3];
  sy[it+nt*(1+ip*2)] = (p[7]*p[7])*sx_tmp[13];

  } break;

  case 4: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*2)] = p[7]*sx_tmp[3];
  sy[it+nt*(1+ip*2)] = (p[7]*p[7])*sx_tmp[13];

  } break;

  case 5: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*2)] = p[7]*sx_tmp[3];
  sy[it+nt*(1+ip*2)] = (p[7]*p[7])*sx_tmp[13];

  } break;

  case 6: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*2)] = p[7]*sx_tmp[3];
  sy[it+nt*(1+ip*2)] = (p[7]*p[7])*sx_tmp[13];

  } break;

  case 7: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*2)] = x_tmp[3]+p[7]*sx_tmp[3];
  sy[it+nt*(1+ip*2)] = p[7]*(x_tmp[13]+x_tmp[3]*x_tmp[3])*2.0+(p[7]*p[7])*sx_tmp[13]-p[7]*(x_tmp[3]*x_tmp[3])*2.0;

  } break;

  case 8: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*2)] = p[7]*sx_tmp[3]+1.0;
  sy[it+nt*(1+ip*2)] = (p[7]*p[7])*sx_tmp[13];

  } break;

  case 9: {
  sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
  sy[it+nt*(0+ip*2)] = p[7]*sx_tmp[3];
  sy[it+nt*(1+ip*2)] = (p[7]*p[7])*sx_tmp[13];

  } break;

}
}
return(0);

}


