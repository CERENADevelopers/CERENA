
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int J_AMICI_genExp_timeDep(long int N, realtype t, N_Vector x, N_Vector xdot, DlsMat J, void *user_data, N_Vector tmp1, N_Vector tmp2, N_Vector tmp3) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *xdot_tmp = N_VGetArrayPointer(xdot);
memset(J->data,0,sizeof(realtype)*196);
  J->data[0] = -(k[0]*p[0]+(k[0]*k[0])*p[6]*x_tmp[3])/k[0];
  J->data[1] = (k[0]*p[0]+(k[0]*k[0])*p[6]*x_tmp[3])/k[0];
  J->data[4] = 1.0/(k[0]*k[0])*(k[0]*p[0]+(k[0]*k[0])*p[6]*x_tmp[3]-(k[0]*k[0]*k[0])*p[6]*x_tmp[7]*2.0);
  J->data[5] = -1.0/(k[0]*k[0])*(k[0]*p[0]+(k[0]*k[0])*p[6]*x_tmp[3]-(k[0]*k[0]*k[0])*p[6]*x_tmp[7]+(k[0]*k[0]*k[0])*p[6]*x_tmp[10]);
  J->data[6] = -k[0]*p[6]*x_tmp[12];
  J->data[7] = -k[0]*p[6]*x_tmp[13];
  J->data[8] = 1.0/(k[0]*k[0])*(k[0]*p[0]+(k[0]*k[0])*p[6]*x_tmp[3]+(k[0]*k[0]*k[0])*p[6]*x_tmp[10]*2.0);
  J->data[9] = k[0]*p[6]*x_tmp[12];
  J->data[10] = k[0]*p[6]*x_tmp[13];
  J->data[14] = p[1];
  J->data[15] = -p[1];
  J->data[16] = p[2];
  J->data[18] = p[1]/k[0];
  J->data[19] = -p[1]/k[0];
  J->data[22] = p[1]/k[0];
  J->data[25] = p[2]/k[0];
  J->data[30] = -p[3];
  J->data[31] = p[4]*t;
  J->data[39] = p[3]/k[0];
  J->data[41] = (p[4]*t)/k[0];
  J->data[42] = -k[0]*p[6]*x_tmp[0];
  J->data[43] = k[0]*p[6]*x_tmp[0];
  J->data[45] = -p[5];
  J->data[46] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[6]*x_tmp[0]-(k[0]*k[0]*k[0])*p[6]*x_tmp[4]*2.0);
  J->data[47] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[6]*x_tmp[0]-(k[0]*k[0]*k[0])*p[6]*x_tmp[4]+(k[0]*k[0]*k[0])*p[6]*x_tmp[5]);
  J->data[48] = -k[0]*p[6]*x_tmp[6];
  J->data[49] = -k[0]*p[6]*x_tmp[7];
  J->data[50] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[6]*x_tmp[0]+(k[0]*k[0]*k[0])*p[6]*x_tmp[5]*2.0);
  J->data[51] = k[0]*p[6]*x_tmp[6];
  J->data[52] = k[0]*p[6]*x_tmp[7];
  J->data[55] = p[5]/k[0];
  J->data[60] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]*2.0+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]*2.0);
  J->data[61] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]);
  J->data[74] = p[1]*2.0;
  J->data[75] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]+(k[0]*k[0])*p[1]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]);
  J->data[76] = p[2];
  J->data[78] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]*2.0+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]*2.0);
  J->data[90] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]+(k[0]*k[0])*p[3]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]);
  J->data[91] = p[4]*t;
  J->data[93] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]);
  J->data[98] = -k[0]*p[6];
  J->data[99] = k[0]*p[6];
  J->data[102] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[6]-(k[0]*k[0]*k[0])*p[6]*x_tmp[0]*2.0);
  J->data[103] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[6]-(k[0]*k[0]*k[0])*p[6]*x_tmp[0]);
  J->data[105] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]+(k[0]*k[0])*p[5]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]);
  J->data[106] = p[6];
  J->data[108] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]);
  J->data[117] = p[1];
  J->data[120] = p[1]*-2.0;
  J->data[121] = p[2];
  J->data[132] = p[1];
  J->data[135] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[1]+(k[0]*k[0])*p[3]);
  J->data[136] = p[4]*t;
  J->data[137] = p[2]*2.0;
  J->data[145] = -k[0]*p[6]*x_tmp[0];
  J->data[147] = p[1];
  J->data[148] = k[0]*p[6]*x_tmp[0]*2.0;
  J->data[150] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[1]+(k[0]*k[0])*p[5]);
  J->data[152] = p[2];
  J->data[165] = p[3]*-2.0;
  J->data[166] = p[4]*t;
  J->data[174] = -k[0]*p[6]*x_tmp[0];
  J->data[177] = k[0]*p[6]*x_tmp[0];
  J->data[180] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[3]+(k[0]*k[0])*p[5]);
  J->data[181] = p[4]*t*2.0;
  J->data[189] = -k[0]*p[6]*x_tmp[0];
  J->data[192] = k[0]*p[6]*x_tmp[0];
  J->data[195] = p[5]*-2.0;
int ix;
for(ix = 0; ix<196; ix++) {
   if(mxIsNaN(J->data[ix])) {
       J->data[ix] = 0;       if(!udata->am_nan_J) {
           mexWarnMsgIdAndTxt("AMICI:mex:fJ:NaN","AMICI replaced a NaN value in Jacobian and replaced it by 0.0. This will not be reported again for this simulation run.");           udata->am_nan_J = TRUE;
       }
   }   if(mxIsInf(J->data[ix])) {
       mexWarnMsgIdAndTxt("AMICI:mex:fJ:Inf","AMICI encountered an Inf value in Jacobian! Aborting simulation ... ");       return(-1);   }}
return(0);

}


