
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int xdot_AMICI_genExp_timeDep(realtype t, N_Vector x, N_Vector xdot, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *xdot_tmp = N_VGetArrayPointer(xdot);
memset(xdot_tmp,0,sizeof(realtype)*14);
  xdot_tmp[0] = -((k[0]*k[0])*p[6]*x_tmp[7]+k[0]*p[0]*x_tmp[0]-k[0]*p[1]*x_tmp[1]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3])/k[0];
  xdot_tmp[1] = ((k[0]*k[0])*p[6]*x_tmp[7]+k[0]*p[0]*x_tmp[0]-k[0]*p[1]*x_tmp[1]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3])/k[0];
  xdot_tmp[2] = (k[0]*p[2]*x_tmp[1]-k[0]*p[3]*x_tmp[2])/k[0];
  xdot_tmp[3] = -(k[0]*p[5]*x_tmp[3]-k[0]*p[4]*t*x_tmp[2])/k[0];
  xdot_tmp[4] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]*x_tmp[4]*-2.0+(k[0]*k[0])*p[1]*x_tmp[5]*2.0+(k[0]*k[0])*p[6]*x_tmp[7]+k[0]*p[0]*x_tmp[0]+k[0]*p[1]*x_tmp[1]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]-(k[0]*k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[7]*2.0-(k[0]*k[0]*k[0])*p[6]*x_tmp[3]*x_tmp[4]*2.0);
  xdot_tmp[5] = -1.0/(k[0]*k[0])*(-(k[0]*k[0])*p[0]*x_tmp[4]+(k[0]*k[0])*p[0]*x_tmp[5]+(k[0]*k[0])*p[1]*x_tmp[5]-(k[0]*k[0])*p[1]*x_tmp[8]+(k[0]*k[0])*p[6]*x_tmp[7]+k[0]*p[0]*x_tmp[0]+k[0]*p[1]*x_tmp[1]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]-(k[0]*k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[7]-(k[0]*k[0]*k[0])*p[6]*x_tmp[3]*x_tmp[4]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]*x_tmp[5]+(k[0]*k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[10]);
  xdot_tmp[6] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]*x_tmp[6]-(k[0]*k[0])*p[2]*x_tmp[5]+(k[0]*k[0])*p[3]*x_tmp[6]-(k[0]*k[0])*p[1]*x_tmp[9]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]*x_tmp[6]+(k[0]*k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[12]);
  xdot_tmp[7] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]*x_tmp[7]-(k[0]*k[0])*p[1]*x_tmp[10]+(k[0]*k[0])*p[5]*x_tmp[7]-(k[0]*k[0])*p[4]*t*x_tmp[6]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]*x_tmp[7]+(k[0]*k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[13]);
  xdot_tmp[8] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]*x_tmp[5]*2.0-(k[0]*k[0])*p[1]*x_tmp[8]*2.0+(k[0]*k[0])*p[6]*x_tmp[7]+k[0]*p[0]*x_tmp[0]+k[0]*p[1]*x_tmp[1]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]*x_tmp[5]*2.0+(k[0]*k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[10]*2.0);
  xdot_tmp[9] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]*x_tmp[6]-(k[0]*k[0])*p[1]*x_tmp[9]+(k[0]*k[0])*p[2]*x_tmp[8]-(k[0]*k[0])*p[3]*x_tmp[9]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]*x_tmp[6]+(k[0]*k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[12]);
  xdot_tmp[10] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]*x_tmp[7]-(k[0]*k[0])*p[1]*x_tmp[10]-(k[0]*k[0])*p[5]*x_tmp[10]+(k[0]*k[0])*p[4]*t*x_tmp[9]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]*x_tmp[7]+(k[0]*k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[13]);
  xdot_tmp[11] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[2]*x_tmp[9]*2.0-(k[0]*k[0])*p[3]*x_tmp[11]*2.0+k[0]*p[2]*x_tmp[1]+k[0]*p[3]*x_tmp[2]);
  xdot_tmp[12] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[2]*x_tmp[10]-(k[0]*k[0])*p[3]*x_tmp[12]-(k[0]*k[0])*p[5]*x_tmp[12]+(k[0]*k[0])*p[4]*t*x_tmp[11]);
  xdot_tmp[13] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[5]*x_tmp[13]*-2.0+k[0]*p[5]*x_tmp[3]+k[0]*p[4]*t*x_tmp[2]+(k[0]*k[0])*p[4]*t*x_tmp[12]*2.0);
int ix;
for(ix = 0; ix<14; ix++) {
   if(mxIsNaN(xdot_tmp[ix])) {
       xdot_tmp[ix] = 0;       if(!udata->am_nan_xdot) {
           mexWarnMsgIdAndTxt("AMICI:mex:fxdot:NaN","AMICI replaced a NaN value in xdot and replaced it by 0.0. This will not be reported again for this simulation run.");           udata->am_nan_xdot = TRUE;
       }
   }   if(mxIsInf(xdot_tmp[ix])) {
       mexWarnMsgIdAndTxt("AMICI:mex:fxdot:Inf","AMICI encountered an Inf value in xdot! Aborting simulation ... ");       return(-1);   }}
return(0);

}


