#ifndef _am_AMICI_genExp_timeDep_x0_h
#define _am_AMICI_genExp_timeDep_x0_h

int x0_AMICI_genExp_timeDep(N_Vector x0, void *user_data);


#endif /* _am_AMICI_genExp_timeDep_x0_h */
