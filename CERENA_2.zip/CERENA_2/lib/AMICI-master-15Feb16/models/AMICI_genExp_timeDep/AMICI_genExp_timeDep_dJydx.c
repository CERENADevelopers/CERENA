
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int dJydx_AMICI_genExp_timeDep(realtype t, int it, realtype *dJydx, realtype *y, N_Vector x, realtype *dydx, realtype *my, realtype *sd_y, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
int iy;
for(iy=0;iy<2;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  dJydx[it+3*nt] += dydx[6]*1.0/(sd_y[0]*sd_y[0])*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1;
  dJydx[it+13*nt] += dydx[27]*1.0/(sd_y[1]*sd_y[1])*(my[it+nt*1]*2.0-y[it+nt*1]*2.0)*-5.0E-1;
return(0);

}


