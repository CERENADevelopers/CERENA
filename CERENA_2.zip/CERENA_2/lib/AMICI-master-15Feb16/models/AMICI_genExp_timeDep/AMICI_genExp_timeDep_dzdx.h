#ifndef _am_AMICI_genExp_timeDep_dzdx_h
#define _am_AMICI_genExp_timeDep_dzdx_h

int dzdx_AMICI_genExp_timeDep(realtype t, int ie, realtype *dzdx, N_Vector x, void *user_data);


#endif /* _am_AMICI_genExp_timeDep_dzdx_h */
