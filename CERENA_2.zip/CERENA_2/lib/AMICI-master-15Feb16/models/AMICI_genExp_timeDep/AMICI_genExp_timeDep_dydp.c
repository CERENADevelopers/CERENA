
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int dydp_AMICI_genExp_timeDep(realtype t, int it, realtype *dydp, N_Vector x, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
int ip;
for(ip = 0; ip<np; ip++) {
switch (plist[ip]) {
  case 7: {
  dydp[ip*2 + 0] = x_tmp[3];
  dydp[ip*2 + 1] = p[7]*(x_tmp[13]+x_tmp[3]*x_tmp[3])*2.0-p[7]*(x_tmp[3]*x_tmp[3])*2.0;

  } break;

  case 8: {
  dydp[ip*2 + 0] = 1.0;

  } break;

}
}
return(0);

}


