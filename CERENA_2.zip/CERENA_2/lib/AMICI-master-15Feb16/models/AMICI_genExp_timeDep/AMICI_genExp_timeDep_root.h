#ifndef _am_AMICI_genExp_timeDep_root_h
#define _am_AMICI_genExp_timeDep_root_h

int root_AMICI_genExp_timeDep(realtype t, N_Vector x, realtype *root, void *user_data);


#endif /* _am_AMICI_genExp_timeDep_root_h */
