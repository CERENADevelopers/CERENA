#ifndef _am_AMICI_genExp_timeDep_dJydx_h
#define _am_AMICI_genExp_timeDep_dJydx_h

int dJydx_AMICI_genExp_timeDep(realtype t, int it, realtype *dJydx, realtype *y, N_Vector x, realtype *dydx, realtype *my, realtype *sd_y, void *user_data);


#endif /* _am_AMICI_genExp_timeDep_dJydx_h */
