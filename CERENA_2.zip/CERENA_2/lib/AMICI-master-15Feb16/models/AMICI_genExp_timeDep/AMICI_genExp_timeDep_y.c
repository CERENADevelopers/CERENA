
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int y_AMICI_genExp_timeDep(realtype t, int it, realtype *y, N_Vector x, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
  y[it+nt*0] = p[8]+p[7]*x_tmp[3];
  y[it+nt*1] = -(p[7]*p[7])*(x_tmp[3]*x_tmp[3])+(p[7]*p[7])*(x_tmp[13]+x_tmp[3]*x_tmp[3]);
return(0);

}


