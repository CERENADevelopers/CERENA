
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int JB_AMICI_genExp_timeDep(long int NeqBdot, realtype t, N_Vector x, N_Vector xB, N_Vector xBdot, DlsMat JB, void *user_data, N_Vector tmp1B, N_Vector tmp2B, N_Vector tmp3B) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *xB_tmp = N_VGetArrayPointer(xB);
realtype *xBdot_tmp = N_VGetArrayPointer(xBdot);
  memset(JB->data,0,sizeof(realtype)*196);
  JB->data[0] = (k[0]*p[0]+(k[0]*k[0])*p[6]*x_tmp[3])/k[0];
  JB->data[1] = -p[1];
  JB->data[3] = k[0]*p[6]*x_tmp[0];
  JB->data[7] = k[0]*p[6];
  JB->data[14] = -(k[0]*p[0]+(k[0]*k[0])*p[6]*x_tmp[3])/k[0];
  JB->data[15] = p[1];
  JB->data[17] = -k[0]*p[6]*x_tmp[0];
  JB->data[21] = -k[0]*p[6];
  JB->data[29] = -p[2];
  JB->data[30] = p[3];
  JB->data[44] = -p[4]*t;
  JB->data[45] = p[5];
  JB->data[56] = -1.0/(k[0]*k[0])*(k[0]*p[0]+(k[0]*k[0])*p[6]*x_tmp[3]-(k[0]*k[0]*k[0])*p[6]*x_tmp[7]*2.0);
  JB->data[57] = -p[1]/k[0];
  JB->data[59] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[6]*x_tmp[0]-(k[0]*k[0]*k[0])*p[6]*x_tmp[4]*2.0);
  JB->data[60] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]*2.0+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]*2.0);
  JB->data[61] = p[1]*-2.0;
  JB->data[63] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[6]-(k[0]*k[0]*k[0])*p[6]*x_tmp[0]*2.0);
  JB->data[70] = 1.0/(k[0]*k[0])*(k[0]*p[0]+(k[0]*k[0])*p[6]*x_tmp[3]-(k[0]*k[0]*k[0])*p[6]*x_tmp[7]+(k[0]*k[0]*k[0])*p[6]*x_tmp[10]);
  JB->data[71] = p[1]/k[0];
  JB->data[73] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[6]*x_tmp[0]-(k[0]*k[0]*k[0])*p[6]*x_tmp[4]+(k[0]*k[0]*k[0])*p[6]*x_tmp[5]);
  JB->data[74] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]);
  JB->data[75] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]+(k[0]*k[0])*p[1]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]);
  JB->data[77] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[6]-(k[0]*k[0]*k[0])*p[6]*x_tmp[0]);
  JB->data[78] = -p[1];
  JB->data[80] = k[0]*p[6]*x_tmp[0];
  JB->data[84] = k[0]*p[6]*x_tmp[12];
  JB->data[87] = k[0]*p[6]*x_tmp[6];
  JB->data[89] = -p[2];
  JB->data[90] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]+(k[0]*k[0])*p[3]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]);
  JB->data[93] = -p[1];
  JB->data[96] = k[0]*p[6]*x_tmp[0];
  JB->data[98] = k[0]*p[6]*x_tmp[13];
  JB->data[101] = k[0]*p[6]*x_tmp[7];
  JB->data[104] = -p[4]*t;
  JB->data[105] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]+(k[0]*k[0])*p[5]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]);
  JB->data[108] = -p[1];
  JB->data[111] = k[0]*p[6]*x_tmp[0];
  JB->data[112] = -1.0/(k[0]*k[0])*(k[0]*p[0]+(k[0]*k[0])*p[6]*x_tmp[3]+(k[0]*k[0]*k[0])*p[6]*x_tmp[10]*2.0);
  JB->data[113] = -p[1]/k[0];
  JB->data[115] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[6]*x_tmp[0]+(k[0]*k[0]*k[0])*p[6]*x_tmp[5]*2.0);
  JB->data[117] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]*2.0+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]*2.0);
  JB->data[119] = -p[6];
  JB->data[120] = p[1]*2.0;
  JB->data[122] = k[0]*p[6]*x_tmp[0]*-2.0;
  JB->data[126] = -k[0]*p[6]*x_tmp[12];
  JB->data[129] = -k[0]*p[6]*x_tmp[6];
  JB->data[132] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]);
  JB->data[134] = -p[2];
  JB->data[135] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[1]+(k[0]*k[0])*p[3]);
  JB->data[138] = -k[0]*p[6]*x_tmp[0];
  JB->data[140] = -k[0]*p[6]*x_tmp[13];
  JB->data[143] = -k[0]*p[6]*x_tmp[7];
  JB->data[147] = -1.0/(k[0]*k[0])*((k[0]*k[0])*p[0]+(k[0]*k[0]*k[0])*p[6]*x_tmp[3]);
  JB->data[149] = -p[4]*t;
  JB->data[150] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[1]+(k[0]*k[0])*p[5]);
  JB->data[153] = -k[0]*p[6]*x_tmp[0];
  JB->data[155] = -p[2]/k[0];
  JB->data[156] = -p[3]/k[0];
  JB->data[163] = p[2]*-2.0;
  JB->data[165] = p[3]*2.0;
  JB->data[178] = -p[2];
  JB->data[179] = -p[4]*t;
  JB->data[180] = 1.0/(k[0]*k[0])*((k[0]*k[0])*p[3]+(k[0]*k[0])*p[5]);
  JB->data[184] = -(p[4]*t)/k[0];
  JB->data[185] = -p[5]/k[0];
  JB->data[194] = p[4]*t*-2.0;
  JB->data[195] = p[5]*2.0;
return(0);

}


