#ifndef _am_AMICI_genExp_timeDep_dzdp_h
#define _am_AMICI_genExp_timeDep_dzdp_h

int dzdp_AMICI_genExp_timeDep(realtype t, int ie, realtype *dzdp, N_Vector x, void *user_data);


#endif /* _am_AMICI_genExp_timeDep_dzdp_h */
