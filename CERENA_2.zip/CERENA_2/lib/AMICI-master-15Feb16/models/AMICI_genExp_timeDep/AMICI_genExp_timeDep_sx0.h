#ifndef _am_AMICI_genExp_timeDep_sx0_h
#define _am_AMICI_genExp_timeDep_sx0_h

int sx0_AMICI_genExp_timeDep(N_Vector *sx0, N_Vector x, N_Vector dx, void *user_data);


#endif /* _am_AMICI_genExp_timeDep_sx0_h */
