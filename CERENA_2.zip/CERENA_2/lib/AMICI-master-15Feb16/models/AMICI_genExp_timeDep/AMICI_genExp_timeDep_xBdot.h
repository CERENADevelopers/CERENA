#ifndef _am_AMICI_genExp_timeDep_xBdot_h
#define _am_AMICI_genExp_timeDep_xBdot_h

int xBdot_AMICI_genExp_timeDep(realtype t, N_Vector x, N_Vector xB, N_Vector xBdot, void *user_data);


#endif /* _am_AMICI_genExp_timeDep_xBdot_h */
