#ifndef _am_AMICI_genExp_timeDep_Jy_h
#define _am_AMICI_genExp_timeDep_Jy_h

int Jy_AMICI_genExp_timeDep(realtype t, int it, realtype *Jy, realtype *y, N_Vector x, realtype *my, realtype *sd_y, void *user_data);


#endif /* _am_AMICI_genExp_timeDep_Jy_h */
