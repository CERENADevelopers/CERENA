#ifndef _am_AMICI_genExp_timeDep_xdot_h
#define _am_AMICI_genExp_timeDep_xdot_h

int xdot_AMICI_genExp_timeDep(realtype t, N_Vector x, N_Vector xdot, void *user_data);


#endif /* _am_AMICI_genExp_timeDep_xdot_h */
