
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int sz_linearChain_MM2_f_a(realtype t, int ie, int *nroots, realtype *sz, N_Vector x, N_Vector *sx, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *sx_tmp;
int ip;
for(ip = 0; ip<np; ip++) {
sx_tmp = N_VGetArrayPointer(sx[plist[ip]]);
switch (plist[ip]) {
}
}
return(0);

}


