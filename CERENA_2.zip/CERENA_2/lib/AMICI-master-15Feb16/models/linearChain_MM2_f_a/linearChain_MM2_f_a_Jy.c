
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int Jy_linearChain_MM2_f_a(realtype t, int it, realtype *Jy, realtype *y, N_Vector x, realtype *my, realtype *sd_y, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
int iy;
for(iy=0;iy<1;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  Jy[0] += log((sd_y[0]*sd_y[0])*3.141592653589793*2.0)*5.0E-1+1.0/(sd_y[0]*sd_y[0])*pow(my[it+nt*0]-y[it+nt*0],2.0)*5.0E-1;
return(0);

}


