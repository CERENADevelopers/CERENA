
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int x0_linearChain_MM2_f_a(N_Vector x0, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x0_tmp = N_VGetArrayPointer(x0);
memset(x0_tmp,0,sizeof(realtype)*65);
  x0_tmp[0] = k[0]*-1.0E1+k[0]*k[65]+1.0E1;
  x0_tmp[1] = k[1]*k[66];
  x0_tmp[2] = k[2]*k[67];
  x0_tmp[3] = k[3]*k[68];
  x0_tmp[4] = k[4]*k[69];
  x0_tmp[5] = k[5]*k[70];
  x0_tmp[6] = k[6]*k[71];
  x0_tmp[7] = k[7]*k[72];
  x0_tmp[8] = k[8]*k[73];
  x0_tmp[9] = k[9]*k[74];
  x0_tmp[10] = k[10]*k[75];
  x0_tmp[11] = k[11]*k[76];
  x0_tmp[12] = k[12]*k[77];
  x0_tmp[13] = k[13]*k[78];
  x0_tmp[14] = k[14]*k[79];
  x0_tmp[15] = k[15]*k[80];
  x0_tmp[16] = k[16]*k[81];
  x0_tmp[17] = k[17]*k[82];
  x0_tmp[18] = k[18]*k[83];
  x0_tmp[19] = k[19]*k[84];
  x0_tmp[20] = k[20]*k[85];
  x0_tmp[21] = k[21]*k[86];
  x0_tmp[22] = k[22]*k[87];
  x0_tmp[23] = k[23]*k[88];
  x0_tmp[24] = k[24]*k[89];
  x0_tmp[25] = k[25]*k[90];
  x0_tmp[26] = k[26]*k[91];
  x0_tmp[27] = k[27]*k[92];
  x0_tmp[28] = k[28]*k[93];
  x0_tmp[29] = k[29]*k[94];
  x0_tmp[30] = k[30]*k[95];
  x0_tmp[31] = k[31]*k[96];
  x0_tmp[32] = k[32]*k[97];
  x0_tmp[33] = k[33]*k[98];
  x0_tmp[34] = k[34]*k[99];
  x0_tmp[35] = k[35]*k[100];
  x0_tmp[36] = k[36]*k[101];
  x0_tmp[37] = k[37]*k[102];
  x0_tmp[38] = k[38]*k[103];
  x0_tmp[39] = k[39]*k[104];
  x0_tmp[40] = k[40]*k[105];
  x0_tmp[41] = k[41]*k[106];
  x0_tmp[42] = k[42]*k[107];
  x0_tmp[43] = k[43]*k[108];
  x0_tmp[44] = k[44]*k[109];
  x0_tmp[45] = k[45]*k[110];
  x0_tmp[46] = k[46]*k[111];
  x0_tmp[47] = k[47]*k[112];
  x0_tmp[48] = k[48]*k[113];
  x0_tmp[49] = k[49]*k[114];
  x0_tmp[50] = k[50]*k[115];
  x0_tmp[51] = k[51]*k[116];
  x0_tmp[52] = k[52]*k[117];
  x0_tmp[53] = k[53]*k[118];
  x0_tmp[54] = k[54]*k[119];
  x0_tmp[55] = k[55]*k[120];
  x0_tmp[56] = k[56]*k[121];
  x0_tmp[57] = k[57]*k[122];
  x0_tmp[58] = k[58]*k[123];
  x0_tmp[59] = k[59]*k[124];
  x0_tmp[60] = k[60]*k[125];
  x0_tmp[61] = k[61]*k[126];
  x0_tmp[62] = k[62]*k[127];
  x0_tmp[63] = k[63]*k[128];
  x0_tmp[64] = k[64]*k[129];
return(0);

}


