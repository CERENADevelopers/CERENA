#ifndef _am_linearChain_MM2_f_a_sy_h
#define _am_linearChain_MM2_f_a_sy_h

int sy_linearChain_MM2_f_a(realtype t, int it, realtype *sy, N_Vector x, N_Vector *sx, void *user_data);


#endif /* _am_linearChain_MM2_f_a_sy_h */
