#ifndef _am_linearChain_MM2_f_a_Jv_h
#define _am_linearChain_MM2_f_a_Jv_h

int Jv_linearChain_MM2_f_a(N_Vector v, N_Vector Jv, realtype t, N_Vector x, N_Vector xdot, void *user_data, N_Vector tmp);


#endif /* _am_linearChain_MM2_f_a_Jv_h */
