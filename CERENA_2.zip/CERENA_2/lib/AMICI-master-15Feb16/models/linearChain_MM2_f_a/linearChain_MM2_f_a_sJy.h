#ifndef _am_linearChain_MM2_f_a_sJy_h
#define _am_linearChain_MM2_f_a_sJy_h

int sJy_linearChain_MM2_f_a(realtype t, int it, realtype *sJy, realtype *y, N_Vector x, realtype *dydp, realtype *sy, realtype *my, realtype *sd_y, realtype *dsigma_ydp, void *user_data);


#endif /* _am_linearChain_MM2_f_a_sJy_h */
