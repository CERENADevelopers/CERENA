
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int Jv_linearChain_MM2_f_a(N_Vector v, N_Vector Jv, realtype t, N_Vector x, N_Vector xdot, void *user_data, N_Vector tmp) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *xdot_tmp = N_VGetArrayPointer(xdot);
realtype *v_tmp = N_VGetArrayPointer(v);
realtype *Jv_tmp = N_VGetArrayPointer(Jv);
memset(Jv_tmp,0,sizeof(realtype)*65);
  Jv_tmp[0] = -p[1]*v_tmp[0]+p[2]*v_tmp[1];
  Jv_tmp[1] = -v_tmp[1]*(p[2]+p[3])+p[1]*v_tmp[0]+p[4]*v_tmp[2];
  Jv_tmp[2] = -v_tmp[2]*(p[4]+p[5])+p[3]*v_tmp[1]+p[6]*v_tmp[3];
  Jv_tmp[3] = -v_tmp[3]*(p[6]+p[7])+p[5]*v_tmp[2]+p[8]*v_tmp[4];
  Jv_tmp[4] = -v_tmp[4]*(p[8]+p[9])+p[7]*v_tmp[3]+p[10]*v_tmp[5];
  Jv_tmp[5] = -v_tmp[5]*(p[10]+p[11])+p[9]*v_tmp[4]+p[12]*v_tmp[6];
  Jv_tmp[6] = -v_tmp[6]*(p[12]+p[13])+p[11]*v_tmp[5]+p[14]*v_tmp[7];
  Jv_tmp[7] = -v_tmp[7]*(p[14]+p[15])+p[13]*v_tmp[6]+p[16]*v_tmp[8];
  Jv_tmp[8] = -v_tmp[8]*(p[16]+p[17])+p[15]*v_tmp[7]+p[18]*v_tmp[9];
  Jv_tmp[9] = -v_tmp[9]*(p[18]+p[19])+p[17]*v_tmp[8];
  Jv_tmp[10] = p[1]*v_tmp[0]+p[2]*v_tmp[1]-p[1]*v_tmp[10]*2.0+p[2]*v_tmp[11]*2.0;
  Jv_tmp[11] = -p[1]*v_tmp[0]-p[2]*v_tmp[1]+p[1]*v_tmp[10]+p[4]*v_tmp[12]+p[2]*v_tmp[20]-v_tmp[11]*(p[1]+p[2]+p[3]);
  Jv_tmp[12] = p[3]*v_tmp[11]+p[6]*v_tmp[13]+p[2]*v_tmp[21]-v_tmp[12]*(p[1]+p[4]+p[5]);
  Jv_tmp[13] = p[5]*v_tmp[12]+p[8]*v_tmp[14]+p[2]*v_tmp[22]-v_tmp[13]*(p[1]+p[6]+p[7]);
  Jv_tmp[14] = p[7]*v_tmp[13]+p[2]*v_tmp[23]+p[10]*v_tmp[15]-v_tmp[14]*(p[1]+p[8]+p[9]);
  Jv_tmp[15] = p[9]*v_tmp[14]+p[2]*v_tmp[24]+p[12]*v_tmp[16]-v_tmp[15]*(p[1]+p[10]+p[11]);
  Jv_tmp[16] = p[11]*v_tmp[15]+p[2]*v_tmp[25]+p[14]*v_tmp[17]-v_tmp[16]*(p[1]+p[12]+p[13]);
  Jv_tmp[17] = p[2]*v_tmp[26]+p[13]*v_tmp[16]+p[16]*v_tmp[18]-v_tmp[17]*(p[1]+p[14]+p[15]);
  Jv_tmp[18] = p[2]*v_tmp[27]+p[15]*v_tmp[17]+p[18]*v_tmp[19]-v_tmp[18]*(p[1]+p[16]+p[17]);
  Jv_tmp[19] = p[2]*v_tmp[28]+p[17]*v_tmp[18]-v_tmp[19]*(p[1]+p[18]+p[19]);
  Jv_tmp[20] = v_tmp[1]*(p[2]+p[3])+p[1]*v_tmp[0]+p[4]*v_tmp[2]+p[1]*v_tmp[11]*2.0+p[4]*v_tmp[21]*2.0-v_tmp[20]*(p[2]*2.0+p[3]*2.0);
  Jv_tmp[21] = -p[3]*v_tmp[1]-p[4]*v_tmp[2]+p[1]*v_tmp[12]+p[3]*v_tmp[20]+p[6]*v_tmp[22]+p[4]*v_tmp[29]-v_tmp[21]*(p[2]+p[3]+p[4]+p[5]);
  Jv_tmp[22] = p[1]*v_tmp[13]+p[5]*v_tmp[21]+p[8]*v_tmp[23]+p[4]*v_tmp[30]-v_tmp[22]*(p[2]+p[3]+p[6]+p[7]);
  Jv_tmp[23] = p[1]*v_tmp[14]+p[7]*v_tmp[22]+p[10]*v_tmp[24]+p[4]*v_tmp[31]-v_tmp[23]*(p[2]+p[3]+p[8]+p[9]);
  Jv_tmp[24] = p[1]*v_tmp[15]+p[9]*v_tmp[23]+p[4]*v_tmp[32]+p[12]*v_tmp[25]-v_tmp[24]*(p[2]+p[3]+p[10]+p[11]);
  Jv_tmp[25] = p[1]*v_tmp[16]+p[11]*v_tmp[24]+p[4]*v_tmp[33]+p[14]*v_tmp[26]-v_tmp[25]*(p[2]+p[3]+p[12]+p[13]);
  Jv_tmp[26] = p[1]*v_tmp[17]+p[4]*v_tmp[34]+p[13]*v_tmp[25]+p[16]*v_tmp[27]-v_tmp[26]*(p[2]+p[3]+p[14]+p[15]);
  Jv_tmp[27] = p[1]*v_tmp[18]+p[4]*v_tmp[35]+p[15]*v_tmp[26]+p[18]*v_tmp[28]-v_tmp[27]*(p[2]+p[3]+p[16]+p[17]);
  Jv_tmp[28] = p[1]*v_tmp[19]+p[4]*v_tmp[36]+p[17]*v_tmp[27]-v_tmp[28]*(p[2]+p[3]+p[18]+p[19]);
  Jv_tmp[29] = v_tmp[2]*(p[4]+p[5])+p[3]*v_tmp[1]+p[6]*v_tmp[3]+p[3]*v_tmp[21]*2.0+p[6]*v_tmp[30]*2.0-v_tmp[29]*(p[4]*2.0+p[5]*2.0);
  Jv_tmp[30] = -p[5]*v_tmp[2]-p[6]*v_tmp[3]+p[3]*v_tmp[22]+p[5]*v_tmp[29]+p[8]*v_tmp[31]+p[6]*v_tmp[37]-v_tmp[30]*(p[4]+p[5]+p[6]+p[7]);
  Jv_tmp[31] = p[3]*v_tmp[23]+p[7]*v_tmp[30]+p[10]*v_tmp[32]+p[6]*v_tmp[38]-v_tmp[31]*(p[4]+p[5]+p[8]+p[9]);
  Jv_tmp[32] = p[3]*v_tmp[24]+p[9]*v_tmp[31]+p[6]*v_tmp[39]+p[12]*v_tmp[33]-v_tmp[32]*(p[4]+p[5]+p[10]+p[11]);
  Jv_tmp[33] = p[3]*v_tmp[25]+p[11]*v_tmp[32]+p[6]*v_tmp[40]+p[14]*v_tmp[34]-v_tmp[33]*(p[4]+p[5]+p[12]+p[13]);
  Jv_tmp[34] = p[3]*v_tmp[26]+p[13]*v_tmp[33]+p[6]*v_tmp[41]+p[16]*v_tmp[35]-v_tmp[34]*(p[4]+p[5]+p[14]+p[15]);
  Jv_tmp[35] = p[3]*v_tmp[27]+p[6]*v_tmp[42]+p[15]*v_tmp[34]+p[18]*v_tmp[36]-v_tmp[35]*(p[4]+p[5]+p[16]+p[17]);
  Jv_tmp[36] = p[3]*v_tmp[28]+p[6]*v_tmp[43]+p[17]*v_tmp[35]-v_tmp[36]*(p[4]+p[5]+p[18]+p[19]);
  Jv_tmp[37] = v_tmp[3]*(p[6]+p[7])+p[5]*v_tmp[2]+p[8]*v_tmp[4]+p[5]*v_tmp[30]*2.0+p[8]*v_tmp[38]*2.0-v_tmp[37]*(p[6]*2.0+p[7]*2.0);
  Jv_tmp[38] = -p[7]*v_tmp[3]-p[8]*v_tmp[4]+p[5]*v_tmp[31]+p[7]*v_tmp[37]+p[10]*v_tmp[39]+p[8]*v_tmp[44]-v_tmp[38]*(p[6]+p[7]+p[8]+p[9]);
  Jv_tmp[39] = p[5]*v_tmp[32]+p[9]*v_tmp[38]+p[12]*v_tmp[40]+p[8]*v_tmp[45]-v_tmp[39]*(p[6]+p[7]+p[10]+p[11]);
  Jv_tmp[40] = p[5]*v_tmp[33]+p[11]*v_tmp[39]+p[8]*v_tmp[46]+p[14]*v_tmp[41]-v_tmp[40]*(p[6]+p[7]+p[12]+p[13]);
  Jv_tmp[41] = p[5]*v_tmp[34]+p[13]*v_tmp[40]+p[8]*v_tmp[47]+p[16]*v_tmp[42]-v_tmp[41]*(p[6]+p[7]+p[14]+p[15]);
  Jv_tmp[42] = p[5]*v_tmp[35]+p[8]*v_tmp[48]+p[15]*v_tmp[41]+p[18]*v_tmp[43]-v_tmp[42]*(p[6]+p[7]+p[16]+p[17]);
  Jv_tmp[43] = p[5]*v_tmp[36]+p[8]*v_tmp[49]+p[17]*v_tmp[42]-v_tmp[43]*(p[6]+p[7]+p[18]+p[19]);
  Jv_tmp[44] = v_tmp[4]*(p[8]+p[9])+p[7]*v_tmp[3]+p[10]*v_tmp[5]+p[7]*v_tmp[38]*2.0+p[10]*v_tmp[45]*2.0-v_tmp[44]*(p[8]*2.0+p[9]*2.0);
  Jv_tmp[45] = -p[9]*v_tmp[4]-p[10]*v_tmp[5]+p[7]*v_tmp[39]+p[9]*v_tmp[44]+p[12]*v_tmp[46]+p[10]*v_tmp[50]-v_tmp[45]*(p[8]+p[9]+p[10]+p[11]);
  Jv_tmp[46] = p[7]*v_tmp[40]+p[11]*v_tmp[45]+p[10]*v_tmp[51]+p[14]*v_tmp[47]-v_tmp[46]*(p[8]+p[9]+p[12]+p[13]);
  Jv_tmp[47] = p[7]*v_tmp[41]+p[13]*v_tmp[46]+p[10]*v_tmp[52]+p[16]*v_tmp[48]-v_tmp[47]*(p[8]+p[9]+p[14]+p[15]);
  Jv_tmp[48] = p[7]*v_tmp[42]+p[15]*v_tmp[47]+p[10]*v_tmp[53]+p[18]*v_tmp[49]-v_tmp[48]*(p[8]+p[9]+p[16]+p[17]);
  Jv_tmp[49] = p[7]*v_tmp[43]+p[10]*v_tmp[54]+p[17]*v_tmp[48]-v_tmp[49]*(p[8]+p[9]+p[18]+p[19]);
  Jv_tmp[50] = v_tmp[5]*(p[10]+p[11])+p[9]*v_tmp[4]+p[12]*v_tmp[6]+p[9]*v_tmp[45]*2.0+p[12]*v_tmp[51]*2.0-v_tmp[50]*(p[10]*2.0+p[11]*2.0);
  Jv_tmp[51] = -p[11]*v_tmp[5]-p[12]*v_tmp[6]+p[9]*v_tmp[46]+p[11]*v_tmp[50]+p[14]*v_tmp[52]+p[12]*v_tmp[55]-v_tmp[51]*(p[10]+p[11]+p[12]+p[13]);
  Jv_tmp[52] = p[9]*v_tmp[47]+p[13]*v_tmp[51]+p[12]*v_tmp[56]+p[16]*v_tmp[53]-v_tmp[52]*(p[10]+p[11]+p[14]+p[15]);
  Jv_tmp[53] = p[9]*v_tmp[48]+p[15]*v_tmp[52]+p[12]*v_tmp[57]+p[18]*v_tmp[54]-v_tmp[53]*(p[10]+p[11]+p[16]+p[17]);
  Jv_tmp[54] = p[9]*v_tmp[49]+p[12]*v_tmp[58]+p[17]*v_tmp[53]-v_tmp[54]*(p[10]+p[11]+p[18]+p[19]);
  Jv_tmp[55] = v_tmp[6]*(p[12]+p[13])+p[11]*v_tmp[5]+p[14]*v_tmp[7]+p[11]*v_tmp[51]*2.0+p[14]*v_tmp[56]*2.0-v_tmp[55]*(p[12]*2.0+p[13]*2.0);
  Jv_tmp[56] = -p[13]*v_tmp[6]-p[14]*v_tmp[7]+p[11]*v_tmp[52]+p[13]*v_tmp[55]+p[14]*v_tmp[59]+p[16]*v_tmp[57]-v_tmp[56]*(p[12]+p[13]+p[14]+p[15]);
  Jv_tmp[57] = p[11]*v_tmp[53]+p[15]*v_tmp[56]+p[14]*v_tmp[60]+p[18]*v_tmp[58]-v_tmp[57]*(p[12]+p[13]+p[16]+p[17]);
  Jv_tmp[58] = p[11]*v_tmp[54]+p[17]*v_tmp[57]+p[14]*v_tmp[61]-v_tmp[58]*(p[12]+p[13]+p[18]+p[19]);
  Jv_tmp[59] = v_tmp[7]*(p[14]+p[15])+p[13]*v_tmp[6]+p[16]*v_tmp[8]+p[13]*v_tmp[56]*2.0+p[16]*v_tmp[60]*2.0-v_tmp[59]*(p[14]*2.0+p[15]*2.0);
  Jv_tmp[60] = -p[15]*v_tmp[7]-p[16]*v_tmp[8]+p[13]*v_tmp[57]+p[15]*v_tmp[59]+p[16]*v_tmp[62]+p[18]*v_tmp[61]-v_tmp[60]*(p[14]+p[15]+p[16]+p[17]);
  Jv_tmp[61] = p[13]*v_tmp[58]+p[17]*v_tmp[60]+p[16]*v_tmp[63]-v_tmp[61]*(p[14]+p[15]+p[18]+p[19]);
  Jv_tmp[62] = v_tmp[8]*(p[16]+p[17])+p[15]*v_tmp[7]+p[18]*v_tmp[9]+p[15]*v_tmp[60]*2.0+p[18]*v_tmp[63]*2.0-v_tmp[62]*(p[16]*2.0+p[17]*2.0);
  Jv_tmp[63] = -p[17]*v_tmp[8]-p[18]*v_tmp[9]+p[15]*v_tmp[61]+p[17]*v_tmp[62]+p[18]*v_tmp[64]-v_tmp[63]*(p[16]+p[17]+p[18]+p[19]);
  Jv_tmp[64] = v_tmp[9]*(p[18]+p[19])+p[17]*v_tmp[8]+p[17]*v_tmp[63]*2.0-v_tmp[64]*(p[18]*2.0+p[19]*2.0);
return(0);

}


