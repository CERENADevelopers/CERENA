#ifndef _am_linearChain_MM2_f_a_dJzdx_h
#define _am_linearChain_MM2_f_a_dJzdx_h

int dJzdx_linearChain_MM2_f_a(realtype t, int ie, realtype *dJzdx, realtype *z, N_Vector x, realtype *dzdx, realtype *mz, realtype *sd_z, void *user_data, void *temp_data);


#endif /* _am_linearChain_MM2_f_a_dJzdx_h */
