
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int y_linearChain_MM2_f_a(realtype t, int it, realtype *y, N_Vector x, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
  y[it+nt*0] = x_tmp[9];
return(0);

}


