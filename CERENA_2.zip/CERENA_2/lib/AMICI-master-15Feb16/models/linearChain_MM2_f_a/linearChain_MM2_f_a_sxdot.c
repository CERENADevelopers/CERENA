
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>
#include "linearChain_MM2_f_a_JSparse.h"
#include "linearChain_MM2_f_a_dxdotdp.h"

int sxdot_linearChain_MM2_f_a(int Ns, realtype t, N_Vector x, N_Vector xdot,int ip,  N_Vector sx, N_Vector sxdot, void *user_data, N_Vector tmp1, N_Vector tmp2) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *sx_tmp = N_VGetArrayPointer(sx);
realtype *sxdot_tmp = N_VGetArrayPointer(sxdot);
realtype *xdot_tmp = N_VGetArrayPointer(xdot);
memset(sxdot_tmp,0,sizeof(realtype)*65);
int status = 0;
if(ip == 0) {
    status = JSparse_linearChain_MM2_f_a(t,x,xdot,tmp_J,user_data,NULL,NULL,NULL);
    status = dxdotdp_linearChain_MM2_f_a(t,tmp_dxdotdp,x,user_data);
}
  sxdot_tmp[0] = tmp_dxdotdp[0 + ip*65]+sx_tmp[0]*tmp_J->data[0]+sx_tmp[1]*tmp_J->data[5];
  sxdot_tmp[1] = tmp_dxdotdp[1 + ip*65]+sx_tmp[0]*tmp_J->data[1]+sx_tmp[1]*tmp_J->data[6]+sx_tmp[2]*tmp_J->data[13];
  sxdot_tmp[2] = tmp_dxdotdp[2 + ip*65]+sx_tmp[1]*tmp_J->data[7]+sx_tmp[2]*tmp_J->data[14]+sx_tmp[3]*tmp_J->data[21];
  sxdot_tmp[3] = tmp_dxdotdp[3 + ip*65]+sx_tmp[2]*tmp_J->data[15]+sx_tmp[3]*tmp_J->data[22]+sx_tmp[4]*tmp_J->data[29];
  sxdot_tmp[4] = tmp_dxdotdp[4 + ip*65]+sx_tmp[3]*tmp_J->data[23]+sx_tmp[4]*tmp_J->data[30]+sx_tmp[5]*tmp_J->data[37];
  sxdot_tmp[5] = tmp_dxdotdp[5 + ip*65]+sx_tmp[4]*tmp_J->data[31]+sx_tmp[5]*tmp_J->data[38]+sx_tmp[6]*tmp_J->data[45];
  sxdot_tmp[6] = tmp_dxdotdp[6 + ip*65]+sx_tmp[5]*tmp_J->data[39]+sx_tmp[6]*tmp_J->data[46]+sx_tmp[7]*tmp_J->data[53];
  sxdot_tmp[7] = tmp_dxdotdp[7 + ip*65]+sx_tmp[6]*tmp_J->data[47]+sx_tmp[7]*tmp_J->data[54]+sx_tmp[8]*tmp_J->data[61];
  sxdot_tmp[8] = tmp_dxdotdp[8 + ip*65]+sx_tmp[7]*tmp_J->data[55]+sx_tmp[8]*tmp_J->data[62]+sx_tmp[9]*tmp_J->data[69];
  sxdot_tmp[9] = tmp_dxdotdp[9 + ip*65]+sx_tmp[8]*tmp_J->data[63]+sx_tmp[9]*tmp_J->data[70];
  sxdot_tmp[10] = tmp_dxdotdp[10 + ip*65]+sx_tmp[0]*tmp_J->data[2]+sx_tmp[1]*tmp_J->data[8]+sx_tmp[10]*tmp_J->data[74]+sx_tmp[11]*tmp_J->data[76];
  sxdot_tmp[11] = tmp_dxdotdp[11 + ip*65]+sx_tmp[0]*tmp_J->data[3]+sx_tmp[1]*tmp_J->data[9]+sx_tmp[10]*tmp_J->data[75]+sx_tmp[11]*tmp_J->data[77]+sx_tmp[12]*tmp_J->data[80]+sx_tmp[20]*tmp_J->data[111];
  sxdot_tmp[12] = tmp_dxdotdp[12 + ip*65]+sx_tmp[11]*tmp_J->data[78]+sx_tmp[12]*tmp_J->data[81]+sx_tmp[13]*tmp_J->data[84]+sx_tmp[21]*tmp_J->data[114];
  sxdot_tmp[13] = tmp_dxdotdp[13 + ip*65]+sx_tmp[12]*tmp_J->data[82]+sx_tmp[13]*tmp_J->data[85]+sx_tmp[14]*tmp_J->data[88]+sx_tmp[22]*tmp_J->data[119];
  sxdot_tmp[14] = tmp_dxdotdp[14 + ip*65]+sx_tmp[13]*tmp_J->data[86]+sx_tmp[14]*tmp_J->data[89]+sx_tmp[15]*tmp_J->data[92]+sx_tmp[23]*tmp_J->data[124];
  sxdot_tmp[15] = tmp_dxdotdp[15 + ip*65]+sx_tmp[14]*tmp_J->data[90]+sx_tmp[15]*tmp_J->data[93]+sx_tmp[16]*tmp_J->data[96]+sx_tmp[24]*tmp_J->data[129];
  sxdot_tmp[16] = tmp_dxdotdp[16 + ip*65]+sx_tmp[15]*tmp_J->data[94]+sx_tmp[16]*tmp_J->data[97]+sx_tmp[17]*tmp_J->data[100]+sx_tmp[25]*tmp_J->data[134];
  sxdot_tmp[17] = tmp_dxdotdp[17 + ip*65]+sx_tmp[16]*tmp_J->data[98]+sx_tmp[17]*tmp_J->data[101]+sx_tmp[18]*tmp_J->data[104]+sx_tmp[26]*tmp_J->data[139];
  sxdot_tmp[18] = tmp_dxdotdp[18 + ip*65]+sx_tmp[17]*tmp_J->data[102]+sx_tmp[18]*tmp_J->data[105]+sx_tmp[19]*tmp_J->data[108]+sx_tmp[27]*tmp_J->data[144];
  sxdot_tmp[19] = tmp_dxdotdp[19 + ip*65]+sx_tmp[18]*tmp_J->data[106]+sx_tmp[19]*tmp_J->data[109]+sx_tmp[28]*tmp_J->data[149];
  sxdot_tmp[20] = tmp_dxdotdp[20 + ip*65]+sx_tmp[0]*tmp_J->data[4]+sx_tmp[1]*tmp_J->data[10]+sx_tmp[2]*tmp_J->data[16]+sx_tmp[11]*tmp_J->data[79]+sx_tmp[20]*tmp_J->data[112]+sx_tmp[21]*tmp_J->data[115];
  sxdot_tmp[21] = tmp_dxdotdp[21 + ip*65]+sx_tmp[1]*tmp_J->data[11]+sx_tmp[2]*tmp_J->data[17]+sx_tmp[12]*tmp_J->data[83]+sx_tmp[20]*tmp_J->data[113]+sx_tmp[21]*tmp_J->data[116]+sx_tmp[22]*tmp_J->data[120]+sx_tmp[29]*tmp_J->data[153];
  sxdot_tmp[22] = tmp_dxdotdp[22 + ip*65]+sx_tmp[13]*tmp_J->data[87]+sx_tmp[21]*tmp_J->data[117]+sx_tmp[22]*tmp_J->data[121]+sx_tmp[23]*tmp_J->data[125]+sx_tmp[30]*tmp_J->data[156];
  sxdot_tmp[23] = tmp_dxdotdp[23 + ip*65]+sx_tmp[14]*tmp_J->data[91]+sx_tmp[22]*tmp_J->data[122]+sx_tmp[23]*tmp_J->data[126]+sx_tmp[24]*tmp_J->data[130]+sx_tmp[31]*tmp_J->data[161];
  sxdot_tmp[24] = tmp_dxdotdp[24 + ip*65]+sx_tmp[15]*tmp_J->data[95]+sx_tmp[23]*tmp_J->data[127]+sx_tmp[24]*tmp_J->data[131]+sx_tmp[25]*tmp_J->data[135]+sx_tmp[32]*tmp_J->data[166];
  sxdot_tmp[25] = tmp_dxdotdp[25 + ip*65]+sx_tmp[16]*tmp_J->data[99]+sx_tmp[24]*tmp_J->data[132]+sx_tmp[25]*tmp_J->data[136]+sx_tmp[26]*tmp_J->data[140]+sx_tmp[33]*tmp_J->data[171];
  sxdot_tmp[26] = tmp_dxdotdp[26 + ip*65]+sx_tmp[17]*tmp_J->data[103]+sx_tmp[25]*tmp_J->data[137]+sx_tmp[26]*tmp_J->data[141]+sx_tmp[27]*tmp_J->data[145]+sx_tmp[34]*tmp_J->data[176];
  sxdot_tmp[27] = tmp_dxdotdp[27 + ip*65]+sx_tmp[18]*tmp_J->data[107]+sx_tmp[26]*tmp_J->data[142]+sx_tmp[27]*tmp_J->data[146]+sx_tmp[28]*tmp_J->data[150]+sx_tmp[35]*tmp_J->data[181];
  sxdot_tmp[28] = tmp_dxdotdp[28 + ip*65]+sx_tmp[19]*tmp_J->data[110]+sx_tmp[27]*tmp_J->data[147]+sx_tmp[28]*tmp_J->data[151]+sx_tmp[36]*tmp_J->data[186];
  sxdot_tmp[29] = tmp_dxdotdp[29 + ip*65]+sx_tmp[1]*tmp_J->data[12]+sx_tmp[2]*tmp_J->data[18]+sx_tmp[3]*tmp_J->data[24]+sx_tmp[21]*tmp_J->data[118]+sx_tmp[29]*tmp_J->data[154]+sx_tmp[30]*tmp_J->data[157];
  sxdot_tmp[30] = tmp_dxdotdp[30 + ip*65]+sx_tmp[2]*tmp_J->data[19]+sx_tmp[3]*tmp_J->data[25]+sx_tmp[22]*tmp_J->data[123]+sx_tmp[29]*tmp_J->data[155]+sx_tmp[30]*tmp_J->data[158]+sx_tmp[31]*tmp_J->data[162]+sx_tmp[37]*tmp_J->data[190];
  sxdot_tmp[31] = tmp_dxdotdp[31 + ip*65]+sx_tmp[23]*tmp_J->data[128]+sx_tmp[30]*tmp_J->data[159]+sx_tmp[31]*tmp_J->data[163]+sx_tmp[32]*tmp_J->data[167]+sx_tmp[38]*tmp_J->data[193];
  sxdot_tmp[32] = tmp_dxdotdp[32 + ip*65]+sx_tmp[24]*tmp_J->data[133]+sx_tmp[31]*tmp_J->data[164]+sx_tmp[32]*tmp_J->data[168]+sx_tmp[33]*tmp_J->data[172]+sx_tmp[39]*tmp_J->data[198];
  sxdot_tmp[33] = tmp_dxdotdp[33 + ip*65]+sx_tmp[25]*tmp_J->data[138]+sx_tmp[32]*tmp_J->data[169]+sx_tmp[33]*tmp_J->data[173]+sx_tmp[34]*tmp_J->data[177]+sx_tmp[40]*tmp_J->data[203];
  sxdot_tmp[34] = tmp_dxdotdp[34 + ip*65]+sx_tmp[26]*tmp_J->data[143]+sx_tmp[33]*tmp_J->data[174]+sx_tmp[34]*tmp_J->data[178]+sx_tmp[35]*tmp_J->data[182]+sx_tmp[41]*tmp_J->data[208];
  sxdot_tmp[35] = tmp_dxdotdp[35 + ip*65]+sx_tmp[27]*tmp_J->data[148]+sx_tmp[34]*tmp_J->data[179]+sx_tmp[35]*tmp_J->data[183]+sx_tmp[36]*tmp_J->data[187]+sx_tmp[42]*tmp_J->data[213];
  sxdot_tmp[36] = tmp_dxdotdp[36 + ip*65]+sx_tmp[28]*tmp_J->data[152]+sx_tmp[35]*tmp_J->data[184]+sx_tmp[36]*tmp_J->data[188]+sx_tmp[43]*tmp_J->data[218];
  sxdot_tmp[37] = tmp_dxdotdp[37 + ip*65]+sx_tmp[2]*tmp_J->data[20]+sx_tmp[3]*tmp_J->data[26]+sx_tmp[4]*tmp_J->data[32]+sx_tmp[30]*tmp_J->data[160]+sx_tmp[37]*tmp_J->data[191]+sx_tmp[38]*tmp_J->data[194];
  sxdot_tmp[38] = tmp_dxdotdp[38 + ip*65]+sx_tmp[3]*tmp_J->data[27]+sx_tmp[4]*tmp_J->data[33]+sx_tmp[31]*tmp_J->data[165]+sx_tmp[37]*tmp_J->data[192]+sx_tmp[38]*tmp_J->data[195]+sx_tmp[39]*tmp_J->data[199]+sx_tmp[44]*tmp_J->data[222];
  sxdot_tmp[39] = tmp_dxdotdp[39 + ip*65]+sx_tmp[32]*tmp_J->data[170]+sx_tmp[38]*tmp_J->data[196]+sx_tmp[39]*tmp_J->data[200]+sx_tmp[40]*tmp_J->data[204]+sx_tmp[45]*tmp_J->data[225];
  sxdot_tmp[40] = tmp_dxdotdp[40 + ip*65]+sx_tmp[33]*tmp_J->data[175]+sx_tmp[39]*tmp_J->data[201]+sx_tmp[40]*tmp_J->data[205]+sx_tmp[41]*tmp_J->data[209]+sx_tmp[46]*tmp_J->data[230];
  sxdot_tmp[41] = tmp_dxdotdp[41 + ip*65]+sx_tmp[34]*tmp_J->data[180]+sx_tmp[40]*tmp_J->data[206]+sx_tmp[41]*tmp_J->data[210]+sx_tmp[42]*tmp_J->data[214]+sx_tmp[47]*tmp_J->data[235];
  sxdot_tmp[42] = tmp_dxdotdp[42 + ip*65]+sx_tmp[35]*tmp_J->data[185]+sx_tmp[41]*tmp_J->data[211]+sx_tmp[42]*tmp_J->data[215]+sx_tmp[43]*tmp_J->data[219]+sx_tmp[48]*tmp_J->data[240];
  sxdot_tmp[43] = tmp_dxdotdp[43 + ip*65]+sx_tmp[36]*tmp_J->data[189]+sx_tmp[42]*tmp_J->data[216]+sx_tmp[43]*tmp_J->data[220]+sx_tmp[49]*tmp_J->data[245];
  sxdot_tmp[44] = tmp_dxdotdp[44 + ip*65]+sx_tmp[3]*tmp_J->data[28]+sx_tmp[4]*tmp_J->data[34]+sx_tmp[5]*tmp_J->data[40]+sx_tmp[38]*tmp_J->data[197]+sx_tmp[44]*tmp_J->data[223]+sx_tmp[45]*tmp_J->data[226];
  sxdot_tmp[45] = tmp_dxdotdp[45 + ip*65]+sx_tmp[4]*tmp_J->data[35]+sx_tmp[5]*tmp_J->data[41]+sx_tmp[39]*tmp_J->data[202]+sx_tmp[44]*tmp_J->data[224]+sx_tmp[45]*tmp_J->data[227]+sx_tmp[46]*tmp_J->data[231]+sx_tmp[50]*tmp_J->data[249];
  sxdot_tmp[46] = tmp_dxdotdp[46 + ip*65]+sx_tmp[40]*tmp_J->data[207]+sx_tmp[45]*tmp_J->data[228]+sx_tmp[46]*tmp_J->data[232]+sx_tmp[47]*tmp_J->data[236]+sx_tmp[51]*tmp_J->data[252];
  sxdot_tmp[47] = tmp_dxdotdp[47 + ip*65]+sx_tmp[41]*tmp_J->data[212]+sx_tmp[46]*tmp_J->data[233]+sx_tmp[47]*tmp_J->data[237]+sx_tmp[48]*tmp_J->data[241]+sx_tmp[52]*tmp_J->data[257];
  sxdot_tmp[48] = tmp_dxdotdp[48 + ip*65]+sx_tmp[42]*tmp_J->data[217]+sx_tmp[47]*tmp_J->data[238]+sx_tmp[48]*tmp_J->data[242]+sx_tmp[49]*tmp_J->data[246]+sx_tmp[53]*tmp_J->data[262];
  sxdot_tmp[49] = tmp_dxdotdp[49 + ip*65]+sx_tmp[43]*tmp_J->data[221]+sx_tmp[48]*tmp_J->data[243]+sx_tmp[49]*tmp_J->data[247]+sx_tmp[54]*tmp_J->data[267];
  sxdot_tmp[50] = tmp_dxdotdp[50 + ip*65]+sx_tmp[4]*tmp_J->data[36]+sx_tmp[5]*tmp_J->data[42]+sx_tmp[6]*tmp_J->data[48]+sx_tmp[45]*tmp_J->data[229]+sx_tmp[50]*tmp_J->data[250]+sx_tmp[51]*tmp_J->data[253];
  sxdot_tmp[51] = tmp_dxdotdp[51 + ip*65]+sx_tmp[5]*tmp_J->data[43]+sx_tmp[6]*tmp_J->data[49]+sx_tmp[46]*tmp_J->data[234]+sx_tmp[50]*tmp_J->data[251]+sx_tmp[51]*tmp_J->data[254]+sx_tmp[52]*tmp_J->data[258]+sx_tmp[55]*tmp_J->data[271];
  sxdot_tmp[52] = tmp_dxdotdp[52 + ip*65]+sx_tmp[47]*tmp_J->data[239]+sx_tmp[51]*tmp_J->data[255]+sx_tmp[52]*tmp_J->data[259]+sx_tmp[53]*tmp_J->data[263]+sx_tmp[56]*tmp_J->data[274];
  sxdot_tmp[53] = tmp_dxdotdp[53 + ip*65]+sx_tmp[48]*tmp_J->data[244]+sx_tmp[52]*tmp_J->data[260]+sx_tmp[53]*tmp_J->data[264]+sx_tmp[54]*tmp_J->data[268]+sx_tmp[57]*tmp_J->data[279];
  sxdot_tmp[54] = tmp_dxdotdp[54 + ip*65]+sx_tmp[49]*tmp_J->data[248]+sx_tmp[53]*tmp_J->data[265]+sx_tmp[54]*tmp_J->data[269]+sx_tmp[58]*tmp_J->data[284];
  sxdot_tmp[55] = tmp_dxdotdp[55 + ip*65]+sx_tmp[5]*tmp_J->data[44]+sx_tmp[6]*tmp_J->data[50]+sx_tmp[7]*tmp_J->data[56]+sx_tmp[51]*tmp_J->data[256]+sx_tmp[55]*tmp_J->data[272]+sx_tmp[56]*tmp_J->data[275];
  sxdot_tmp[56] = tmp_dxdotdp[56 + ip*65]+sx_tmp[6]*tmp_J->data[51]+sx_tmp[7]*tmp_J->data[57]+sx_tmp[52]*tmp_J->data[261]+sx_tmp[55]*tmp_J->data[273]+sx_tmp[56]*tmp_J->data[276]+sx_tmp[57]*tmp_J->data[280]+sx_tmp[59]*tmp_J->data[288];
  sxdot_tmp[57] = tmp_dxdotdp[57 + ip*65]+sx_tmp[53]*tmp_J->data[266]+sx_tmp[56]*tmp_J->data[277]+sx_tmp[57]*tmp_J->data[281]+sx_tmp[58]*tmp_J->data[285]+sx_tmp[60]*tmp_J->data[291];
  sxdot_tmp[58] = tmp_dxdotdp[58 + ip*65]+sx_tmp[54]*tmp_J->data[270]+sx_tmp[57]*tmp_J->data[282]+sx_tmp[58]*tmp_J->data[286]+sx_tmp[61]*tmp_J->data[296];
  sxdot_tmp[59] = tmp_dxdotdp[59 + ip*65]+sx_tmp[6]*tmp_J->data[52]+sx_tmp[7]*tmp_J->data[58]+sx_tmp[8]*tmp_J->data[64]+sx_tmp[56]*tmp_J->data[278]+sx_tmp[59]*tmp_J->data[289]+sx_tmp[60]*tmp_J->data[292];
  sxdot_tmp[60] = tmp_dxdotdp[60 + ip*65]+sx_tmp[7]*tmp_J->data[59]+sx_tmp[8]*tmp_J->data[65]+sx_tmp[57]*tmp_J->data[283]+sx_tmp[59]*tmp_J->data[290]+sx_tmp[60]*tmp_J->data[293]+sx_tmp[61]*tmp_J->data[297]+sx_tmp[62]*tmp_J->data[300];
  sxdot_tmp[61] = tmp_dxdotdp[61 + ip*65]+sx_tmp[58]*tmp_J->data[287]+sx_tmp[60]*tmp_J->data[294]+sx_tmp[61]*tmp_J->data[298]+sx_tmp[63]*tmp_J->data[303];
  sxdot_tmp[62] = tmp_dxdotdp[62 + ip*65]+sx_tmp[7]*tmp_J->data[60]+sx_tmp[8]*tmp_J->data[66]+sx_tmp[9]*tmp_J->data[71]+sx_tmp[60]*tmp_J->data[295]+sx_tmp[62]*tmp_J->data[301]+sx_tmp[63]*tmp_J->data[304];
  sxdot_tmp[63] = tmp_dxdotdp[63 + ip*65]+sx_tmp[8]*tmp_J->data[67]+sx_tmp[9]*tmp_J->data[72]+sx_tmp[61]*tmp_J->data[299]+sx_tmp[62]*tmp_J->data[302]+sx_tmp[63]*tmp_J->data[305]+sx_tmp[64]*tmp_J->data[307];
  sxdot_tmp[64] = tmp_dxdotdp[64 + ip*65]+sx_tmp[8]*tmp_J->data[68]+sx_tmp[9]*tmp_J->data[73]+sx_tmp[63]*tmp_J->data[306]+sx_tmp[64]*tmp_J->data[308];
return(status);

}


