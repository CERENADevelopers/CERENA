#ifndef _am_linearChain_MM2_f_a_dydx_h
#define _am_linearChain_MM2_f_a_dydx_h

int dydx_linearChain_MM2_f_a(realtype t, int it, realtype *dydx, N_Vector x, void *user_data);


#endif /* _am_linearChain_MM2_f_a_dydx_h */
