#ifndef _am_linearChain_MM2_f_a_x0_h
#define _am_linearChain_MM2_f_a_x0_h

int x0_linearChain_MM2_f_a(N_Vector x0, void *user_data);


#endif /* _am_linearChain_MM2_f_a_x0_h */
