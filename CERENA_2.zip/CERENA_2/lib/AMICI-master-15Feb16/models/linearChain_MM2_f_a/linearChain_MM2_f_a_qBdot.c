
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>
#include "linearChain_MM2_f_a_dxdotdp.h"

int qBdot_linearChain_MM2_f_a(realtype t, N_Vector x, N_Vector xB, N_Vector qBdot, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *xB_tmp = N_VGetArrayPointer(xB);
realtype *qBdot_tmp = N_VGetArrayPointer(qBdot);
memset(qBdot_tmp,0,sizeof(realtype)*np);
int status;
int ip;
status = dxdotdp_linearChain_MM2_f_a(t,tmp_dxdotdp,x,user_data);
for(ip = 0; ip<np; ip++) {
  qBdot_tmp[ip] = -tmp_dxdotdp[0 + ip*65]*xB_tmp[0]-tmp_dxdotdp[1 + ip*65]*xB_tmp[1]-tmp_dxdotdp[2 + ip*65]*xB_tmp[2]-tmp_dxdotdp[3 + ip*65]*xB_tmp[3]-tmp_dxdotdp[4 + ip*65]*xB_tmp[4]-tmp_dxdotdp[5 + ip*65]*xB_tmp[5]-tmp_dxdotdp[6 + ip*65]*xB_tmp[6]-tmp_dxdotdp[7 + ip*65]*xB_tmp[7]-tmp_dxdotdp[8 + ip*65]*xB_tmp[8]-tmp_dxdotdp[9 + ip*65]*xB_tmp[9]-tmp_dxdotdp[10 + ip*65]*xB_tmp[10]-tmp_dxdotdp[11 + ip*65]*xB_tmp[11]-tmp_dxdotdp[12 + ip*65]*xB_tmp[12]-tmp_dxdotdp[13 + ip*65]*xB_tmp[13]-tmp_dxdotdp[14 + ip*65]*xB_tmp[14]-tmp_dxdotdp[15 + ip*65]*xB_tmp[15]-tmp_dxdotdp[16 + ip*65]*xB_tmp[16]-tmp_dxdotdp[17 + ip*65]*xB_tmp[17]-tmp_dxdotdp[18 + ip*65]*xB_tmp[18]-tmp_dxdotdp[19 + ip*65]*xB_tmp[19]-tmp_dxdotdp[20 + ip*65]*xB_tmp[20]-tmp_dxdotdp[21 + ip*65]*xB_tmp[21]-tmp_dxdotdp[22 + ip*65]*xB_tmp[22]-tmp_dxdotdp[23 + ip*65]*xB_tmp[23]-tmp_dxdotdp[24 + ip*65]*xB_tmp[24]-tmp_dxdotdp[25 + ip*65]*xB_tmp[25]-tmp_dxdotdp[26 + ip*65]*xB_tmp[26]-tmp_dxdotdp[27 + ip*65]*xB_tmp[27]-tmp_dxdotdp[28 + ip*65]*xB_tmp[28]-tmp_dxdotdp[29 + ip*65]*xB_tmp[29]-tmp_dxdotdp[30 + ip*65]*xB_tmp[30]-tmp_dxdotdp[31 + ip*65]*xB_tmp[31]-tmp_dxdotdp[32 + ip*65]*xB_tmp[32]-tmp_dxdotdp[33 + ip*65]*xB_tmp[33]-tmp_dxdotdp[34 + ip*65]*xB_tmp[34]-tmp_dxdotdp[35 + ip*65]*xB_tmp[35]-tmp_dxdotdp[36 + ip*65]*xB_tmp[36]-tmp_dxdotdp[37 + ip*65]*xB_tmp[37]-tmp_dxdotdp[38 + ip*65]*xB_tmp[38]-tmp_dxdotdp[39 + ip*65]*xB_tmp[39]-tmp_dxdotdp[40 + ip*65]*xB_tmp[40]-tmp_dxdotdp[41 + ip*65]*xB_tmp[41]-tmp_dxdotdp[42 + ip*65]*xB_tmp[42]-tmp_dxdotdp[43 + ip*65]*xB_tmp[43]-tmp_dxdotdp[44 + ip*65]*xB_tmp[44]-tmp_dxdotdp[45 + ip*65]*xB_tmp[45]-tmp_dxdotdp[46 + ip*65]*xB_tmp[46]-tmp_dxdotdp[47 + ip*65]*xB_tmp[47]-tmp_dxdotdp[48 + ip*65]*xB_tmp[48]-tmp_dxdotdp[49 + ip*65]*xB_tmp[49]-tmp_dxdotdp[50 + ip*65]*xB_tmp[50]-tmp_dxdotdp[51 + ip*65]*xB_tmp[51]-tmp_dxdotdp[52 + ip*65]*xB_tmp[52]-tmp_dxdotdp[53 + ip*65]*xB_tmp[53]-tmp_dxdotdp[54 + ip*65]*xB_tmp[54]-tmp_dxdotdp[55 + ip*65]*xB_tmp[55]-tmp_dxdotdp[56 + ip*65]*xB_tmp[56]-tmp_dxdotdp[57 + ip*65]*xB_tmp[57]-tmp_dxdotdp[58 + ip*65]*xB_tmp[58]-tmp_dxdotdp[59 + ip*65]*xB_tmp[59]-tmp_dxdotdp[60 + ip*65]*xB_tmp[60]-tmp_dxdotdp[61 + ip*65]*xB_tmp[61]-tmp_dxdotdp[62 + ip*65]*xB_tmp[62]-tmp_dxdotdp[63 + ip*65]*xB_tmp[63]-tmp_dxdotdp[64 + ip*65]*xB_tmp[64];
}
for(ip = 0; ip<np; ip++) {
   if(mxIsNaN(qBdot_tmp[ip])) {
       qBdot_tmp[ip] = 0;       if(!udata->am_nan_qBdot) {
           mexWarnMsgIdAndTxt("AMICI:mex:fqBdot:NaN","AMICI replaced a NaN value in xBdot and replaced it by 0.0. This will not be reported again for this simulation run.");           udata->am_nan_qBdot = TRUE;
       }
   }   if(mxIsInf(qBdot_tmp[ip])) {
       mexWarnMsgIdAndTxt("AMICI:mex:fqBdot:Inf","AMICI encountered an Inf value in xBdot! Aborting simulation ... ");       return(-1);   }}
return(status);

}


