#ifndef _am_linearChain_MM2_f_a_sxdot_h
#define _am_linearChain_MM2_f_a_sxdot_h

int sxdot_linearChain_MM2_f_a(int Ns, realtype t, N_Vector x, N_Vector xdot,int ip,  N_Vector sx, N_Vector sxdot, void *user_data, N_Vector tmp1, N_Vector tmp2);


#endif /* _am_linearChain_MM2_f_a_sxdot_h */
