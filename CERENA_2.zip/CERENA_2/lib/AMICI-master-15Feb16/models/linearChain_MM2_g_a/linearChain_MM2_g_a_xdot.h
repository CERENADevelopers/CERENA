#ifndef _am_linearChain_MM2_g_a_xdot_h
#define _am_linearChain_MM2_g_a_xdot_h

int xdot_linearChain_MM2_g_a(realtype t, N_Vector x, N_Vector xdot, void *user_data);


#endif /* _am_linearChain_MM2_g_a_xdot_h */
