
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int x0_linearChain_MM2_g_a(N_Vector x0, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x0_tmp = N_VGetArrayPointer(x0);
memset(x0_tmp,0,sizeof(realtype)*29);
  x0_tmp[0] = k[0]*-1.0E1+k[0]*k[65]+1.0E1;
  x0_tmp[1] = k[1]*k[66];
  x0_tmp[2] = k[2]*k[67];
  x0_tmp[3] = k[3]*k[68];
  x0_tmp[4] = k[4]*k[69];
  x0_tmp[5] = k[5]*k[70];
  x0_tmp[6] = k[6]*k[71];
  x0_tmp[7] = k[7]*k[72];
  x0_tmp[8] = k[8]*k[73];
  x0_tmp[9] = k[9]*k[74];
  x0_tmp[10] = k[10]*k[75];
  x0_tmp[11] = k[11]*k[76];
  x0_tmp[12] = k[20]*k[85];
  x0_tmp[13] = k[21]*k[86];
  x0_tmp[14] = k[29]*k[94];
  x0_tmp[15] = k[30]*k[95];
  x0_tmp[16] = k[37]*k[102];
  x0_tmp[17] = k[38]*k[103];
  x0_tmp[18] = k[44]*k[109];
  x0_tmp[19] = k[45]*k[110];
  x0_tmp[20] = k[50]*k[115];
  x0_tmp[21] = k[51]*k[116];
  x0_tmp[22] = k[55]*k[120];
  x0_tmp[23] = k[56]*k[121];
  x0_tmp[24] = k[59]*k[124];
  x0_tmp[25] = k[60]*k[125];
  x0_tmp[26] = k[62]*k[127];
  x0_tmp[27] = k[63]*k[128];
  x0_tmp[28] = k[64]*k[129];
return(0);

}


