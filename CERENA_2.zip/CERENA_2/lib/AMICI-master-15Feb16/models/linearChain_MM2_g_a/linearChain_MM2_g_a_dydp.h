#ifndef _am_linearChain_MM2_g_a_dydp_h
#define _am_linearChain_MM2_g_a_dydp_h

int dydp_linearChain_MM2_g_a(realtype t, int it, realtype *dydp, N_Vector x, void *user_data);


#endif /* _am_linearChain_MM2_g_a_dydp_h */
