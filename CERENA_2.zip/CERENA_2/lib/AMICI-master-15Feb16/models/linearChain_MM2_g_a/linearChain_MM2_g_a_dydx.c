
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int dydx_linearChain_MM2_g_a(realtype t, int it, realtype *dydx, N_Vector x, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
  dydx[9] = 1.0;
return(0);

}


