#ifndef _am_linearChain_MM2_g_a_y_h
#define _am_linearChain_MM2_g_a_y_h

int y_linearChain_MM2_g_a(realtype t, int it, realtype *y, N_Vector x, void *user_data);


#endif /* _am_linearChain_MM2_g_a_y_h */
