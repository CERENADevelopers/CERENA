#ifndef _am_linearChain_MM2_g_a_root_h
#define _am_linearChain_MM2_g_a_root_h

int root_linearChain_MM2_g_a(realtype t, N_Vector x, realtype *root, void *user_data);


#endif /* _am_linearChain_MM2_g_a_root_h */
