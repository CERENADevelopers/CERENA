#ifndef _am_linearChain_MM2_g_a_dzdp_h
#define _am_linearChain_MM2_g_a_dzdp_h

int dzdp_linearChain_MM2_g_a(realtype t, int ie, realtype *dzdp, N_Vector x, void *user_data);


#endif /* _am_linearChain_MM2_g_a_dzdp_h */
