
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int sJy_linearChain_MM2_g_a(realtype t, int it, realtype *sJy, realtype *y, N_Vector x, realtype *dydp, realtype *sy, realtype *my, realtype *sd_y, realtype *dsigma_ydp, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
int ip;
for(ip = 0; ip<np; ip++) {
switch (plist[ip]) {
  case 0: {
int iy;
for(iy=0;iy<1;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*1)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1;

  } break;

  case 1: {
int iy;
for(iy=0;iy<1;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*1)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1;

  } break;

  case 2: {
int iy;
for(iy=0;iy<1;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*1)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1;

  } break;

  case 3: {
int iy;
for(iy=0;iy<1;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*1)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1;

  } break;

  case 4: {
int iy;
for(iy=0;iy<1;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*1)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1;

  } break;

  case 5: {
int iy;
for(iy=0;iy<1;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*1)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1;

  } break;

  case 6: {
int iy;
for(iy=0;iy<1;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*1)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1;

  } break;

  case 7: {
int iy;
for(iy=0;iy<1;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*1)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1;

  } break;

  case 8: {
int iy;
for(iy=0;iy<1;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*1)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1;

  } break;

  case 9: {
int iy;
for(iy=0;iy<1;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*1)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1;

  } break;

  case 10: {
int iy;
for(iy=0;iy<1;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*1)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1;

  } break;

  case 11: {
int iy;
for(iy=0;iy<1;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*1)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1;

  } break;

  case 12: {
int iy;
for(iy=0;iy<1;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*1)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1;

  } break;

  case 13: {
int iy;
for(iy=0;iy<1;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*1)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1;

  } break;

  case 14: {
int iy;
for(iy=0;iy<1;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*1)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1;

  } break;

  case 15: {
int iy;
for(iy=0;iy<1;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*1)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1;

  } break;

  case 16: {
int iy;
for(iy=0;iy<1;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*1)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1;

  } break;

  case 17: {
int iy;
for(iy=0;iy<1;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*1)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1;

  } break;

  case 18: {
int iy;
for(iy=0;iy<1;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*1)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1;

  } break;

  case 19: {
int iy;
for(iy=0;iy<1;iy++){
    if(mxIsNaN(my[iy*nt+it])){
        my[iy*nt+it] = y[iy*nt+it];
    }
}
  sJy[0] += 1.0/(sd_y[0]*sd_y[0])*sy[it+nt*(0+ip*1)]*(my[it+nt*0]*2.0-y[it+nt*0]*2.0)*-5.0E-1;

  } break;

}
}
return(0);

}


