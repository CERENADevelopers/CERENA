#ifndef _am_linearChain_MM2_g_a_dJzdp_h
#define _am_linearChain_MM2_g_a_dJzdp_h

int dJzdp_linearChain_MM2_g_a(realtype t, int ie, realtype *dJzdp, realtype *z, N_Vector x, realtype *dzdp, realtype *mz, realtype *sd_z, realtype *dsigma_zdp, void *user_data, void *temp_data);


#endif /* _am_linearChain_MM2_g_a_dJzdp_h */
