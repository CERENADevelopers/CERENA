#ifndef _am_linearChain_MM2_g_a_deltasx_h
#define _am_linearChain_MM2_g_a_deltasx_h

int deltasx_linearChain_MM2_g_a(realtype t, int ie, realtype *deltasx, N_Vector x, N_Vector xdot, N_Vector xdot_old, N_Vector *sx, void *user_data);


#endif /* _am_linearChain_MM2_g_a_deltasx_h */
