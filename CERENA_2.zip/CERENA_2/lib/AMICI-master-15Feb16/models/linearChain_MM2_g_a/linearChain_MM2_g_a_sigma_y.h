#ifndef _am_linearChain_MM2_g_a_sigma_y_h
#define _am_linearChain_MM2_g_a_sigma_y_h

int sigma_y_linearChain_MM2_g_a(realtype t, realtype *sigma_y, void *user_data);


#endif /* _am_linearChain_MM2_g_a_sigma_y_h */
