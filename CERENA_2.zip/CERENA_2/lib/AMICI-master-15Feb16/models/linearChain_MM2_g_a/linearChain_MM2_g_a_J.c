
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int J_linearChain_MM2_g_a(long int N, realtype t, N_Vector x, N_Vector xdot, DlsMat J, void *user_data, N_Vector tmp1, N_Vector tmp2, N_Vector tmp3) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *xdot_tmp = N_VGetArrayPointer(xdot);
memset(J->data,0,sizeof(realtype)*841);
  J->data[0] = -p[1];
  J->data[1] = p[1];
  J->data[10] = p[1];
  J->data[11] = -p[1];
  J->data[12] = p[1];
  J->data[29] = p[2];
  J->data[30] = -p[2]-p[3];
  J->data[31] = p[3];
  J->data[39] = p[2];
  J->data[40] = -p[2];
  J->data[41] = p[2]+p[3];
  J->data[42] = -p[3];
  J->data[43] = p[3];
  J->data[59] = p[4];
  J->data[60] = -p[4]-p[5];
  J->data[61] = p[5];
  J->data[70] = p[4];
  J->data[71] = -p[4];
  J->data[72] = p[4]+p[5];
  J->data[73] = -p[5];
  J->data[74] = p[5];
  J->data[89] = p[6];
  J->data[90] = -p[6]-p[7];
  J->data[91] = p[7];
  J->data[101] = p[6];
  J->data[102] = -p[6];
  J->data[103] = p[6]+p[7];
  J->data[104] = -p[7];
  J->data[105] = p[7];
  J->data[119] = p[8];
  J->data[120] = -p[8]-p[9];
  J->data[121] = p[9];
  J->data[132] = p[8];
  J->data[133] = -p[8];
  J->data[134] = p[8]+p[9];
  J->data[135] = -p[9];
  J->data[136] = p[9];
  J->data[149] = p[10];
  J->data[150] = -p[10]-p[11];
  J->data[151] = p[11];
  J->data[163] = p[10];
  J->data[164] = -p[10];
  J->data[165] = p[10]+p[11];
  J->data[166] = -p[11];
  J->data[167] = p[11];
  J->data[179] = p[12];
  J->data[180] = -p[12]-p[13];
  J->data[181] = p[13];
  J->data[194] = p[12];
  J->data[195] = -p[12];
  J->data[196] = p[12]+p[13];
  J->data[197] = -p[13];
  J->data[198] = p[13];
  J->data[209] = p[14];
  J->data[210] = -p[14]-p[15];
  J->data[211] = p[15];
  J->data[225] = p[14];
  J->data[226] = -p[14];
  J->data[227] = p[14]+p[15];
  J->data[228] = -p[15];
  J->data[229] = p[15];
  J->data[239] = p[16];
  J->data[240] = -p[16]-p[17];
  J->data[241] = p[17];
  J->data[256] = p[16];
  J->data[257] = -p[16];
  J->data[258] = p[16]+p[17];
  J->data[259] = -p[17];
  J->data[260] = p[17];
  J->data[269] = p[18];
  J->data[270] = -p[18]-p[19];
  J->data[287] = p[18];
  J->data[288] = -p[18];
  J->data[289] = p[18]+p[19];
  J->data[300] = p[1]*-2.0;
  J->data[301] = p[1];
  J->data[329] = p[2]*2.0;
  J->data[330] = -p[1]-p[2]-p[3];
  J->data[331] = p[1]*2.0;
  J->data[359] = p[2];
  J->data[360] = p[2]*-2.0-p[3]*2.0;
  J->data[361] = p[3];
  J->data[389] = p[4]*2.0;
  J->data[390] = -p[2]-p[3]-p[4]-p[5];
  J->data[391] = p[3]*2.0;
  J->data[419] = p[4];
  J->data[420] = p[4]*-2.0-p[5]*2.0;
  J->data[421] = p[5];
  J->data[449] = p[6]*2.0;
  J->data[450] = -p[4]-p[5]-p[6]-p[7];
  J->data[451] = p[5]*2.0;
  J->data[479] = p[6];
  J->data[480] = p[6]*-2.0-p[7]*2.0;
  J->data[481] = p[7];
  J->data[509] = p[8]*2.0;
  J->data[510] = -p[6]-p[7]-p[8]-p[9];
  J->data[511] = p[7]*2.0;
  J->data[539] = p[8];
  J->data[540] = p[8]*-2.0-p[9]*2.0;
  J->data[541] = p[9];
  J->data[569] = p[10]*2.0;
  J->data[570] = -p[8]-p[9]-p[10]-p[11];
  J->data[571] = p[9]*2.0;
  J->data[599] = p[10];
  J->data[600] = p[10]*-2.0-p[11]*2.0;
  J->data[601] = p[11];
  J->data[629] = p[12]*2.0;
  J->data[630] = -p[10]-p[11]-p[12]-p[13];
  J->data[631] = p[11]*2.0;
  J->data[659] = p[12];
  J->data[660] = p[12]*-2.0-p[13]*2.0;
  J->data[661] = p[13];
  J->data[689] = p[14]*2.0;
  J->data[690] = -p[12]-p[13]-p[14]-p[15];
  J->data[691] = p[13]*2.0;
  J->data[719] = p[14];
  J->data[720] = p[14]*-2.0-p[15]*2.0;
  J->data[721] = p[15];
  J->data[749] = p[16]*2.0;
  J->data[750] = -p[14]-p[15]-p[16]-p[17];
  J->data[751] = p[15]*2.0;
  J->data[779] = p[16];
  J->data[780] = p[16]*-2.0-p[17]*2.0;
  J->data[781] = p[17];
  J->data[809] = p[18]*2.0;
  J->data[810] = -p[16]-p[17]-p[18]-p[19];
  J->data[811] = p[17]*2.0;
  J->data[839] = p[18];
  J->data[840] = p[18]*-2.0-p[19]*2.0;
int ix;
for(ix = 0; ix<841; ix++) {
   if(mxIsNaN(J->data[ix])) {
       J->data[ix] = 0;       if(!udata->am_nan_J) {
           mexWarnMsgIdAndTxt("AMICI:mex:fJ:NaN","AMICI replaced a NaN value in Jacobian and replaced it by 0.0. This will not be reported again for this simulation run.");           udata->am_nan_J = TRUE;
       }
   }   if(mxIsInf(J->data[ix])) {
       mexWarnMsgIdAndTxt("AMICI:mex:fJ:Inf","AMICI encountered an Inf value in Jacobian! Aborting simulation ... ");       return(-1);   }}
return(0);

}


