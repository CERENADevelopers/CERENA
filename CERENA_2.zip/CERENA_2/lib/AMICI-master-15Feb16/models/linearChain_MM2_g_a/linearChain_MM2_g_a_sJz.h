#ifndef _am_linearChain_MM2_g_a_sJz_h
#define _am_linearChain_MM2_g_a_sJz_h

int sJz_linearChain_MM2_g_a(realtype t, int ie, realtype *sJz, realtype *z, N_Vector x, realtype *dzdp, realtype *sz, realtype *mz, realtype *sd_z, realtype *dsigma_zdp, void *user_data, void *temp_data);


#endif /* _am_linearChain_MM2_g_a_sJz_h */
