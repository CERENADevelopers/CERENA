#ifndef _am_linearChain_MM2_g_a_z_h
#define _am_linearChain_MM2_g_a_z_h

int z_linearChain_MM2_g_a(realtype t, int ie, int *nroots, realtype *z, N_Vector x, void *user_data);


#endif /* _am_linearChain_MM2_g_a_z_h */
