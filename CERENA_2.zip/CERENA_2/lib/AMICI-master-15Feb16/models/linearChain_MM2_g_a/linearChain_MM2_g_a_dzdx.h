#ifndef _am_linearChain_MM2_g_a_dzdx_h
#define _am_linearChain_MM2_g_a_dzdx_h

int dzdx_linearChain_MM2_g_a(realtype t, int ie, realtype *dzdx, N_Vector x, void *user_data);


#endif /* _am_linearChain_MM2_g_a_dzdx_h */
