
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int Jv_linearChain_MM2_g_a(N_Vector v, N_Vector Jv, realtype t, N_Vector x, N_Vector xdot, void *user_data, N_Vector tmp) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *xdot_tmp = N_VGetArrayPointer(xdot);
realtype *v_tmp = N_VGetArrayPointer(v);
realtype *Jv_tmp = N_VGetArrayPointer(Jv);
memset(Jv_tmp,0,sizeof(realtype)*29);
  Jv_tmp[0] = -p[1]*v_tmp[0]+p[2]*v_tmp[1];
  Jv_tmp[1] = -v_tmp[1]*(p[2]+p[3])+p[1]*v_tmp[0]+p[4]*v_tmp[2];
  Jv_tmp[2] = -v_tmp[2]*(p[4]+p[5])+p[3]*v_tmp[1]+p[6]*v_tmp[3];
  Jv_tmp[3] = -v_tmp[3]*(p[6]+p[7])+p[5]*v_tmp[2]+p[8]*v_tmp[4];
  Jv_tmp[4] = -v_tmp[4]*(p[8]+p[9])+p[7]*v_tmp[3]+p[10]*v_tmp[5];
  Jv_tmp[5] = -v_tmp[5]*(p[10]+p[11])+p[9]*v_tmp[4]+p[12]*v_tmp[6];
  Jv_tmp[6] = -v_tmp[6]*(p[12]+p[13])+p[11]*v_tmp[5]+p[14]*v_tmp[7];
  Jv_tmp[7] = -v_tmp[7]*(p[14]+p[15])+p[13]*v_tmp[6]+p[16]*v_tmp[8];
  Jv_tmp[8] = -v_tmp[8]*(p[16]+p[17])+p[15]*v_tmp[7]+p[18]*v_tmp[9];
  Jv_tmp[9] = -v_tmp[9]*(p[18]+p[19])+p[17]*v_tmp[8];
  Jv_tmp[10] = p[1]*v_tmp[0]+p[2]*v_tmp[1]-p[1]*v_tmp[10]*2.0+p[2]*v_tmp[11]*2.0;
  Jv_tmp[11] = -p[1]*v_tmp[0]-p[2]*v_tmp[1]+p[1]*v_tmp[10]+p[2]*v_tmp[12]-v_tmp[11]*(p[1]+p[2]+p[3]);
  Jv_tmp[12] = v_tmp[1]*(p[2]+p[3])+p[1]*v_tmp[0]+p[4]*v_tmp[2]+p[1]*v_tmp[11]*2.0+p[4]*v_tmp[13]*2.0-v_tmp[12]*(p[2]*2.0+p[3]*2.0);
  Jv_tmp[13] = -p[3]*v_tmp[1]-p[4]*v_tmp[2]+p[3]*v_tmp[12]+p[4]*v_tmp[14]-v_tmp[13]*(p[2]+p[3]+p[4]+p[5]);
  Jv_tmp[14] = v_tmp[2]*(p[4]+p[5])+p[3]*v_tmp[1]+p[6]*v_tmp[3]+p[3]*v_tmp[13]*2.0+p[6]*v_tmp[15]*2.0-v_tmp[14]*(p[4]*2.0+p[5]*2.0);
  Jv_tmp[15] = -p[5]*v_tmp[2]-p[6]*v_tmp[3]+p[5]*v_tmp[14]+p[6]*v_tmp[16]-v_tmp[15]*(p[4]+p[5]+p[6]+p[7]);
  Jv_tmp[16] = v_tmp[3]*(p[6]+p[7])+p[5]*v_tmp[2]+p[8]*v_tmp[4]+p[5]*v_tmp[15]*2.0+p[8]*v_tmp[17]*2.0-v_tmp[16]*(p[6]*2.0+p[7]*2.0);
  Jv_tmp[17] = -p[7]*v_tmp[3]-p[8]*v_tmp[4]+p[7]*v_tmp[16]+p[8]*v_tmp[18]-v_tmp[17]*(p[6]+p[7]+p[8]+p[9]);
  Jv_tmp[18] = v_tmp[4]*(p[8]+p[9])+p[7]*v_tmp[3]+p[10]*v_tmp[5]+p[7]*v_tmp[17]*2.0+p[10]*v_tmp[19]*2.0-v_tmp[18]*(p[8]*2.0+p[9]*2.0);
  Jv_tmp[19] = -p[9]*v_tmp[4]-p[10]*v_tmp[5]+p[9]*v_tmp[18]+p[10]*v_tmp[20]-v_tmp[19]*(p[8]+p[9]+p[10]+p[11]);
  Jv_tmp[20] = v_tmp[5]*(p[10]+p[11])+p[9]*v_tmp[4]+p[12]*v_tmp[6]+p[9]*v_tmp[19]*2.0+p[12]*v_tmp[21]*2.0-v_tmp[20]*(p[10]*2.0+p[11]*2.0);
  Jv_tmp[21] = -p[11]*v_tmp[5]-p[12]*v_tmp[6]+p[11]*v_tmp[20]+p[12]*v_tmp[22]-v_tmp[21]*(p[10]+p[11]+p[12]+p[13]);
  Jv_tmp[22] = v_tmp[6]*(p[12]+p[13])+p[11]*v_tmp[5]+p[14]*v_tmp[7]+p[11]*v_tmp[21]*2.0+p[14]*v_tmp[23]*2.0-v_tmp[22]*(p[12]*2.0+p[13]*2.0);
  Jv_tmp[23] = -p[13]*v_tmp[6]-p[14]*v_tmp[7]+p[13]*v_tmp[22]+p[14]*v_tmp[24]-v_tmp[23]*(p[12]+p[13]+p[14]+p[15]);
  Jv_tmp[24] = v_tmp[7]*(p[14]+p[15])+p[13]*v_tmp[6]+p[16]*v_tmp[8]+p[13]*v_tmp[23]*2.0+p[16]*v_tmp[25]*2.0-v_tmp[24]*(p[14]*2.0+p[15]*2.0);
  Jv_tmp[25] = -p[15]*v_tmp[7]-p[16]*v_tmp[8]+p[15]*v_tmp[24]+p[16]*v_tmp[26]-v_tmp[25]*(p[14]+p[15]+p[16]+p[17]);
  Jv_tmp[26] = v_tmp[8]*(p[16]+p[17])+p[15]*v_tmp[7]+p[18]*v_tmp[9]+p[15]*v_tmp[25]*2.0+p[18]*v_tmp[27]*2.0-v_tmp[26]*(p[16]*2.0+p[17]*2.0);
  Jv_tmp[27] = -p[17]*v_tmp[8]-p[18]*v_tmp[9]+p[17]*v_tmp[26]+p[18]*v_tmp[28]-v_tmp[27]*(p[16]+p[17]+p[18]+p[19]);
  Jv_tmp[28] = v_tmp[9]*(p[18]+p[19])+p[17]*v_tmp[8]+p[17]*v_tmp[27]*2.0-v_tmp[28]*(p[18]*2.0+p[19]*2.0);
return(0);

}


