
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int sx0_linearChain_MM2_g_a(N_Vector *sx0, N_Vector x, N_Vector dx, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *dx_tmp = N_VGetArrayPointer(dx);
realtype *sx0_tmp;
int ip;
for(ip = 0; ip<np; ip++) {
sx0_tmp = N_VGetArrayPointer(sx0[plist[ip]]);
memset(sx0_tmp,0,sizeof(realtype)*29);
switch (plist[ip]) {
}
}
return(0);

}


