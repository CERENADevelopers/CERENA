
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int dxdotdp_linearChain_MM2_g_a(realtype t, realtype *dxdotdp, N_Vector x, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
memset(dxdotdp,0,sizeof(realtype)*29*np);
int ip;
for(ip = 0; ip<np; ip++) {
switch (plist[ip]) {
  case 0: {
  dxdotdp[(0+ip*29)] = 1.0;
  dxdotdp[(10+ip*29)] = 1.0;

  } break;

  case 1: {
  dxdotdp[(0+ip*29)] = -x_tmp[0];
  dxdotdp[(1+ip*29)] = x_tmp[0];
  dxdotdp[(10+ip*29)] = x_tmp[0]-x_tmp[10]*2.0;
  dxdotdp[(11+ip*29)] = -x_tmp[0]+x_tmp[10]-x_tmp[11];
  dxdotdp[(12+ip*29)] = x_tmp[0]+x_tmp[11]*2.0;

  } break;

  case 2: {
  dxdotdp[(0+ip*29)] = x_tmp[1];
  dxdotdp[(1+ip*29)] = -x_tmp[1];
  dxdotdp[(10+ip*29)] = x_tmp[1]+x_tmp[11]*2.0;
  dxdotdp[(11+ip*29)] = -x_tmp[1]-x_tmp[11]+x_tmp[12];
  dxdotdp[(12+ip*29)] = x_tmp[1]-x_tmp[12]*2.0;
  dxdotdp[(13+ip*29)] = -x_tmp[13];

  } break;

  case 3: {
  dxdotdp[(1+ip*29)] = -x_tmp[1];
  dxdotdp[(2+ip*29)] = x_tmp[1];
  dxdotdp[(11+ip*29)] = -x_tmp[11];
  dxdotdp[(12+ip*29)] = x_tmp[1]-x_tmp[12]*2.0;
  dxdotdp[(13+ip*29)] = -x_tmp[1]+x_tmp[12]-x_tmp[13];
  dxdotdp[(14+ip*29)] = x_tmp[1]+x_tmp[13]*2.0;

  } break;

  case 4: {
  dxdotdp[(1+ip*29)] = x_tmp[2];
  dxdotdp[(2+ip*29)] = -x_tmp[2];
  dxdotdp[(12+ip*29)] = x_tmp[2]+x_tmp[13]*2.0;
  dxdotdp[(13+ip*29)] = -x_tmp[2]-x_tmp[13]+x_tmp[14];
  dxdotdp[(14+ip*29)] = x_tmp[2]-x_tmp[14]*2.0;
  dxdotdp[(15+ip*29)] = -x_tmp[15];

  } break;

  case 5: {
  dxdotdp[(2+ip*29)] = -x_tmp[2];
  dxdotdp[(3+ip*29)] = x_tmp[2];
  dxdotdp[(13+ip*29)] = -x_tmp[13];
  dxdotdp[(14+ip*29)] = x_tmp[2]-x_tmp[14]*2.0;
  dxdotdp[(15+ip*29)] = -x_tmp[2]+x_tmp[14]-x_tmp[15];
  dxdotdp[(16+ip*29)] = x_tmp[2]+x_tmp[15]*2.0;

  } break;

  case 6: {
  dxdotdp[(2+ip*29)] = x_tmp[3];
  dxdotdp[(3+ip*29)] = -x_tmp[3];
  dxdotdp[(14+ip*29)] = x_tmp[3]+x_tmp[15]*2.0;
  dxdotdp[(15+ip*29)] = -x_tmp[3]-x_tmp[15]+x_tmp[16];
  dxdotdp[(16+ip*29)] = x_tmp[3]-x_tmp[16]*2.0;
  dxdotdp[(17+ip*29)] = -x_tmp[17];

  } break;

  case 7: {
  dxdotdp[(3+ip*29)] = -x_tmp[3];
  dxdotdp[(4+ip*29)] = x_tmp[3];
  dxdotdp[(15+ip*29)] = -x_tmp[15];
  dxdotdp[(16+ip*29)] = x_tmp[3]-x_tmp[16]*2.0;
  dxdotdp[(17+ip*29)] = -x_tmp[3]+x_tmp[16]-x_tmp[17];
  dxdotdp[(18+ip*29)] = x_tmp[3]+x_tmp[17]*2.0;

  } break;

  case 8: {
  dxdotdp[(3+ip*29)] = x_tmp[4];
  dxdotdp[(4+ip*29)] = -x_tmp[4];
  dxdotdp[(16+ip*29)] = x_tmp[4]+x_tmp[17]*2.0;
  dxdotdp[(17+ip*29)] = -x_tmp[4]-x_tmp[17]+x_tmp[18];
  dxdotdp[(18+ip*29)] = x_tmp[4]-x_tmp[18]*2.0;
  dxdotdp[(19+ip*29)] = -x_tmp[19];

  } break;

  case 9: {
  dxdotdp[(4+ip*29)] = -x_tmp[4];
  dxdotdp[(5+ip*29)] = x_tmp[4];
  dxdotdp[(17+ip*29)] = -x_tmp[17];
  dxdotdp[(18+ip*29)] = x_tmp[4]-x_tmp[18]*2.0;
  dxdotdp[(19+ip*29)] = -x_tmp[4]+x_tmp[18]-x_tmp[19];
  dxdotdp[(20+ip*29)] = x_tmp[4]+x_tmp[19]*2.0;

  } break;

  case 10: {
  dxdotdp[(4+ip*29)] = x_tmp[5];
  dxdotdp[(5+ip*29)] = -x_tmp[5];
  dxdotdp[(18+ip*29)] = x_tmp[5]+x_tmp[19]*2.0;
  dxdotdp[(19+ip*29)] = -x_tmp[5]-x_tmp[19]+x_tmp[20];
  dxdotdp[(20+ip*29)] = x_tmp[5]-x_tmp[20]*2.0;
  dxdotdp[(21+ip*29)] = -x_tmp[21];

  } break;

  case 11: {
  dxdotdp[(5+ip*29)] = -x_tmp[5];
  dxdotdp[(6+ip*29)] = x_tmp[5];
  dxdotdp[(19+ip*29)] = -x_tmp[19];
  dxdotdp[(20+ip*29)] = x_tmp[5]-x_tmp[20]*2.0;
  dxdotdp[(21+ip*29)] = -x_tmp[5]+x_tmp[20]-x_tmp[21];
  dxdotdp[(22+ip*29)] = x_tmp[5]+x_tmp[21]*2.0;

  } break;

  case 12: {
  dxdotdp[(5+ip*29)] = x_tmp[6];
  dxdotdp[(6+ip*29)] = -x_tmp[6];
  dxdotdp[(20+ip*29)] = x_tmp[6]+x_tmp[21]*2.0;
  dxdotdp[(21+ip*29)] = -x_tmp[6]-x_tmp[21]+x_tmp[22];
  dxdotdp[(22+ip*29)] = x_tmp[6]-x_tmp[22]*2.0;
  dxdotdp[(23+ip*29)] = -x_tmp[23];

  } break;

  case 13: {
  dxdotdp[(6+ip*29)] = -x_tmp[6];
  dxdotdp[(7+ip*29)] = x_tmp[6];
  dxdotdp[(21+ip*29)] = -x_tmp[21];
  dxdotdp[(22+ip*29)] = x_tmp[6]-x_tmp[22]*2.0;
  dxdotdp[(23+ip*29)] = -x_tmp[6]+x_tmp[22]-x_tmp[23];
  dxdotdp[(24+ip*29)] = x_tmp[6]+x_tmp[23]*2.0;

  } break;

  case 14: {
  dxdotdp[(6+ip*29)] = x_tmp[7];
  dxdotdp[(7+ip*29)] = -x_tmp[7];
  dxdotdp[(22+ip*29)] = x_tmp[7]+x_tmp[23]*2.0;
  dxdotdp[(23+ip*29)] = -x_tmp[7]-x_tmp[23]+x_tmp[24];
  dxdotdp[(24+ip*29)] = x_tmp[7]-x_tmp[24]*2.0;
  dxdotdp[(25+ip*29)] = -x_tmp[25];

  } break;

  case 15: {
  dxdotdp[(7+ip*29)] = -x_tmp[7];
  dxdotdp[(8+ip*29)] = x_tmp[7];
  dxdotdp[(23+ip*29)] = -x_tmp[23];
  dxdotdp[(24+ip*29)] = x_tmp[7]-x_tmp[24]*2.0;
  dxdotdp[(25+ip*29)] = -x_tmp[7]+x_tmp[24]-x_tmp[25];
  dxdotdp[(26+ip*29)] = x_tmp[7]+x_tmp[25]*2.0;

  } break;

  case 16: {
  dxdotdp[(7+ip*29)] = x_tmp[8];
  dxdotdp[(8+ip*29)] = -x_tmp[8];
  dxdotdp[(24+ip*29)] = x_tmp[8]+x_tmp[25]*2.0;
  dxdotdp[(25+ip*29)] = -x_tmp[8]-x_tmp[25]+x_tmp[26];
  dxdotdp[(26+ip*29)] = x_tmp[8]-x_tmp[26]*2.0;
  dxdotdp[(27+ip*29)] = -x_tmp[27];

  } break;

  case 17: {
  dxdotdp[(8+ip*29)] = -x_tmp[8];
  dxdotdp[(9+ip*29)] = x_tmp[8];
  dxdotdp[(25+ip*29)] = -x_tmp[25];
  dxdotdp[(26+ip*29)] = x_tmp[8]-x_tmp[26]*2.0;
  dxdotdp[(27+ip*29)] = -x_tmp[8]+x_tmp[26]-x_tmp[27];
  dxdotdp[(28+ip*29)] = x_tmp[8]+x_tmp[27]*2.0;

  } break;

  case 18: {
  dxdotdp[(8+ip*29)] = x_tmp[9];
  dxdotdp[(9+ip*29)] = -x_tmp[9];
  dxdotdp[(26+ip*29)] = x_tmp[9]+x_tmp[27]*2.0;
  dxdotdp[(27+ip*29)] = -x_tmp[9]-x_tmp[27]+x_tmp[28];
  dxdotdp[(28+ip*29)] = x_tmp[9]-x_tmp[28]*2.0;

  } break;

  case 19: {
  dxdotdp[(9+ip*29)] = -x_tmp[9];
  dxdotdp[(27+ip*29)] = -x_tmp[27];
  dxdotdp[(28+ip*29)] = x_tmp[9]-x_tmp[28]*2.0;

  } break;

}
}
int ix;
for(ip = 0; ip<np; ip++) {
   for(ix = 0; ix<29; ix++) {
       if(mxIsNaN(dxdotdp[ix+ip*29])) {
           dxdotdp[ix+ip*29] = 0;
           if(!udata->am_nan_dxdotdp) {
               mexWarnMsgIdAndTxt("AMICI:mex:fdxdotdp:NaN","AMICI replaced a NaN value in dxdotdp and replaced it by 0.0. This will not be reported again.");
               udata->am_nan_dxdotdp = TRUE;
           }
       }
       if(mxIsInf(dxdotdp[ix+ip*29])) {
           mexWarnMsgIdAndTxt("AMICI:mex:fdxdotdp:Inf","AMICI encountered an Inf value in dxdotdp, aborting.");
           return(-1);
       }
   }
}
return(0);

}


