
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int dsigma_zdp_AMICI_genExp_MCM1(realtype t, int ie, realtype *dsigma_zdp, void *user_data) {
UserData udata = (UserData) user_data;
memset(dsigma_zdp,0,sizeof(realtype)*0*np);
int ip;
for(ip = 0; ip<np; ip++) {
switch (plist[ip]) {
}
}
return(0);

}


