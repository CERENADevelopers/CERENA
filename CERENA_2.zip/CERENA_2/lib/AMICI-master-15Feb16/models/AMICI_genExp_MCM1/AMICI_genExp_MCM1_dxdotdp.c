
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int dxdotdp_AMICI_genExp_MCM1(realtype t, realtype *dxdotdp, N_Vector x, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
memset(dxdotdp,0,sizeof(realtype)*6*np);
int ip;
for(ip = 0; ip<np; ip++) {
switch (plist[ip]) {
  case 0: {
  dxdotdp[(0+ip*6)] = -x_tmp[0];
  dxdotdp[(1+ip*6)] = x_tmp[0];
  dxdotdp[(4+ip*6)] = (k[0]*x_tmp[0]*x_tmp[2]-k[0]*x_tmp[0]*x_tmp[4])/k[0];
  dxdotdp[(5+ip*6)] = x_tmp[0]*x_tmp[3]-x_tmp[0]*x_tmp[5];

  } break;

  case 1: {
  dxdotdp[(0+ip*6)] = x_tmp[1];
  dxdotdp[(1+ip*6)] = -x_tmp[1];
  dxdotdp[(2+ip*6)] = -x_tmp[1]*x_tmp[2]+x_tmp[1]*x_tmp[4];
  dxdotdp[(3+ip*6)] = -x_tmp[1]*x_tmp[3]+x_tmp[1]*x_tmp[5];

  } break;

  case 2: {
  dxdotdp[(4+ip*6)] = x_tmp[1]/k[0];

  } break;

  case 3: {
  dxdotdp[(2+ip*6)] = -x_tmp[0]*x_tmp[2];
  dxdotdp[(4+ip*6)] = -x_tmp[1]*x_tmp[4];

  } break;

  case 4: {
  dxdotdp[(3+ip*6)] = t*x_tmp[0]*x_tmp[2];
  dxdotdp[(5+ip*6)] = t*x_tmp[1]*x_tmp[4];

  } break;

  case 5: {
  dxdotdp[(3+ip*6)] = -x_tmp[0]*x_tmp[3];
  dxdotdp[(5+ip*6)] = -x_tmp[1]*x_tmp[5];

  } break;

  case 6: {
  dxdotdp[(0+ip*6)] = -k[0]*x_tmp[0]*x_tmp[3];
  dxdotdp[(1+ip*6)] = k[0]*x_tmp[0]*x_tmp[3];
  dxdotdp[(4+ip*6)] = ((k[0]*k[0])*x_tmp[0]*x_tmp[2]*x_tmp[3]-(k[0]*k[0])*x_tmp[0]*x_tmp[3]*x_tmp[4])/k[0];
  dxdotdp[(5+ip*6)] = k[0]*x_tmp[0]*(x_tmp[3]*x_tmp[3])-k[0]*x_tmp[0]*x_tmp[3]*x_tmp[5];

  } break;

}
}
int ix;
for(ip = 0; ip<np; ip++) {
   for(ix = 0; ix<6; ix++) {
       if(mxIsNaN(dxdotdp[ix+ip*6])) {
           dxdotdp[ix+ip*6] = 0;
           if(!udata->am_nan_dxdotdp) {
               mexWarnMsgIdAndTxt("AMICI:mex:fdxdotdp:NaN","AMICI replaced a NaN value in dxdotdp and replaced it by 0.0. This will not be reported again.");
               udata->am_nan_dxdotdp = TRUE;
           }
       }
       if(mxIsInf(dxdotdp[ix+ip*6])) {
           mexWarnMsgIdAndTxt("AMICI:mex:fdxdotdp:Inf","AMICI encountered an Inf value in dxdotdp, aborting.");
           return(-1);
       }
   }
}
return(0);

}


