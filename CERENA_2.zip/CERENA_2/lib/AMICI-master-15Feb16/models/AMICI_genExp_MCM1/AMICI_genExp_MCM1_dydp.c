
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int dydp_AMICI_genExp_MCM1(realtype t, int it, realtype *dydp, N_Vector x, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
int ip;
for(ip = 0; ip<np; ip++) {
switch (plist[ip]) {
  case 7: {
  dydp[ip*5 + 4] = x_tmp[0]*x_tmp[3]+x_tmp[1]*x_tmp[5];

  } break;

  case 8: {
  dydp[ip*5 + 4] = 1.0;

  } break;

}
}
return(0);

}


