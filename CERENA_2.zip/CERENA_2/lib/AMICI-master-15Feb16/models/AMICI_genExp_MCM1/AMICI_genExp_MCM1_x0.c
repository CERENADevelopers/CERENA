
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int x0_AMICI_genExp_MCM1(N_Vector x0, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x0_tmp = N_VGetArrayPointer(x0);
memset(x0_tmp,0,sizeof(realtype)*6);
  x0_tmp[0] = 9.999999999E-1;
  x0_tmp[1] = 1.0E-10;
  x0_tmp[2] = (k[3]*k[17]-p[9]*(k[3]-1.0))/k[0];
  x0_tmp[3] = (k[4]*k[18])/k[0];
  x0_tmp[4] = (k[3]*k[17]-p[9]*(k[3]-1.0))/k[0];
  x0_tmp[5] = (k[4]*k[18])/k[0];
return(0);

}


