#ifndef _am_AMICI_genExp_MCM1_deltax_h
#define _am_AMICI_genExp_MCM1_deltax_h

int deltax_AMICI_genExp_MCM1(realtype t, int ie, realtype *deltax, N_Vector x, N_Vector xdot, N_Vector xdot_old, void *user_data);


#endif /* _am_AMICI_genExp_MCM1_deltax_h */
