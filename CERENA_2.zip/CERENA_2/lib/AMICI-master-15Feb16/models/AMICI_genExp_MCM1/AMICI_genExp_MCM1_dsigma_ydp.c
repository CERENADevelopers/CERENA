
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int dsigma_ydp_AMICI_genExp_MCM1(realtype t, realtype *dsigma_ydp, void *user_data) {
UserData udata = (UserData) user_data;
memset(dsigma_ydp,0,sizeof(realtype)*5*np);
int ip;
for(ip = 0; ip<np; ip++) {
switch (plist[ip]) {
}
}
return(0);

}


