
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int sdx0_AMICI_genExp_MCM1(N_Vector *sdx0, N_Vector x, N_Vector dx, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *dx_tmp = N_VGetArrayPointer(dx);
realtype *sdx0_tmp;
memset(sdx0_tmp,0,sizeof(realtype)*6);
int ip;
for(ip = 0; ip<np; ip++) {
sdx0_tmp = N_VGetArrayPointer(sdx0[plist[ip]]);
memset(sdx0_tmp,0,sizeof(realtype)*6);
switch (plist[ip]) {
  case 0: {
  sdx0_tmp[0] = -9.999999999E-1;
  sdx0_tmp[1] = 9.999999999E-1;

  } break;

  case 1: {
  sdx0_tmp[0] = 1.0E-10;
  sdx0_tmp[1] = -1.0E-10;

  } break;

  case 2: {
  sdx0_tmp[4] = 1.0/k[0];

  } break;

  case 3: {
  sdx0_tmp[2] = -(k[3]*k[17]-p[9]*(k[3]-1.0))/k[0];
  sdx0_tmp[4] = -(k[3]*k[17]-p[9]*(k[3]-1.0))/k[0];

  } break;

  case 4: {
  sdx0_tmp[3] = (t*(k[3]*k[17]-p[9]*(k[3]-1.0)))/k[0];
  sdx0_tmp[5] = (t*(k[3]*k[17]-p[9]*(k[3]-1.0)))/k[0];

  } break;

  case 5: {
  sdx0_tmp[3] = -(k[4]*k[18])/k[0];
  sdx0_tmp[5] = -(k[4]*k[18])/k[0];

  } break;

  case 6: {
  sdx0_tmp[0] = k[4]*k[18]*(-9.999999999E-1);
  sdx0_tmp[1] = k[4]*k[18]*9.999999999E-1;

  } break;

  case 9: {
  sdx0_tmp[2] = (p[3]*(k[3]-1.0))/k[0];
  sdx0_tmp[3] = -(p[4]*t*(k[3]-1.0))/k[0];
  sdx0_tmp[4] = (p[3]*(k[3]-1.0))/k[0];
  sdx0_tmp[5] = -(p[4]*t*(k[3]-1.0))/k[0];

  } break;

}
}
return(0);

}


