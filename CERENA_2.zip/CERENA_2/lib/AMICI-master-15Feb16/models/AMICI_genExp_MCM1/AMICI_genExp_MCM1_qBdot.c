
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>
#include "AMICI_genExp_MCM1_dxdotdp.h"

int qBdot_AMICI_genExp_MCM1(realtype t, N_Vector x, N_Vector dx, N_Vector xB, N_Vector dxB, N_Vector qBdot, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *dx_tmp = N_VGetArrayPointer(dx);
realtype *xB_tmp = N_VGetArrayPointer(xB);
realtype *dxB_tmp = N_VGetArrayPointer(dxB);
realtype *qBdot_tmp = N_VGetArrayPointer(qBdot);
memset(qBdot_tmp,0,sizeof(realtype)*np);
int status;
int ip;
status = dxdotdp_AMICI_genExp_MCM1(t,tmp_dxdotdp,x,user_data);
for(ip = 0; ip<np; ip++) {
  qBdot_tmp[ip] = -tmp_dxdotdp[0 + ip*6]*xB_tmp[0]-tmp_dxdotdp[1 + ip*6]*xB_tmp[1]-tmp_dxdotdp[2 + ip*6]*xB_tmp[2]-tmp_dxdotdp[3 + ip*6]*xB_tmp[3]-tmp_dxdotdp[4 + ip*6]*xB_tmp[4]-tmp_dxdotdp[5 + ip*6]*xB_tmp[5];
}
for(ip = 0; ip<np; ip++) {
   if(mxIsNaN(qBdot_tmp[ip])) {
       qBdot_tmp[ip] = 0;       if(!udata->am_nan_qBdot) {
           mexWarnMsgIdAndTxt("AMICI:mex:fqBdot:NaN","AMICI replaced a NaN value in xBdot and replaced it by 0.0. This will not be reported again for this simulation run.");           udata->am_nan_qBdot = TRUE;
       }
   }   if(mxIsInf(qBdot_tmp[ip])) {
       mexWarnMsgIdAndTxt("AMICI:mex:fqBdot:Inf","AMICI encountered an Inf value in xBdot! Aborting simulation ... ");       return(-1);   }}
return(status);

}


