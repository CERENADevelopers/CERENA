#ifndef _am_AMICI_genExp_MCM1_JSparse_h
#define _am_AMICI_genExp_MCM1_JSparse_h

int JSparse_AMICI_genExp_MCM1(realtype t, realtype cj, N_Vector x, N_Vector dx, N_Vector xdot, SlsMat J, void *user_data, N_Vector tmp1, N_Vector tmp2, N_Vector tmp3);


#endif /* _am_AMICI_genExp_MCM1_JSparse_h */
