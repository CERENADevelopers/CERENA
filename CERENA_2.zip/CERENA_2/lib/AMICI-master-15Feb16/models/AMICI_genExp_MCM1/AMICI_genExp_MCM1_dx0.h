#ifndef _am_AMICI_genExp_MCM1_dx0_h
#define _am_AMICI_genExp_MCM1_dx0_h

int dx0_AMICI_genExp_MCM1(N_Vector x0, N_Vector dx0, void *user_data);


#endif /* _am_AMICI_genExp_MCM1_dx0_h */
