#ifndef _am_AMICI_genExp_MCM1_sxdot_h
#define _am_AMICI_genExp_MCM1_sxdot_h

int sxdot_AMICI_genExp_MCM1(int Ns, realtype t, N_Vector x, N_Vector dx, N_Vector xdot, N_Vector *sx, N_Vector *sdx, N_Vector *sxdot, void *user_data, N_Vector tmp1, N_Vector tmp2, N_Vector tmp3);


#endif /* _am_AMICI_genExp_MCM1_sxdot_h */
