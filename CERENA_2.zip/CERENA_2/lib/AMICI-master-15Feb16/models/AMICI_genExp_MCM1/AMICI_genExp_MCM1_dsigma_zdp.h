#ifndef _am_AMICI_genExp_MCM1_dsigma_zdp_h
#define _am_AMICI_genExp_MCM1_dsigma_zdp_h

int dsigma_zdp_AMICI_genExp_MCM1(realtype t, int ie, realtype *dsigma_zdp, void *user_data);


#endif /* _am_AMICI_genExp_MCM1_dsigma_zdp_h */
