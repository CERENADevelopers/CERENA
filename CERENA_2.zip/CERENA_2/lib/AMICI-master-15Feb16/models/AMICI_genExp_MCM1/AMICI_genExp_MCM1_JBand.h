#ifndef _am_AMICI_genExp_MCM1_JBand_h
#define _am_AMICI_genExp_MCM1_JBand_h

int JBand_AMICI_genExp_MCM1(long int N, long int mupper, long int mlower, realtype t, realtype cj, N_Vector x, N_Vector dx, N_Vector xdot, DlsMat J, void *user_data, N_Vector tmp1, N_Vector tmp2, N_Vector tmp3);


#endif /* _am_AMICI_genExp_MCM1_JBand_h */
