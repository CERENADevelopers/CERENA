
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int xBdot_AMICI_genExp_MCM1(realtype t, N_Vector x, N_Vector dx, N_Vector xB, N_Vector dxB, N_Vector xBdot, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
realtype *dx_tmp = N_VGetArrayPointer(dx);
realtype *xB_tmp = N_VGetArrayPointer(xB);
realtype *dxB_tmp = N_VGetArrayPointer(dxB);
realtype *xBdot_tmp = N_VGetArrayPointer(xBdot);
memset(xBdot_tmp,0,sizeof(realtype)*6);
  xBdot_tmp[0] = dxB_tmp[0]-xB_tmp[5]*(p[0]*x_tmp[3]-p[0]*x_tmp[5]+k[0]*p[6]*(x_tmp[3]*x_tmp[3])-k[0]*p[6]*x_tmp[3]*x_tmp[5])+xB_tmp[0]*(p[0]+k[0]*p[6]*x_tmp[3])-xB_tmp[1]*(p[0]+k[0]*p[6]*x_tmp[3])+xB_tmp[3]*(dx_tmp[3]+p[5]*x_tmp[3]-p[4]*t*x_tmp[2])+xB_tmp[2]*(dx_tmp[2]+p[3]*x_tmp[2])-(xB_tmp[4]*(k[0]*p[0]*x_tmp[2]-k[0]*p[0]*x_tmp[4]+(k[0]*k[0])*p[6]*x_tmp[2]*x_tmp[3]-(k[0]*k[0])*p[6]*x_tmp[3]*x_tmp[4]))/k[0];
  xBdot_tmp[1] = dxB_tmp[1]-p[1]*xB_tmp[0]+p[1]*xB_tmp[1]+xB_tmp[4]*(dx_tmp[4]-(p[2]-k[0]*p[3]*x_tmp[4])/k[0])+xB_tmp[5]*(dx_tmp[5]+p[5]*x_tmp[5]-p[4]*t*x_tmp[4])+xB_tmp[2]*(p[1]*x_tmp[2]-p[1]*x_tmp[4])+xB_tmp[3]*(p[1]*x_tmp[3]-p[1]*x_tmp[5]);
  xBdot_tmp[2] = dxB_tmp[2]*x_tmp[0]+xB_tmp[2]*(p[1]*x_tmp[1]+p[3]*x_tmp[0])-(xB_tmp[4]*(k[0]*p[0]*x_tmp[0]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]))/k[0]-p[4]*t*xB_tmp[3]*x_tmp[0];
  xBdot_tmp[3] = dxB_tmp[3]*x_tmp[0]+xB_tmp[3]*(p[1]*x_tmp[1]+p[5]*x_tmp[0])-xB_tmp[5]*(p[0]*x_tmp[0]+k[0]*p[6]*x_tmp[0]*x_tmp[3]*2.0-k[0]*p[6]*x_tmp[0]*x_tmp[5])-(xB_tmp[4]*((k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[2]-(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[4]))/k[0]+k[0]*p[6]*xB_tmp[0]*x_tmp[0]-k[0]*p[6]*xB_tmp[1]*x_tmp[0];
  xBdot_tmp[4] = dxB_tmp[4]*x_tmp[1]-p[1]*xB_tmp[2]*x_tmp[1]+(xB_tmp[4]*(k[0]*p[0]*x_tmp[0]+k[0]*p[3]*x_tmp[1]+(k[0]*k[0])*p[6]*x_tmp[0]*x_tmp[3]))/k[0]-p[4]*t*xB_tmp[5]*x_tmp[1];
  xBdot_tmp[5] = dxB_tmp[5]*x_tmp[1]+xB_tmp[5]*(p[0]*x_tmp[0]+p[5]*x_tmp[1]+k[0]*p[6]*x_tmp[0]*x_tmp[3])-p[1]*xB_tmp[3]*x_tmp[1];
int ix;
for(ix = 0; ix<6; ix++) {
   if(mxIsNaN(xBdot_tmp[ix])) {
       xBdot_tmp[ix] = 0;       if(!udata->am_nan_xBdot) {
           mexWarnMsgIdAndTxt("AMICI:mex:fxBdot:NaN","AMICI replaced a NaN value in xBdot and replaced it by 0.0. This will not be reported again for this simulation run.");           udata->am_nan_xBdot = TRUE;
       }
   }   if(mxIsInf(xBdot_tmp[ix])) {
       mexWarnMsgIdAndTxt("AMICI:mex:fxBdot:Inf","AMICI encountered an Inf value in xBdot! Aborting simulation ... ");       return(-1);   }}
return(0);

}


