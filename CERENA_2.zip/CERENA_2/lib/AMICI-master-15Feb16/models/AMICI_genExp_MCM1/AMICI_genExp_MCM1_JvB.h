#ifndef _am_AMICI_genExp_MCM1_JvB_h
#define _am_AMICI_genExp_MCM1_JvB_h

int JvB_AMICI_genExp_MCM1(realtype t, N_Vector x, N_Vector dx, N_Vector xB, N_Vector dxB, N_Vector xBdot, N_Vector vB, N_Vector JvB, realtype cj, void *user_data, N_Vector tmpB1, N_Vector tmpB2);


#endif /* _am_AMICI_genExp_MCM1_JvB_h */
