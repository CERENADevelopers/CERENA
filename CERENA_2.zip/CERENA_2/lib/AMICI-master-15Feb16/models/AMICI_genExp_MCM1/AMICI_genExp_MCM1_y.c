
#include <include/symbolic_functions.h>
#include <string.h>
#include <mex.h>
#include <include/udata.h>

int y_AMICI_genExp_MCM1(realtype t, int it, realtype *y, N_Vector x, void *user_data) {
UserData udata = (UserData) user_data;
realtype *x_tmp = N_VGetArrayPointer(x);
  y[it+nt*0] = x_tmp[0];
  y[it+nt*1] = x_tmp[1];
  y[it+nt*2] = x_tmp[0]*x_tmp[2]+x_tmp[1]*x_tmp[4];
  y[it+nt*3] = x_tmp[0]*x_tmp[3]+x_tmp[1]*x_tmp[5];
  y[it+nt*4] = p[8]+p[7]*(x_tmp[0]*x_tmp[3]+x_tmp[1]*x_tmp[5]);
return(0);

}


