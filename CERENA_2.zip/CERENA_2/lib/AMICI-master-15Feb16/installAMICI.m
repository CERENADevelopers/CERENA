amipath = fileparts(mfilename('fullpath'));
addpath(amipath)
addpath(fullfile(amipath,'auxiliary'))
addpath(fullfile(amipath,'auxiliary','datahash'))
addpath(fullfile(amipath,'symbolic'))