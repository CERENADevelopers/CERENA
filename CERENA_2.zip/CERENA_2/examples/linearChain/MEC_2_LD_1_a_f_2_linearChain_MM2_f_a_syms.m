% function [model] = MEC_2_LD_1_a_f_2_linearChain_MM2_f_a_syms(f0_user)
function [model] = MEC_2_LD_1_a_f_2_linearChain_MM2_f_a_syms(varargin)

% CVODES OPTIONS

model.atol = 1e-8;
model.rtol = 1e-8;
model.maxsteps = 1e4;

% STATES

syms mu_1 mu_2 mu_3 mu_4 mu_5 mu_6 mu_7 mu_8 mu_9 mu_10 C_1_1 C_1_2 C_1_3 C_1_4 C_1_5 C_1_6 C_1_7 C_1_8 C_1_9 C_1_10 C_2_2 C_2_3 C_2_4 C_2_5 C_2_6 C_2_7 C_2_8 C_2_9 C_2_10 C_3_3 C_3_4 C_3_5 C_3_6 C_3_7 C_3_8 C_3_9 C_3_10 C_4_4 C_4_5 C_4_6 C_4_7 C_4_8 C_4_9 C_4_10 C_5_5 C_5_6 C_5_7 C_5_8 C_5_9 C_5_10 C_6_6 C_6_7 C_6_8 C_6_9 C_6_10 C_7_7 C_7_8 C_7_9 C_7_10 C_8_8 C_8_9 C_8_10 C_9_9 C_9_10 C_10_10

x = [
mu_1, mu_2, mu_3, mu_4, mu_5, mu_6, mu_7, mu_8, mu_9, mu_10, C_1_1, C_1_2, C_1_3, C_1_4, C_1_5, C_1_6, C_1_7, C_1_8, C_1_9, C_1_10, C_2_2, C_2_3, C_2_4, C_2_5, C_2_6, C_2_7, C_2_8, C_2_9, C_2_10, C_3_3, C_3_4, C_3_5, C_3_6, C_3_7, C_3_8, C_3_9, C_3_10, C_4_4, C_4_5, C_4_6, C_4_7, C_4_8, C_4_9, C_4_10, C_5_5, C_5_6, C_5_7, C_5_8, C_5_9, C_5_10, C_6_6, C_6_7, C_6_8, C_6_9, C_6_10, C_7_7, C_7_8, C_7_9, C_7_10, C_8_8, C_8_9, C_8_10, C_9_9, C_9_10, C_10_10 ...
];

% PARAMETERS

syms k0 k1 k1_1 k2 k2_1 k3 k3_1 k4 k4_1 k5 k5_1 k6 k6_1 k7 k7_1 k8 k8_1 k9 k9_1 k10 

% KAPPA (constant parameters)

syms indmu1 indmu2 indmu3 indmu4 indmu5 indmu6 indmu7 indmu8 indmu9 indmu10 indC1 indC2 indC3 indC4 indC5 indC6 indC7 indC8 indC9 indC10 indC11 indC12 indC13 indC14 indC15 indC16 indC17 indC18 indC19 indC20 indC21 indC22 indC23 indC24 indC25 indC26 indC27 indC28 indC29 indC30 indC31 indC32 indC33 indC34 indC35 indC36 indC37 indC38 indC39 indC40 indC41 indC42 indC43 indC44 indC45 indC46 indC47 indC48 indC49 indC50 indC51 indC52 indC53 indC54 indC55 kmu01 kmu02 kmu03 kmu04 kmu05 kmu06 kmu07 kmu08 kmu09 kmu010 kC01 kC02 kC03 kC04 kC05 kC06 kC07 kC08 kC09 kC010 kC011 kC012 kC013 kC014 kC015 kC016 kC017 kC018 kC019 kC020 kC021 kC022 kC023 kC024 kC025 kC026 kC027 kC028 kC029 kC030 kC031 kC032 kC033 kC034 kC035 kC036 kC037 kC038 kC039 kC040 kC041 kC042 kC043 kC044 kC045 kC046 kC047 kC048 kC049 kC050 kC051 kC052 kC053 kC054 kC055 

syms t

p = [k0,k1,k1_1,k2,k2_1,k3,k3_1,k4,k4_1,k5,k5_1,k6,k6_1,k7,k7_1,k8,k8_1,k9,k9_1,k10];

k = [indmu1,indmu2,indmu3,indmu4,indmu5,indmu6,indmu7,indmu8,indmu9,indmu10,indC1,indC2,indC3,indC4,indC5,indC6,indC7,indC8,indC9,indC10,indC11,indC12,indC13,indC14,indC15,indC16,indC17,indC18,indC19,indC20,indC21,indC22,indC23,indC24,indC25,indC26,indC27,indC28,indC29,indC30,indC31,indC32,indC33,indC34,indC35,indC36,indC37,indC38,indC39,indC40,indC41,indC42,indC43,indC44,indC45,indC46,indC47,indC48,indC49,indC50,indC51,indC52,indC53,indC54,indC55,kmu01,kmu02,kmu03,kmu04,kmu05,kmu06,kmu07,kmu08,kmu09,kmu010,kC01,kC02,kC03,kC04,kC05,kC06,kC07,kC08,kC09,kC010,kC011,kC012,kC013,kC014,kC015,kC016,kC017,kC018,kC019,kC020,kC021,kC022,kC023,kC024,kC025,kC026,kC027,kC028,kC029,kC030,kC031,kC032,kC033,kC034,kC035,kC036,kC037,kC038,kC039,kC040,kC041,kC042,kC043,kC044,kC045,kC046,kC047,kC048,kC049,kC050,kC051,kC052,kC053,kC054,kC055];

if nargin > 0
   f0_user = varargin{1};
   if ~isnumeric(f0_user)
      p_user = setdiff(symvar(f0_user),p);
      % ADDITIONAL PARAMETERS IN INITIAL CONDITIONS
      p = [p,p_user];
   end
	fmu01 = f0_user(1); 
	fmu02 = f0_user(2); 
	fmu03 = f0_user(3); 
	fmu04 = f0_user(4); 
	fmu05 = f0_user(5); 
	fmu06 = f0_user(6); 
	fmu07 = f0_user(7); 
	fmu08 = f0_user(8); 
	fmu09 = f0_user(9); 
	fmu010 = f0_user(10); 
	fC01 = f0_user(11); 
	fC02 = f0_user(12); 
	fC03 = f0_user(13); 
	fC04 = f0_user(14); 
	fC05 = f0_user(15); 
	fC06 = f0_user(16); 
	fC07 = f0_user(17); 
	fC08 = f0_user(18); 
	fC09 = f0_user(19); 
	fC010 = f0_user(20); 
	fC011 = f0_user(21); 
	fC012 = f0_user(22); 
	fC013 = f0_user(23); 
	fC014 = f0_user(24); 
	fC015 = f0_user(25); 
	fC016 = f0_user(26); 
	fC017 = f0_user(27); 
	fC018 = f0_user(28); 
	fC019 = f0_user(29); 
	fC020 = f0_user(30); 
	fC021 = f0_user(31); 
	fC022 = f0_user(32); 
	fC023 = f0_user(33); 
	fC024 = f0_user(34); 
	fC025 = f0_user(35); 
	fC026 = f0_user(36); 
	fC027 = f0_user(37); 
	fC028 = f0_user(38); 
	fC029 = f0_user(39); 
	fC030 = f0_user(40); 
	fC031 = f0_user(41); 
	fC032 = f0_user(42); 
	fC033 = f0_user(43); 
	fC034 = f0_user(44); 
	fC035 = f0_user(45); 
	fC036 = f0_user(46); 
	fC037 = f0_user(47); 
	fC038 = f0_user(48); 
	fC039 = f0_user(49); 
	fC040 = f0_user(50); 
	fC041 = f0_user(51); 
	fC042 = f0_user(52); 
	fC043 = f0_user(53); 
	fC044 = f0_user(54); 
	fC045 = f0_user(55); 
	fC046 = f0_user(56); 
	fC047 = f0_user(57); 
	fC048 = f0_user(58); 
	fC049 = f0_user(59); 
	fC050 = f0_user(60); 
	fC051 = f0_user(61); 
	fC052 = f0_user(62); 
	fC053 = f0_user(63); 
	fC054 = f0_user(64); 
	fC055 = f0_user(65); 
else
	fmu01 = 10; 
	fmu02 = 0; 
	fmu03 = 0; 
	fmu04 = 0; 
	fmu05 = 0; 
	fmu06 = 0; 
	fmu07 = 0; 
	fmu08 = 0; 
	fmu09 = 0; 
	fmu010 = 0; 
	fC01 = 0; 
	fC02 = 0; 
	fC03 = 0; 
	fC04 = 0; 
	fC05 = 0; 
	fC06 = 0; 
	fC07 = 0; 
	fC08 = 0; 
	fC09 = 0; 
	fC010 = 0; 
	fC011 = 0; 
	fC012 = 0; 
	fC013 = 0; 
	fC014 = 0; 
	fC015 = 0; 
	fC016 = 0; 
	fC017 = 0; 
	fC018 = 0; 
	fC019 = 0; 
	fC020 = 0; 
	fC021 = 0; 
	fC022 = 0; 
	fC023 = 0; 
	fC024 = 0; 
	fC025 = 0; 
	fC026 = 0; 
	fC027 = 0; 
	fC028 = 0; 
	fC029 = 0; 
	fC030 = 0; 
	fC031 = 0; 
	fC032 = 0; 
	fC033 = 0; 
	fC034 = 0; 
	fC035 = 0; 
	fC036 = 0; 
	fC037 = 0; 
	fC038 = 0; 
	fC039 = 0; 
	fC040 = 0; 
	fC041 = 0; 
	fC042 = 0; 
	fC043 = 0; 
	fC044 = 0; 
	fC045 = 0; 
	fC046 = 0; 
	fC047 = 0; 
	fC048 = 0; 
	fC049 = 0; 
	fC050 = 0; 
	fC051 = 0; 
	fC052 = 0; 
	fC053 = 0; 
	fC054 = 0; 
	fC055 = 0; 
end
% INPUT 

u = sym.empty(0,0);

% SYSTEM EQUATIONS

xdot = sym(zeros(size(x)));

xdot(1) = k0 - k1*mu_1 + k1_1*mu_2;
xdot(2) = k1*mu_1 - k2*mu_2 - k1_1*mu_2 + k2_1*mu_3;
xdot(3) = k2*mu_2 - k3*mu_3 - k2_1*mu_3 + k3_1*mu_4;
xdot(4) = k3*mu_3 - k4*mu_4 - k3_1*mu_4 + k4_1*mu_5;
xdot(5) = k4*mu_4 - k5*mu_5 - k4_1*mu_5 + k5_1*mu_6;
xdot(6) = k5*mu_5 - k6*mu_6 - k5_1*mu_6 + k6_1*mu_7;
xdot(7) = k6*mu_6 - k7*mu_7 - k6_1*mu_7 + k7_1*mu_8;
xdot(8) = k7*mu_7 - k8*mu_8 - k7_1*mu_8 + k8_1*mu_9;
xdot(9) = k8*mu_8 - k9*mu_9 - k8_1*mu_9 + k9_1*mu_10;
xdot(10) = k9*mu_9 - k10*mu_10 - k9_1*mu_10;
xdot(11) = k0 - 2*C_1_1*k1 + 2*C_1_2*k1_1 + k1*mu_1 + k1_1*mu_2;
xdot(12) = C_1_1*k1 - C_1_2*k1 - C_1_2*k2 - C_1_2*k1_1 + C_2_2*k1_1 + C_1_3*k2_1 - k1*mu_1 - k1_1*mu_2;
xdot(13) = C_1_2*k2 - C_1_3*k1 - C_1_3*k3 - C_1_3*k2_1 + C_2_3*k1_1 + C_1_4*k3_1;
xdot(14) = C_1_3*k3 - C_1_4*k1 - C_1_4*k4 + C_2_4*k1_1 - C_1_4*k3_1 + C_1_5*k4_1;
xdot(15) = C_1_4*k4 - C_1_5*k1 - C_1_5*k5 + C_2_5*k1_1 - C_1_5*k4_1 + C_1_6*k5_1;
xdot(16) = C_1_5*k5 - C_1_6*k1 - C_1_6*k6 + C_2_6*k1_1 - C_1_6*k5_1 + C_1_7*k6_1;
xdot(17) = C_1_6*k6 - C_1_7*k1 - C_1_7*k7 + C_2_7*k1_1 - C_1_7*k6_1 + C_1_8*k7_1;
xdot(18) = C_1_7*k7 - C_1_8*k1 - C_1_8*k8 + C_2_8*k1_1 - C_1_8*k7_1 + C_1_9*k8_1;
xdot(19) = C_1_8*k8 - C_1_9*k1 - C_1_9*k9 + C_2_9*k1_1 - C_1_9*k8_1 + C_1_10*k9_1;
xdot(20) = C_1_9*k9 - C_1_10*k1 - C_1_10*k10 - C_1_10*k9_1 + C_2_10*k1_1;
xdot(21) = 2*C_1_2*k1 - 2*C_2_2*k2 - 2*C_2_2*k1_1 + 2*C_2_3*k2_1 + k1*mu_1 + k2*mu_2 + k1_1*mu_2 + k2_1*mu_3;
xdot(22) = C_1_3*k1 + C_2_2*k2 - C_2_3*k2 - C_2_3*k3 - C_2_3*k1_1 - C_2_3*k2_1 + C_3_3*k2_1 + C_2_4*k3_1 - k2*mu_2 - k2_1*mu_3;
xdot(23) = C_1_4*k1 + C_2_3*k3 - C_2_4*k2 - C_2_4*k4 - C_2_4*k1_1 - C_2_4*k3_1 + C_3_4*k2_1 + C_2_5*k4_1;
xdot(24) = C_1_5*k1 - C_2_5*k2 + C_2_4*k4 - C_2_5*k5 - C_2_5*k1_1 + C_3_5*k2_1 - C_2_5*k4_1 + C_2_6*k5_1;
xdot(25) = C_1_6*k1 - C_2_6*k2 + C_2_5*k5 - C_2_6*k6 - C_2_6*k1_1 + C_3_6*k2_1 - C_2_6*k5_1 + C_2_7*k6_1;
xdot(26) = C_1_7*k1 - C_2_7*k2 + C_2_6*k6 - C_2_7*k7 - C_2_7*k1_1 + C_3_7*k2_1 - C_2_7*k6_1 + C_2_8*k7_1;
xdot(27) = C_1_8*k1 - C_2_8*k2 + C_2_7*k7 - C_2_8*k8 - C_2_8*k1_1 + C_3_8*k2_1 - C_2_8*k7_1 + C_2_9*k8_1;
xdot(28) = C_1_9*k1 - C_2_9*k2 + C_2_8*k8 - C_2_9*k9 - C_2_9*k1_1 + C_3_9*k2_1 - C_2_9*k8_1 + C_2_10*k9_1;
xdot(29) = C_2_9*k9 + C_1_10*k1 - C_2_10*k2 - C_2_10*k10 - C_2_10*k1_1 - C_2_10*k9_1 + C_3_10*k2_1;
xdot(30) = 2*C_2_3*k2 - 2*C_3_3*k3 - 2*C_3_3*k2_1 + 2*C_3_4*k3_1 + k2*mu_2 + k3*mu_3 + k2_1*mu_3 + k3_1*mu_4;
xdot(31) = C_2_4*k2 + C_3_3*k3 - C_3_4*k3 - C_3_4*k4 - C_3_4*k2_1 - C_3_4*k3_1 + C_4_4*k3_1 + C_3_5*k4_1 - k3*mu_3 - k3_1*mu_4;
xdot(32) = C_2_5*k2 + C_3_4*k4 - C_3_5*k3 - C_3_5*k5 - C_3_5*k2_1 - C_3_5*k4_1 + C_4_5*k3_1 + C_3_6*k5_1;
xdot(33) = C_2_6*k2 - C_3_6*k3 + C_3_5*k5 - C_3_6*k6 - C_3_6*k2_1 + C_4_6*k3_1 - C_3_6*k5_1 + C_3_7*k6_1;
xdot(34) = C_2_7*k2 - C_3_7*k3 + C_3_6*k6 - C_3_7*k7 - C_3_7*k2_1 + C_4_7*k3_1 - C_3_7*k6_1 + C_3_8*k7_1;
xdot(35) = C_2_8*k2 - C_3_8*k3 + C_3_7*k7 - C_3_8*k8 - C_3_8*k2_1 + C_4_8*k3_1 - C_3_8*k7_1 + C_3_9*k8_1;
xdot(36) = C_2_9*k2 - C_3_9*k3 + C_3_8*k8 - C_3_9*k9 - C_3_9*k2_1 + C_4_9*k3_1 - C_3_9*k8_1 + C_3_10*k9_1;
xdot(37) = C_3_9*k9 + C_2_10*k2 - C_3_10*k3 - C_3_10*k10 - C_3_10*k2_1 - C_3_10*k9_1 + C_4_10*k3_1;
xdot(38) = 2*C_3_4*k3 - 2*C_4_4*k4 - 2*C_4_4*k3_1 + 2*C_4_5*k4_1 + k3*mu_3 + k4*mu_4 + k3_1*mu_4 + k4_1*mu_5;
xdot(39) = C_3_5*k3 + C_4_4*k4 - C_4_5*k4 - C_4_5*k5 - C_4_5*k3_1 - C_4_5*k4_1 + C_5_5*k4_1 + C_4_6*k5_1 - k4*mu_4 - k4_1*mu_5;
xdot(40) = C_3_6*k3 + C_4_5*k5 - C_4_6*k4 - C_4_6*k6 - C_4_6*k3_1 - C_4_6*k5_1 + C_5_6*k4_1 + C_4_7*k6_1;
xdot(41) = C_3_7*k3 - C_4_7*k4 + C_4_6*k6 - C_4_7*k7 - C_4_7*k3_1 + C_5_7*k4_1 - C_4_7*k6_1 + C_4_8*k7_1;
xdot(42) = C_3_8*k3 - C_4_8*k4 + C_4_7*k7 - C_4_8*k8 - C_4_8*k3_1 + C_5_8*k4_1 - C_4_8*k7_1 + C_4_9*k8_1;
xdot(43) = C_3_9*k3 - C_4_9*k4 + C_4_8*k8 - C_4_9*k9 - C_4_9*k3_1 + C_5_9*k4_1 - C_4_9*k8_1 + C_4_10*k9_1;
xdot(44) = C_4_9*k9 + C_3_10*k3 - C_4_10*k4 - C_4_10*k10 - C_4_10*k3_1 - C_4_10*k9_1 + C_5_10*k4_1;
xdot(45) = 2*C_4_5*k4 - 2*C_5_5*k5 - 2*C_5_5*k4_1 + 2*C_5_6*k5_1 + k4*mu_4 + k5*mu_5 + k4_1*mu_5 + k5_1*mu_6;
xdot(46) = C_4_6*k4 + C_5_5*k5 - C_5_6*k5 - C_5_6*k6 - C_5_6*k4_1 - C_5_6*k5_1 + C_6_6*k5_1 + C_5_7*k6_1 - k5*mu_5 - k5_1*mu_6;
xdot(47) = C_4_7*k4 + C_5_6*k6 - C_5_7*k5 - C_5_7*k7 - C_5_7*k4_1 - C_5_7*k6_1 + C_6_7*k5_1 + C_5_8*k7_1;
xdot(48) = C_4_8*k4 - C_5_8*k5 + C_5_7*k7 - C_5_8*k8 - C_5_8*k4_1 + C_6_8*k5_1 - C_5_8*k7_1 + C_5_9*k8_1;
xdot(49) = C_4_9*k4 - C_5_9*k5 + C_5_8*k8 - C_5_9*k9 - C_5_9*k4_1 + C_6_9*k5_1 - C_5_9*k8_1 + C_5_10*k9_1;
xdot(50) = C_5_9*k9 + C_4_10*k4 - C_5_10*k5 - C_5_10*k10 - C_5_10*k4_1 - C_5_10*k9_1 + C_6_10*k5_1;
xdot(51) = 2*C_5_6*k5 - 2*C_6_6*k6 - 2*C_6_6*k5_1 + 2*C_6_7*k6_1 + k5*mu_5 + k6*mu_6 + k5_1*mu_6 + k6_1*mu_7;
xdot(52) = C_5_7*k5 + C_6_6*k6 - C_6_7*k6 - C_6_7*k7 - C_6_7*k5_1 - C_6_7*k6_1 + C_7_7*k6_1 + C_6_8*k7_1 - k6*mu_6 - k6_1*mu_7;
xdot(53) = C_5_8*k5 + C_6_7*k7 - C_6_8*k6 - C_6_8*k8 - C_6_8*k5_1 - C_6_8*k7_1 + C_7_8*k6_1 + C_6_9*k8_1;
xdot(54) = C_5_9*k5 - C_6_9*k6 + C_6_8*k8 - C_6_9*k9 - C_6_9*k5_1 + C_7_9*k6_1 - C_6_9*k8_1 + C_6_10*k9_1;
xdot(55) = C_6_9*k9 + C_5_10*k5 - C_6_10*k6 - C_6_10*k10 - C_6_10*k5_1 - C_6_10*k9_1 + C_7_10*k6_1;
xdot(56) = 2*C_6_7*k6 - 2*C_7_7*k7 - 2*C_7_7*k6_1 + 2*C_7_8*k7_1 + k6*mu_6 + k7*mu_7 + k6_1*mu_7 + k7_1*mu_8;
xdot(57) = C_6_8*k6 + C_7_7*k7 - C_7_8*k7 - C_7_8*k8 - C_7_8*k6_1 - C_7_8*k7_1 + C_8_8*k7_1 + C_7_9*k8_1 - k7*mu_7 - k7_1*mu_8;
xdot(58) = C_6_9*k6 + C_7_8*k8 - C_7_9*k7 - C_7_9*k9 - C_7_9*k6_1 - C_7_9*k8_1 + C_8_9*k7_1 + C_7_10*k9_1;
xdot(59) = C_7_9*k9 + C_6_10*k6 - C_7_10*k7 - C_7_10*k10 - C_7_10*k6_1 - C_7_10*k9_1 + C_8_10*k7_1;
xdot(60) = 2*C_7_8*k7 - 2*C_8_8*k8 - 2*C_8_8*k7_1 + 2*C_8_9*k8_1 + k7*mu_7 + k8*mu_8 + k7_1*mu_8 + k8_1*mu_9;
xdot(61) = C_7_9*k7 + C_8_8*k8 - C_8_9*k8 - C_8_9*k9 - C_8_9*k7_1 - C_8_9*k8_1 + C_9_9*k8_1 + C_8_10*k9_1 - k8*mu_8 - k8_1*mu_9;
xdot(62) = C_8_9*k9 + C_7_10*k7 - C_8_10*k8 - C_8_10*k10 - C_8_10*k7_1 - C_8_10*k9_1 + C_9_10*k8_1;
xdot(63) = 2*C_8_9*k8 - 2*C_9_9*k9 - 2*C_9_9*k8_1 + 2*C_9_10*k9_1 + k8*mu_8 + k9*mu_9 + k8_1*mu_9 + k9_1*mu_10;
xdot(64) = C_9_9*k9 + C_8_10*k8 - C_9_10*k9 - C_9_10*k10 - C_9_10*k8_1 - C_9_10*k9_1 + C_10_10*k9_1 - k9*mu_9 - k9_1*mu_10;
xdot(65) = 2*C_9_10*k9 - 2*C_10_10*k10 - 2*C_10_10*k9_1 + k9*mu_9 + k10*mu_10 + k9_1*mu_10;
% INITIAL CONDITIONS

x0 = sym(zeros(size(x)));

x0(1) = indmu1*kmu01 - fmu01*(indmu1 - 1);
x0(2) = indmu2*kmu02 - fmu02*(indmu2 - 1);
x0(3) = indmu3*kmu03 - fmu03*(indmu3 - 1);
x0(4) = indmu4*kmu04 - fmu04*(indmu4 - 1);
x0(5) = indmu5*kmu05 - fmu05*(indmu5 - 1);
x0(6) = indmu6*kmu06 - fmu06*(indmu6 - 1);
x0(7) = indmu7*kmu07 - fmu07*(indmu7 - 1);
x0(8) = indmu8*kmu08 - fmu08*(indmu8 - 1);
x0(9) = indmu9*kmu09 - fmu09*(indmu9 - 1);
x0(10) = indmu10*kmu010 - fmu010*(indmu10 - 1);
x0(11) = indC1*kC01 - fC01*(indC1 - 1);
x0(12) = indC2*kC02 - fC02*(indC2 - 1);
x0(13) = indC3*kC03 - fC03*(indC3 - 1);
x0(14) = indC4*kC04 - fC04*(indC4 - 1);
x0(15) = indC5*kC05 - fC05*(indC5 - 1);
x0(16) = indC6*kC06 - fC06*(indC6 - 1);
x0(17) = indC7*kC07 - fC07*(indC7 - 1);
x0(18) = indC8*kC08 - fC08*(indC8 - 1);
x0(19) = indC9*kC09 - fC09*(indC9 - 1);
x0(20) = indC10*kC010 - fC010*(indC10 - 1);
x0(21) = indC11*kC011 - fC011*(indC11 - 1);
x0(22) = indC12*kC012 - fC012*(indC12 - 1);
x0(23) = indC13*kC013 - fC013*(indC13 - 1);
x0(24) = indC14*kC014 - fC014*(indC14 - 1);
x0(25) = indC15*kC015 - fC015*(indC15 - 1);
x0(26) = indC16*kC016 - fC016*(indC16 - 1);
x0(27) = indC17*kC017 - fC017*(indC17 - 1);
x0(28) = indC18*kC018 - fC018*(indC18 - 1);
x0(29) = indC19*kC019 - fC019*(indC19 - 1);
x0(30) = indC20*kC020 - fC020*(indC20 - 1);
x0(31) = indC21*kC021 - fC021*(indC21 - 1);
x0(32) = indC22*kC022 - fC022*(indC22 - 1);
x0(33) = indC23*kC023 - fC023*(indC23 - 1);
x0(34) = indC24*kC024 - fC024*(indC24 - 1);
x0(35) = indC25*kC025 - fC025*(indC25 - 1);
x0(36) = indC26*kC026 - fC026*(indC26 - 1);
x0(37) = indC27*kC027 - fC027*(indC27 - 1);
x0(38) = indC28*kC028 - fC028*(indC28 - 1);
x0(39) = indC29*kC029 - fC029*(indC29 - 1);
x0(40) = indC30*kC030 - fC030*(indC30 - 1);
x0(41) = indC31*kC031 - fC031*(indC31 - 1);
x0(42) = indC32*kC032 - fC032*(indC32 - 1);
x0(43) = indC33*kC033 - fC033*(indC33 - 1);
x0(44) = indC34*kC034 - fC034*(indC34 - 1);
x0(45) = indC35*kC035 - fC035*(indC35 - 1);
x0(46) = indC36*kC036 - fC036*(indC36 - 1);
x0(47) = indC37*kC037 - fC037*(indC37 - 1);
x0(48) = indC38*kC038 - fC038*(indC38 - 1);
x0(49) = indC39*kC039 - fC039*(indC39 - 1);
x0(50) = indC40*kC040 - fC040*(indC40 - 1);
x0(51) = indC41*kC041 - fC041*(indC41 - 1);
x0(52) = indC42*kC042 - fC042*(indC42 - 1);
x0(53) = indC43*kC043 - fC043*(indC43 - 1);
x0(54) = indC44*kC044 - fC044*(indC44 - 1);
x0(55) = indC45*kC045 - fC045*(indC45 - 1);
x0(56) = indC46*kC046 - fC046*(indC46 - 1);
x0(57) = indC47*kC047 - fC047*(indC47 - 1);
x0(58) = indC48*kC048 - fC048*(indC48 - 1);
x0(59) = indC49*kC049 - fC049*(indC49 - 1);
x0(60) = indC50*kC050 - fC050*(indC50 - 1);
x0(61) = indC51*kC051 - fC051*(indC51 - 1);
x0(62) = indC52*kC052 - fC052*(indC52 - 1);
x0(63) = indC53*kC053 - fC053*(indC53 - 1);
x0(64) = indC54*kC054 - fC054*(indC54 - 1);
x0(65) = indC55*kC055 - fC055*(indC55 - 1);

% OBSERVABLES

y = sym(zeros(1,1));

y(1) = mu_10;

% SYSTEM STRUCT

model.sym.nmx = 0;
model.sym.x = x;
model.sym.u = u;
model.sym.xdot = xdot;
model.sym.p = p;
model.sym.k = k;
model.sym.x0 = x0;
model.sym.y = y;
% Additional fields for the prespecified length of kappa
model.sym.nk1 = 0;
end