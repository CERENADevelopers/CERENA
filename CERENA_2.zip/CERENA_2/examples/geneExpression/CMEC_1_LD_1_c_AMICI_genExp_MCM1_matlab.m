% function [tout,X,MX,Y] = CMEC_1_LD_1_c_AMICI_genExp_MCM1_matlab(t,theta,kappa) 
function varargout = CMEC_1_LD_1_c_AMICI_genExp_MCM1_matlab(varargin) 

t = varargin{1};
theta = varargin{2};
if(nargin>=3)
    kappa=varargin{3};
   if(length(kappa)==1)
    kappa(2:29)=0;
   end
else
    kappa = zeros(1,29);
end
x0 = [];
% Initial conditions
    x0 = x0fun(theta,kappa);

% Simulation
options = odeset('Mass',@(t,x) MMat(t,x,theta,kappa),...
'MStateDependence','strong','RelTol',1e-8,'AbsTol',1e-8);
[tout,X] = ode15s(@(t,x) rhs(t,x,theta,kappa),t,x0,options);
Y = rhsO(t,X,theta,kappa);

% Assign output
varargout{1} = tout;
if nargout >= 2
varargout{2} = X;
end
if nargout >= 3
    % Overall moments of species
    varargout{3} = Y(:,1:4);
end
if nargout >= 4
    % Moments of output variables
    varargout{4} = Y(:,5:end);
end
if nargout >= 5
    error('Too many output arguments.');
end


%% RIGHT-HAND SIDE
function [dxdt] = rhs(t,x,theta,kappa) 

dxdt = [theta(2)*x(2) - theta(1)*x(1) - kappa(1)*theta(7)*x(1)*x(4);...
         theta(1)*x(1) - theta(2)*x(2) + kappa(1)*theta(7)*x(1)*x(4);...
         theta(2)*x(2)*x(5) - theta(4)*x(1)*x(3) - theta(2)*x(2)*x(3);...
         theta(2)*x(2)*x(6) - theta(2)*x(2)*x(4) - theta(6)*x(1)*x(4) + t*theta(5)*x(1)*x(3);...
         (theta(3)*x(2) + kappa(1)*theta(1)*x(1)*x(3) - kappa(1)*theta(1)*x(1)*x(5) - kappa(1)*theta(4)*x(2)*x(5) + kappa(1)^2*theta(7)*x(1)*x(3)*x(4) - kappa(1)^2*theta(7)*x(1)*x(4)*x(5))/kappa(1);...
         theta(1)*x(1)*x(4) - theta(1)*x(1)*x(6) - theta(6)*x(2)*x(6) + t*theta(5)*x(2)*x(5) + kappa(1)*theta(7)*x(1)*x(4)^2 - kappa(1)*theta(7)*x(1)*x(4)*x(6)];

%% MASS MATRIX
function [M] = MMat(t,x,theta,kappa) 

M = spdiags([1;...
         1;...
         x(1);...
         x(1);...
         x(2);...
         x(2)],0,6,6);

%% OUTPUT MAP
function y = rhsO(t,x,theta,kappa) 

y = [x(:,1),...
         x(:,2),...
         x(:,1).*x(:,3) + x(:,2).*x(:,5),...
         x(:,1).*x(:,4) + x(:,2).*x(:,6),...
         theta(9) + theta(8).*(x(:,1).*x(:,4) + x(:,2).*x(:,6))];


%% INITIAL CONDITIONS FOR STATE
function x0 = x0fun(theta,kappa) 

x0 = [562949953365017/562949953421312;...
       1/10000000000;...
       (kappa(4)*kappa(18) - theta(10)*(kappa(4) - 1))/kappa(1);...
       (kappa(5)*kappa(19))/kappa(1);...
       (kappa(4)*kappa(18) - theta(10)*(kappa(4) - 1))/kappa(1);...
       (kappa(5)*kappa(19))/kappa(1)];


