% function [model] = CMEC_1_LD_1_c_AMICI_genExp_MCM1_syms(f0_user)
function [model] = CMEC_1_LD_1_c_AMICI_genExp_MCM1_syms(varargin)

% CVODES OPTIONS

model.atol = 1e-8;
model.rtol = 1e-8;
model.maxsteps = 1e4;

% STATES

syms p_y_1_0 p_y_0_1 mu_1_y_1_0 mu_2_y_1_0 mu_1_y_0_1 mu_2_y_0_1

x = [
p_y_1_0, p_y_0_1, mu_1_y_1_0, mu_2_y_1_0, mu_1_y_0_1, mu_2_y_0_1 ...
];

% PARAMETERS

syms tau_on tau_off k_m gamma_m k_p gamma_p tau_on_p scaleP offsetP r0 

% KAPPA (constant parameters)

syms Omega indmu1 indmu2 indmu3 indmu4 indC1 indC2 indC3 indC4 indC5 indC6 indC7 indC8 indC9 indC10 kmu01 kmu02 kmu03 kmu04 kC01 kC02 kC03 kC04 kC05 kC06 kC07 kC08 kC09 kC010 

syms t

p = [tau_on,tau_off,k_m,gamma_m,k_p,gamma_p,tau_on_p,scaleP,offsetP,r0];

k = [Omega,indmu1,indmu2,indmu3,indmu4,indC1,indC2,indC3,indC4,indC5,indC6,indC7,indC8,indC9,indC10,kmu01,kmu02,kmu03,kmu04,kC01,kC02,kC03,kC04,kC05,kC06,kC07,kC08,kC09,kC010];

if nargin > 0
   f0_user = varargin{1};
   if ~isnumeric(f0_user)
      p_user = setdiff(symvar(f0_user),p);
      % ADDITIONAL PARAMETERS IN INITIAL CONDITIONS
      p = [p,p_user];
   end
	fmu01 = f0_user(1); 
	fmu02 = f0_user(2); 
	fmu03 = f0_user(3); 
	fmu04 = f0_user(4); 
	fC01 = f0_user(5); 
	fC02 = f0_user(6); 
	fC03 = f0_user(7); 
	fC04 = f0_user(8); 
	fC05 = f0_user(9); 
	fC06 = f0_user(10); 
	fC07 = f0_user(11); 
	fC08 = f0_user(12); 
	fC09 = f0_user(13); 
	fC010 = f0_user(14); 
else
	fmu01 = 1; 
	fmu02 = 0; 
	fmu03 = r0; 
	fmu04 = 0; 
	fC01 = 0; 
	fC02 = 0; 
	fC03 = 0; 
	fC04 = 0; 
	fC05 = 0; 
	fC06 = 0; 
	fC07 = 0; 
	fC08 = 0; 
	fC09 = 0; 
	fC010 = 0; 
end
% INPUT 

u = sym.empty(0,0);

% SYSTEM EQUATIONS

f = sym(zeros(size(x)));

f(1) = p_y_0_1*tau_off - p_y_1_0*tau_on - Omega*mu_2_y_1_0*p_y_1_0*tau_on_p;
f(2) = p_y_1_0*tau_on - p_y_0_1*tau_off + Omega*mu_2_y_1_0*p_y_1_0*tau_on_p;
f(3) = mu_1_y_0_1*p_y_0_1*tau_off - gamma_m*mu_1_y_1_0*p_y_1_0 - mu_1_y_1_0*p_y_0_1*tau_off;
f(4) = mu_2_y_0_1*p_y_0_1*tau_off - gamma_p*mu_2_y_1_0*p_y_1_0 - mu_2_y_1_0*p_y_0_1*tau_off + k_p*mu_1_y_1_0*p_y_1_0*t;
f(5) = (k_m*p_y_0_1 - Omega*mu_1_y_0_1*p_y_1_0*tau_on + Omega*mu_1_y_1_0*p_y_1_0*tau_on - Omega*gamma_m*mu_1_y_0_1*p_y_0_1 - Omega^2*mu_1_y_0_1*mu_2_y_1_0*p_y_1_0*tau_on_p + Omega^2*mu_1_y_1_0*mu_2_y_1_0*p_y_1_0*tau_on_p)/Omega;
f(6) = mu_2_y_1_0*p_y_1_0*tau_on - mu_2_y_0_1*p_y_1_0*tau_on - gamma_p*mu_2_y_0_1*p_y_0_1 + k_p*mu_1_y_0_1*p_y_0_1*t + Omega*mu_2_y_1_0^2*p_y_1_0*tau_on_p - Omega*mu_2_y_0_1*mu_2_y_1_0*p_y_1_0*tau_on_p;
M = diag(sym([[1], [1], [p_y_1_0], [p_y_1_0], [p_y_0_1], [p_y_0_1]]));
% INITIAL CONDITIONS

x0 = sym(zeros(size(x)));

x0(1) = 562949953365017/562949953421312;
x0(2) = 1/10000000000;
x0(3) = (indmu3*kmu03 - fmu03*(indmu3 - 1))/Omega;
x0(4) = (indmu4*kmu04 - fmu04*(indmu4 - 1))/Omega;
x0(5) = (indmu3*kmu03 - fmu03*(indmu3 - 1))/Omega;
x0(6) = (indmu4*kmu04 - fmu04*(indmu4 - 1))/Omega;
dx0 = sym(zeros(size(x)));
dx0(1) = tau_off/10000000000 - (562949953365017*tau_on)/562949953421312 - (562949953365017*tau_on_p*(indmu4*kmu04 - fmu04*(indmu4 - 1)))/562949953421312;
dx0(2) = (562949953365017*tau_on)/562949953421312 - tau_off/10000000000 + (562949953365017*tau_on_p*(indmu4*kmu04 - fmu04*(indmu4 - 1)))/562949953421312;
dx0(3) = -(gamma_m*(indmu3*kmu03 - fmu03*(indmu3 - 1)))/Omega;
dx0(4) = (k_p*t*(indmu3*kmu03 - fmu03*(indmu3 - 1)))/Omega - (gamma_p*(indmu4*kmu04 - fmu04*(indmu4 - 1)))/Omega;
dx0(5) = (10000000000*(k_m/10000000000 - (gamma_m*(indmu3*kmu03 - fmu03*(indmu3 - 1)))/10000000000))/Omega;
dx0(6) = (k_p*t*(indmu3*kmu03 - fmu03*(indmu3 - 1)))/Omega - (gamma_p*(indmu4*kmu04 - fmu04*(indmu4 - 1)))/Omega;

% OBSERVABLES

y = sym(zeros(5,1));

y(1) = p_y_1_0;
y(2) = p_y_0_1;
y(3) = mu_1_y_0_1*p_y_0_1 + mu_1_y_1_0*p_y_1_0;
y(4) = mu_2_y_0_1*p_y_0_1 + mu_2_y_1_0*p_y_1_0;
y(5) = offsetP + scaleP*(mu_2_y_0_1*p_y_0_1 + mu_2_y_1_0*p_y_1_0);

% SYSTEM STRUCT

model.sym.nmx = 4;
model.sym.x = x;
model.sym.u = u;
model.sym.f = f;
model.sym.M = M;
model.sym.p = p;
model.sym.k = k;
model.sym.x0 = x0;
model.sym.dx0 = dx0;
model.sym.y = y;
% Additional fields for the prespecified length of kappa
model.sym.nk1 = 1;
end